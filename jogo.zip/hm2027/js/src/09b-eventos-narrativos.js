// Motor de Eventos Narrativos (2026-09-28, pedido do utilizador: "um motor de eventos
// narrativos com raridade... pode gerar centenas de histórias diferentes sem criar novas
// mecânicas complexas"). Fase 1: catálogo de eventos COMUNS/RAROS, resolvidos sempre de forma
// automática (nunca pausam o jogo) — os eventos ÉPICOS/LENDÁRIOS, com modal de escolha, ficam
// para a Fase 2. Corre uma vez por dia, chamado a partir de dailyConditionRecovery
// (09-fluxo-epoca.js) — o único ponto por onde passa cada dia de calendário que o utilizador
// avança, incluindo durante o defeso.
//
// Cada entrada do catálogo (NARRATIVE_EVENTS) tem:
//   id, categoria, raridade ("comum"|"raro"|"epico"|"lendario"), peso (dentro da raridade),
//   titulo (fixo, sem variação — a raridade é que aparece como badge), textos (array de 3-5
//   variantes com placeholders {chave}, ou uma função(ctx){ return [...] } quando o texto
//   depende do desfecho, ver capitao-dividido), elegivel() (bool), montarContexto() (calcula
//   tudo o que for aleatório UMA só vez e devolve o objeto usado para preencher {chaves} no
//   texto — o mesmo objeto/estado fica disponível a aplicarAutomatico via "this"), e
//   aplicarAutomatico() (mexe no estado do jogo depois do texto já estar montado).
//
// Pedido explícito do utilizador ("elabora textos interessantes e bem escritos, várias versões
// de cada para não parecer repetido"): pickNarrativeText nunca repete a última variante usada
// para o mesmo evento (state.eventosUltimoTexto).

const NARRATIVE_RARITY_DAILY_CHANCE = {
  comum: 0.015,
  raro: 0.0035,
  epico: 0.0006,
  lendario: 0.00008,
};
// Da raridade mais rara para a mais comum: se mais do que uma condição se verificar no mesmo
// dia, o mais marcante tem prioridade (só um evento novo por dia).
const NARRATIVE_RARITY_ORDER = ["lendario", "epico", "raro", "comum"];
const NARRATIVE_RARITY_BADGE = { comum: "", raro: "[Raro] ", epico: "[Épico] ", lendario: "[Lendário] " };
const NARRATIVE_DEFAULT_COOLDOWN_DIAS = 90;

function ensureNarrativeEventState() {
  if (!Array.isArray(state.eventosHistorico)) state.eventosHistorico = [];
  if (!state.eventosCooldown || typeof state.eventosCooldown !== "object") state.eventosCooldown = {};
  if (!state.eventosUltimoTexto || typeof state.eventosUltimoTexto !== "object") state.eventosUltimoTexto = {};
}

function narrativeTextPool(ev, ctx) {
  return typeof ev.textos === "function" ? ev.textos(ctx) : (ev.textos || []);
}

// Nunca repete a última variante usada PARA ESTE EVENTO — com 1 única variante o índice fica
// sempre 0 (nada a evitar).
function pickNarrativeText(ev, ctx) {
  const textos = narrativeTextPool(ev, ctx);
  if (!textos.length) return "";
  if (textos.length === 1) return textos[0];
  const last = state.eventosUltimoTexto[ev.id];
  let idx = Math.floor(Math.random() * textos.length);
  if (idx === last) idx = (idx + 1) % textos.length;
  state.eventosUltimoTexto[ev.id] = idx;
  return textos[idx];
}

function fillNarrativeTemplate(template, ctx) {
  return String(template || "").replace(/\{(\w+)\}/g, (m, key) => (ctx && ctx[key] != null ? ctx[key] : m));
}

function narrativeEventOnCooldown(ev) {
  const ate = state.eventosCooldown[ev.id];
  return !!(ate && state.currentDate < new Date(ate));
}

function pickWeightedNarrativeEvent(list) {
  const total = list.reduce((sum, ev) => sum + Math.max(0, ev.peso || 1), 0);
  if (total <= 0) return null;
  let roll = Math.random() * total;
  for (const ev of list) {
    roll -= Math.max(0, ev.peso || 1);
    if (roll <= 0) return ev;
  }
  return list[list.length - 1];
}

// Próximo jogo por disputar / último já disputado do clube do utilizador na sua própria
// competição — usados pelos eventos ligados a um adversário concreto (Árbitro Polémico,
// Traição, Golo Fantasma). state.fixtures é uma lista de JORNADAS (cada uma um array de jogos,
// ver generateFixtures em 03-calendario.js) — não uma lista plana de jogos — por isso é preciso
// percorrer as jornadas por ordem (já cronológica, é assim que currentRound avança) e não tratar
// state.fixtures como se cada elemento fosse já um jogo.
function flattenUserFixtures() {
  if (!Array.isArray(state.fixtures)) return [];
  const out = [];
  state.fixtures.forEach(jornada => {
    (jornada || []).forEach(f => { if (f.home === state.userTeamId || f.away === state.userTeamId) out.push(f); });
  });
  return out;
}
function nextUserFixture() {
  return flattenUserFixtures().find(f => !f.played) || null;
}
function lastUserPlayedFixture() {
  const jogados = flattenUserFixtures().filter(f => f.played);
  return jogados.length ? jogados[jogados.length - 1] : null;
}
function opponentOfFixture(fixture, teamId) {
  if (!fixture) return null;
  if (fixture.home === teamId) return fixture.away;
  if (fixture.away === teamId) return fixture.home;
  return null;
}

function userIsAnyLeagueChampionThisSeason() {
  return [state.placardChampion, state.okLigaChampion, state.serieA1Champion].some(id => id && id === state.userTeamId);
}

const NARRATIVE_LEGEND_FATHER_NAMES = [
  "Paulo Ventura", "Fernando Cardoso", "Ricardo Nogueira", "Jorge Salgado", "Manuel Aveiro",
  "António Roquete", "Vítor Lameira", "Carlos Bessa", "Rui Falcão", "Henrique Salvador",
];
function randomLegendFatherName() {
  return NARRATIVE_LEGEND_FATHER_NAMES[Math.floor(Math.random() * NARRATIVE_LEGEND_FATHER_NAMES.length)];
}

const NARRATIVE_EVENTS = [
  // ---------------------------------------------------------------- Jovens Promessas
  {
    id: "crescimento-tardio", categoria: "juvenis", raridade: "raro", peso: 10, cooldownDias: 200,
    titulo: "Crescimento Tardio",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!team && team.players.some(p => p.age >= 21 && p.age <= 23 && overall(p) <= 11 && (p.potential || overall(p)) <= overall(p) + 2);
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const candidatos = team.players.filter(p => p.age >= 21 && p.age <= 23 && overall(p) <= 11 && (p.potential || overall(p)) <= overall(p) + 2);
      const p = candidatos[Math.floor(Math.random() * candidatos.length)];
      this._player = p;
      return { jogador: playerLinkHtml(team.id, p), idade: p.age, teamId: team.id };
    },
    aplicarAutomatico() {
      const p = this._player; if (!p) return;
      p.potential = clamp((p.potential || overall(p)) + (2 + Math.floor(Math.random() * 3)), overall(p), 20);
    },
    textos: [
      "Os treinadores acreditam que {jogador} pode ter dado um salto qualitativo inesperado. Aos {idade} anos, ninguém apostava nele — mas os números da última época contam outra história.",
      "Ninguém esperava mais nada de {jogador}. E, no entanto, algo mudou: a equipa técnica fala de uma evolução que ninguém via chegar.",
      "{jogador} nunca foi apontado como uma promessa. Esta época, porém, tem surpreendido até os mais cépticos do balneário.",
    ],
  },
  {
    id: "filho-de-uma-lenda", categoria: "juvenis", raridade: "raro", peso: 6, cooldownDias: 300,
    titulo: "Filho de uma Lenda",
    elegivel() {
      const team = state.teams[state.userTeamId];
      if (!team || !team.academy) return false;
      return ACADEMY_BRACKETS.some(b => team.academy.brackets[b] && team.academy.brackets[b].players.some(p => !p.paiLendaNome));
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const pool = [];
      ACADEMY_BRACKETS.forEach(b => { if (team.academy.brackets[b]) pool.push(...team.academy.brackets[b].players.filter(p => !p.paiLendaNome)); });
      const p = pool[Math.floor(Math.random() * pool.length)];
      this._player = p;
      const pai = randomLegendFatherName();
      return { jogador: `<b>${p.name}</b>`, pai, teamId: team.id };
    },
    aplicarAutomatico() {
      if (this._player) this._player.paiLendaNome = randomLegendFatherName();
    },
    textos: [
      "{jogador}, filho do histórico internacional {pai}, surge na academia. Os adeptos já sonham em voz alta.",
      "O apelido pesa: {jogador} é filho de {pai}, uma lenda do hóquei nacional. A expectativa à sua volta é enorme — talvez injusta.",
      "Chama-se {jogador}, mas todos falam dele como «o filho de {pai}». Vai ter de construir o seu próprio nome, cedo ou tarde.",
    ],
  },
  // ---------------------------------------------------------------- Balneário
  {
    id: "capitao-dividido", categoria: "balneario", raridade: "raro", peso: 7, cooldownDias: 150,
    titulo: "Capitão Dividido",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!team && team.players.length >= 8;
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      // Balneário (08d): o protagonista é o capitão real do grupo, não o melhor jogador.
      const capitao = (balnearioResolverCapitao(team).player) || team.players.slice().sort((a, b) => overall(b) - overall(a))[0];
      const avgSat = team.players.reduce((s, p) => s + (p.satisfacao != null ? p.satisfacao : 70), 0) / team.players.length;
      this._resolve = avgSat >= 60;
      this._team = team;
      return { jogador: playerLinkHtml(team.id, capitao), teamId: team.id };
    },
    aplicarAutomatico() {
      const team = this._team; if (!team) return;
      const delta = this._resolve ? 4 : -6;
      team.players.forEach(p => { p.moral = clamp((p.moral != null ? p.moral : 70) + delta, 0, 100); });
      const bal = ensureBalneario(team);
      if (bal) bal.coesao = clamp(bal.coesao + (this._resolve ? 4 : -5), 3, 99);
    },
    textos(ctx) {
      return this._resolve ? [
        "{jogador} reuniu o balneário à porta fechada. O que quer que tenha dito, resultou: o ambiente no plantel melhorou visivelmente nos dias seguintes.",
        "A palavra de {jogador} continua a pesar no balneário. Bastou uma conversa para o mal-estar interno começar a dissipar-se.",
        "{jogador} pôs-se do lado da estrutura técnica, e isso foi suficiente para apaziguar os ânimos no balneário.",
      ] : [
        "{jogador} decidiu apoiar os colegas descontentes, não o treinador. O conflito no balneário, em vez de se resolver, agravou-se.",
        "Em vez de acalmar os ânimos, a intervenção de {jogador} tomou partido — e o mal-estar no balneário aprofundou-se.",
        "{jogador} escolheu o lado do balneário, não o da estrutura técnica. O ambiente interno piorou nos dias seguintes.",
      ];
    },
  },
  // Balneário (08d-balneario.js): eventos que dependem do estado oculto de coesão do grupo.
  {
    id: "jantar-de-equipa", categoria: "balneario", raridade: "comum", peso: 8, cooldownDias: 120,
    titulo: "Jantar de Equipa",
    elegivel() {
      const team = state.teams[state.userTeamId]; const b = team && ensureBalneario(team);
      return !!b && b.coesao >= 58 && team.players.length >= 8;
    },
    montarContexto() {
      const team = state.teams[state.userTeamId]; this._team = team;
      const cap = balnearioResolverCapitao(team).player;
      return { capitao: cap ? playerLinkHtml(team.id, cap) : "o capitão", teamId: team.id };
    },
    aplicarAutomatico() {
      const team = this._team; if (!team) return;
      const b = ensureBalneario(team); if (b) b.coesao = clamp(b.coesao + 2.2, 3, 99);
      team.players.forEach(p => { p.moral = clamp((p.moral != null ? p.moral : 70) + 2, 0, 100); });
    },
    textos: [
      "{capitao} organizou um jantar de equipa e o plantel quase em peso apareceu. Entre histórias de balneário e piadas antigas, o grupo saiu mais próximo do que entrou.",
      "Sem treinador e sem tácticas, só o plantel à mesa. O jantar organizado por {capitao} deixou boas memórias e um ambiente ainda melhor nos treinos seguintes.",
      "Os jogadores marcaram um jantar por iniciativa própria, com {capitao} à cabeça. Há ambientes que se constroem fora do rinque.",
    ],
  },
  {
    id: "zanga-no-treino", categoria: "balneario", raridade: "comum", peso: 8, cooldownDias: 100,
    titulo: "Zanga no Treino",
    elegivel() {
      const team = state.teams[state.userTeamId]; const b = team && ensureBalneario(team);
      return !!b && b.coesao < 50 && team.players.length >= 8;
    },
    montarContexto() {
      const team = state.teams[state.userTeamId]; this._team = team;
      const pool = team.players.filter(p => !p.__provisional).slice().sort((a, b) => (a.satisfacao != null ? a.satisfacao : 70) - (b.satisfacao != null ? b.satisfacao : 70));
      const a = pool[0], o = pool[1 + Math.floor(Math.random() * Math.max(1, Math.min(4, pool.length - 1)))] || pool[1];
      this._a = a; this._o = o;
      return { jogador: playerLinkHtml(team.id, a), outro: playerLinkHtml(team.id, o), teamId: team.id };
    },
    aplicarAutomatico() {
      const team = this._team; if (!team) return;
      const b = ensureBalneario(team); if (b) b.coesao = clamp(b.coesao - 2.5, 3, 99);
      [this._a, this._o].forEach(p => { if (p) { p.moral = clamp((p.moral != null ? p.moral : 70) - 6, 0, 100); p.satisfacao = clamp((p.satisfacao != null ? p.satisfacao : 70) - 2, 0, 100); } });
    },
    textos: [
      "O treino terminou mais cedo do que o previsto: {jogador} e {outro} trocaram palavras duras por causa de uma jogada, e foi preciso os companheiros separá-los.",
      "Há tensão no balneário e esta tarde ela rebentou. {jogador} e {outro} discutiram em pleno treino, perante o silêncio constrangido dos colegas.",
      "Um choque no exercício acabou em discussão aberta entre {jogador} e {outro}. Já se fez as pazes, mas o clima ficou carregado.",
    ],
  },
  {
    id: "capitao-apazigua", categoria: "balneario", raridade: "raro", peso: 8, cooldownDias: 150,
    titulo: "O Capitão Põe Ordem",
    elegivel() {
      const team = state.teams[state.userTeamId]; const b = team && ensureBalneario(team);
      if (!b || b.coesao < 30 || b.coesao > 52) return false;
      const cap = balnearioResolverCapitao(team, b).player;
      return !!cap && cap.attrs && (cap.attrs.lideranca || 0) >= 12;
    },
    montarContexto() {
      const team = state.teams[state.userTeamId]; this._team = team;
      const cap = balnearioResolverCapitao(team).player; this._cap = cap;
      return { capitao: playerLinkHtml(team.id, cap), teamId: team.id };
    },
    aplicarAutomatico() {
      const team = this._team; if (!team) return;
      const b = ensureBalneario(team); if (b) b.coesao = clamp(b.coesao + 4.5, 3, 99);
      if (this._cap) this._cap.satisfacao = clamp((this._cap.satisfacao != null ? this._cap.satisfacao : 70) + 3, 0, 100);
    },
    textos: [
      "Quando o balneário já ameaçava rachar, {capitao} levantou-se e disse o que ninguém queria ouvir. Não houve gritos, só franqueza — e o grupo ficou mais forte.",
      "{capitao} chamou os colegas um a um, ouviu queixas e arrumou diferenças. O ambiente nos treinos mudou logo a seguir.",
      "A braçadeira de capitão pesa nos dias maus. {capitao} carregou-a com autoridade e travou uma crise que se anunciava.",
    ],
  },
  {
    id: "veteranos-acolhem", categoria: "balneario", raridade: "comum", peso: 6, cooldownDias: 150,
    titulo: "Veteranos Acolhem Jovem",
    elegivel() {
      const team = state.teams[state.userTeamId]; const b = team && ensureBalneario(team);
      if (!b || b.coesao < 48) return false;
      return team.players.some(p => p.age <= 20 && balnearioTenureYears(b, p) < 0.5) && team.players.some(p => p.age >= 28);
    },
    montarContexto() {
      const team = state.teams[state.userTeamId]; const b = ensureBalneario(team); this._team = team;
      const jovens = team.players.filter(p => p.age <= 20 && balnearioTenureYears(b, p) < 0.5);
      const novo = jovens[Math.floor(Math.random() * jovens.length)];
      const vets = team.players.filter(p => p.age >= 28).sort((x, y) => balnearioLeaderScore(b, y) - balnearioLeaderScore(b, x));
      this._novo = novo;
      return { jovem: playerLinkHtml(team.id, novo), veterano: playerLinkHtml(team.id, vets[0]), teamId: team.id };
    },
    aplicarAutomatico() {
      const team = this._team; if (!team) return;
      const b = ensureBalneario(team); if (b) b.coesao = clamp(b.coesao + 1.5, 3, 99);
      if (this._novo) this._novo.moral = clamp((this._novo.moral != null ? this._novo.moral : 70) + 6, 0, 100);
    },
    textos: [
      "{veterano} tomou {jovem} sob a sua asa desde o primeiro dia. Os mais velhos fazem questão de integrar quem chega, e isso nota-se no balneário.",
      "Para {jovem}, chegar a um balneário novo podia ter sido difícil. {veterano} tratou de lhe facilitar a vida e o resto do grupo seguiu o exemplo.",
      "Há tradições que mantêm um grupo unido: {veterano} faz questão de acolher os mais novos, e {jovem} já se sente em casa.",
    ],
  },
  {
    id: "balneario-dividido", categoria: "balneario", raridade: "epico", peso: 6, cooldownDias: 200,
    titulo: "Balneário Dividido",
    elegivel() {
      const team = state.teams[state.userTeamId]; const b = team && ensureBalneario(team);
      return !!b && b.coesao < 32 && team.players.length >= 8;
    },
    montarContexto() {
      const team = state.teams[state.userTeamId]; this._team = team;
      return { teamId: team.id };
    },
    escolhas: [
      {
        label: "Reunião geral, sem filtros",
        aplicar() {
          const team = this._team; const b = ensureBalneario(team);
          const cap = balnearioFatores(team, b).capitao;
          const bem = Math.random() < clamp(0.5 + cap * 0.25, 0.25, 0.8);
          b.coesao = clamp(b.coesao + (bem ? 8 : -4), 3, 99);
          return bem
            ? "Todos disseram o que pensavam, houve vozes alteradas, mas no fim as mágoas ficaram em cima da mesa. O grupo saiu da sala mais unido."
            : "A reunião correu mal: em vez de resolver, deu palco a velhas queixas. O ambiente ficou mais pesado.";
        },
      },
      {
        label: "Falar primeiro com os líderes",
        aplicar() {
          const team = this._team; const b = ensureBalneario(team);
          const f = balnearioFatores(team, b);
          const ok = f.lideres.length && f.lideres.reduce((s, p) => s + (p.satisfacao != null ? p.satisfacao : 70), 0) / f.lideres.length >= 50;
          b.coesao = clamp(b.coesao + (ok ? 5 : 1), 3, 99);
          return ok
            ? "Os líderes do grupo ouviram-te e comprometeram-se a puxar pelos colegas. A mudança foi gradual, mas sentiu-se."
            : "Os líderes também estão descontentes e pouco ajudaram. O efeito foi mínimo.";
        },
      },
      {
        label: "Deixar o grupo resolver sozinho",
        aplicar() {
          const team = this._team; const b = ensureBalneario(team);
          const sorte = Math.random() < 0.3;
          b.coesao = clamp(b.coesao + (sorte ? 4 : -3), 3, 99);
          return sorte
            ? "Contra todas as expectativas, o grupo acertou agulhas sem intervenção. Um alívio."
            : "Sem ninguém a mediar, as divisões aprofundaram-se. O silêncio da direcção foi lido como desinteresse.";
        },
      },
    ],
    textos: [
      "O balneário está partido ao meio: dois grupos, duas versões, e ninguém disposto a ceder. Os resultados em campo já sentem o efeito. Como vais reagir?",
      "Há jogadores que já não se falam fora dos treinos. O fosso no plantel é evidente e pede uma decisão tua antes que a época se perca.",
      "Chegam sinais claros de que o grupo se dividiu em facções. Se nada for feito, o desgaste vai custar pontos.",
    ],
  },
  // ---------------------------------------------------------------- Transferências
  {
    id: "traicao", categoria: "transferencias", raridade: "raro", peso: 8, cooldownDias: 120,
    titulo: "Traição",
    elegivel() {
      const fx = nextUserFixture(); if (!fx) return false;
      const oppId = opponentOfFixture(fx, state.userTeamId);
      const opp = oppId && state.teams[oppId];
      return !!(opp && opp.players.some(p => p.clubeFormadorId === state.userTeamId));
    },
    montarContexto() {
      const fx = nextUserFixture();
      const oppId = opponentOfFixture(fx, state.userTeamId);
      const opp = state.teams[oppId];
      const p = opp.players.find(p => p.clubeFormadorId === state.userTeamId);
      this._player = p;
      return { jogador: playerLinkHtml(opp.id, p), clube: opp.name, teamId: state.userTeamId };
    },
    aplicarAutomatico() {
      if (this._player) this._player.moral = clamp((this._player.moral != null ? this._player.moral : 70) - 4, 0, 100);
    },
    textos: [
      "{jogador}, formado nas camadas jovens do clube, regressa esta noite — agora com as cores do {clube}. A bancada não vai esquecer.",
      "Há regressos que doem mais do que outros. {jogador} volta a casa vestido de adversário, e os adeptos já preparam os assobios.",
      "Formou-se aqui, cresceu aqui. Hoje joga contra o clube que o viu nascer para o hóquei em patins. {jogador} sabe bem o que o espera esta noite.",
    ],
  },
  {
    id: "regresso-a-casa", categoria: "transferencias", raridade: "comum", peso: 8, cooldownDias: 150,
    titulo: "Regresso a Casa",
    elegivel() {
      const team = state.teams[state.userTeamId]; if (!team) return false;
      return team.players.some(p => p.age >= 30 && p.clubeFormadorId === team.id && !p._regressoAnunciado &&
        (state.transferHistory || []).some(h => h.player === p.name && h.to === team.name && h.from !== team.name));
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const p = team.players.find(p => p.age >= 30 && p.clubeFormadorId === team.id && !p._regressoAnunciado &&
        (state.transferHistory || []).some(h => h.player === p.name && h.to === team.name && h.from !== team.name));
      this._player = p;
      return { jogador: playerLinkHtml(team.id, p), teamId: team.id };
    },
    aplicarAutomatico() {
      const p = this._player; if (!p) return;
      p._regressoAnunciado = true;
      p.moral = clamp((p.moral != null ? p.moral : 70) + 6, 0, 100);
      p.satisfacao = clamp((p.satisfacao != null ? p.satisfacao : 70) + 6, 0, 100);
    },
    textos: [
      "{jogador} está de volta a casa. Anos depois de sair, veste de novo as cores do clube que o viu nascer para o hóquei em patins — e a bancada nota-se mais cheia do que o habitual.",
      "O regresso de {jogador} traz um ligeiro alvoroço às bancadas. Poucas coisas emocionam tanto os adeptos como ver um dos seus voltar a casa.",
      "{jogador} volta ao clube onde tudo começou. Não é só mais uma contratação — é uma história a fechar-se, aos olhos de quem acompanha o clube há anos.",
    ],
  },
  // ---------------------------------------------------------------- Adeptos
  {
    id: "novo-idolo", categoria: "adeptos", raridade: "comum", peso: 9, cooldownDias: 120,
    titulo: "Novo Ídolo",
    elegivel() {
      const team = state.teams[state.userTeamId]; if (!team) return false;
      return team.players.some(p => p.season && p.season.notas && p.season.notas.length >= 3 && avg(p.season.notas) >= 7.3 && !p._idoloAnunciado);
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const p = team.players.find(p => p.season && p.season.notas && p.season.notas.length >= 3 && avg(p.season.notas) >= 7.3 && !p._idoloAnunciado);
      this._player = p;
      return { jogador: playerLinkHtml(team.id, p), teamId: team.id };
    },
    aplicarAutomatico() {
      const p = this._player; if (!p) return;
      p._idoloAnunciado = true;
      p.moral = clamp((p.moral != null ? p.moral : 70) + 3, 0, 100);
    },
    textos: [
      "{jogador} tornou-se o preferido da claque. Os relatórios da imprensa desportiva local já não escrevem sobre o clube sem o mencionar.",
      "Já não é só mais um jogador do plantel: {jogador} conquistou os adeptos, e o nome aparece agora em quase todas as crónicas sobre o clube.",
      "Poucos jogadores conseguem este tipo de ligação com a claque. {jogador} tornou-se, sem grande alarido, o novo ídolo da casa.",
    ],
  },
  {
    id: "heroi-inesperado", categoria: "adeptos", raridade: "raro", peso: 5, cooldownDias: 365,
    titulo: "Herói Inesperado",
    elegivel() {
      return userIsAnyLeagueChampionThisSeason() && state.eventosHeroiSeason !== state.season;
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const suplentes = team.players.filter(p => !p.titular);
      const p = suplentes.length ? suplentes[Math.floor(Math.random() * suplentes.length)] : team.players[Math.floor(Math.random() * team.players.length)];
      this._player = p;
      return { jogador: playerLinkHtml(team.id, p), teamId: team.id };
    },
    aplicarAutomatico() {
      state.eventosHeroiSeason = state.season;
      const p = this._player; if (p) p.moral = clamp((p.moral != null ? p.moral : 70) + 8, 0, 100);
    },
    textos: [
      "Ninguém apostava em {jogador} para decidir a época — e foi exactamente isso que aconteceu. Um nome que os adeptos não vão esquecer tão cedo.",
      "{jogador} saiu do banco, entrou no jogo mais importante da época, e teve um papel decisivo no título. As lendas nascem assim, sem aviso.",
      "Não era titular, não era favorito. Mas {jogador} escreveu o seu nome na história do clube nesta conquista, no momento mais importante possível.",
    ],
  },
  // ---------------------------------------------------------------- Financeiras
  {
    id: "patrocinador-milagre", categoria: "financeiras", raridade: "raro", peso: 7, cooldownDias: 200,
    titulo: "Patrocinador Milagre",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!(team && team.financeiro);
    },
    montarContexto() {
      const ganho = Math.round(40000 + Math.random() * 50000);
      this._ganho = ganho;
      return { clube: state.teams[state.userTeamId].name, valor: ganho.toLocaleString("pt-PT"), teamId: state.userTeamId };
    },
    aplicarAutomatico() {
      const f = state.teams[state.userTeamId].financeiro;
      f.saldo = (f.saldo || 0) + this._ganho;
      f.orcamentoTransferencias = Math.round((f.orcamentoTransferencias || 0) + this._ganho * 0.3);
    },
    textos: [
      "Uma empresa local decidiu apostar no {clube}: {valor}€ injectados nas contas do clube, de um dia para o outro. Ninguém esperava, mas ninguém vai recusar.",
      "Boa notícia inesperada para o {clube}: um patrocinador de peso decidiu entrar, reforçando o orçamento em {valor}€. A direcção já fala em investir bem este dinheiro.",
      "O telefone da direcção não parou de tocar depois de a notícia se espalhar: um novo patrocinador injecta {valor}€ nas contas do {clube}, sem aviso prévio.",
    ],
  },
  // ---------------------------------------------------------------- Academia
  {
    id: "bairro-de-talento", categoria: "academia", raridade: "raro", peso: 5, cooldownDias: 365 * 3,
    titulo: "Bairro de Talento",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!(team && team.academy) && !(team.academy.talentoRegionalAte && state.currentDate < new Date(team.academy.talentoRegionalAte));
    },
    montarContexto() {
      return { clube: state.teams[state.userTeamId].name, teamId: state.userTeamId };
    },
    aplicarAutomatico() {
      const team = state.teams[state.userTeamId];
      team.academy.talentoRegionalAte = addDays(state.currentDate, 365 * 3).toISOString();
    },
    textos: [
      "Há uma zona perto do {clube} onde, de repente, todos os miúdos querem jogar hóquei em patins. Os olheiros da academia já perceberam — e vão andar por lá nos próximos anos.",
      "Algo está a acontecer na região do {clube}: uma geração inteira a crescer a jogar hóquei em patins. A academia do clube não vai deixar escapar esta oportunidade.",
      "Os olheiros do {clube} identificaram uma zona em ebulição — cada vez mais jovens talentosos a aparecer na área. Vale a pena redobrar a atenção nos próximos anos.",
    ],
  },
  // ---------------------------------------------------------------- Arbitragem
  {
    id: "arbitro-polemico", categoria: "arbitragem", raridade: "comum", peso: 10, cooldownDias: 30,
    titulo: "Árbitro Polémico",
    elegivel() {
      return !!nextUserFixture();
    },
    montarContexto() {
      const fx = nextUserFixture();
      const oppId = opponentOfFixture(fx, state.userTeamId);
      const opp = state.teams[oppId];
      this._expulsoes = 2 + Math.floor(Math.random() * 4);
      return { clube: opp ? opp.name : "o adversário", expulsoes: this._expulsoes, teamId: state.userTeamId };
    },
    textos: [
      "Antes do jogo com o {clube}: este árbitro já expulsou {expulsoes} jogadores do teu clube esta época. A tensão em campo promete não faltar.",
      "Um dado a reter antes do encontro com o {clube}: este árbitro já mostrou o cartão vermelho a {expulsoes} jogadores da tua equipa esta época. Vale a pena avisar o plantel.",
      "A antevisão do jogo com o {clube} traz um pormenor incómodo: {expulsoes} expulsões do teu clube já saíram do apito deste árbitro esta época.",
    ],
  },
  {
    id: "golo-fantasma", categoria: "arbitragem", raridade: "raro", peso: 6, cooldownDias: 120,
    titulo: "Golo Fantasma",
    elegivel() {
      return !!lastUserPlayedFixture();
    },
    montarContexto() {
      const fx = lastUserPlayedFixture();
      const oppId = opponentOfFixture(fx, state.userTeamId);
      const opp = state.teams[oppId];
      return { clube: opp ? opp.name : "o adversário", teamId: state.userTeamId };
    },
    aplicarAutomatico() {
      // Arco curto de seguimento (2 notícias, "o debate continua" alguns dias depois) — pedido
      // do utilizador ("a imprensa debate durante semanas"); verificado em
      // processNarrativeEventsForCurrentDate, antes de sortear um evento novo do dia.
      state.eventoGoloFantasmaSeguimento = {
        data: addDays(state.currentDate, 4 + Math.floor(Math.random() * 4)).toISOString(),
        titulo: "[Raro] Golo Fantasma — o debate continua",
        texto: "Passada mais de uma semana, a imprensa continua a discutir o golo polémico do último jogo. Uns dizem que a bola nunca entrou; outros juram o contrário. O árbitro mantém o silêncio.",
      };
    },
    textos: [
      "Ainda se fala do jogo com o {clube}: um golo polémico, que podia ter mudado o resultado, está a dar que falar na imprensa. Uns juram que a bola entrou; outros, que não.",
      "O golo mais discutido da época aconteceu no jogo com o {clube} — e continua sem consenso. A imagem não é conclusiva, e cada adepto vê o que quer ver.",
      "Passaram-se dias desde o jogo com o {clube}, e o golo polémico continua a ser assunto obrigatório nos cafés perto do estádio.",
    ],
  },

  // ================================================================================
  // FASE 2 — eventos ÉPICOS/LENDÁRIOS, sempre com pausa (excepto Geração de Ouro e Lesão que
  // Muda Carreira, cujo "resultado" é sempre um sorteio, nunca uma escolha do utilizador — ver
  // NARRATIVE_EVENTS acima na secção Fase 1 para a mesma distinção nos eventos automáticos).
  // ================================================================================
  {
    id: "fenomeno-local", categoria: "juvenis", raridade: "epico", peso: 6, cooldownDias: 365,
    titulo: "O Fenómeno Local",
    elegivel() {
      const team = state.teams[state.userTeamId];
      if (!team || !team.academy) return false;
      return ACADEMY_BRACKETS.some(b => team.academy.brackets[b] && team.academy.brackets[b].players.some(p => p.age >= 16 && (p.potential || 0) >= 17 && p.genero !== "F"));
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const pool = [];
      ACADEMY_BRACKETS.forEach(b => { if (team.academy.brackets[b]) pool.push(...team.academy.brackets[b].players.filter(p => p.age >= 16 && (p.potential || 0) >= 17 && p.genero !== "F")); });
      const p = pool[Math.floor(Math.random() * pool.length)];
      this._player = p; this._team = team;
      return { jogador: `<b>${p.name}</b>`, idade: p.age, teamId: team.id };
    },
    escolhas: [
      {
        label: "Promover já ao plantel sénior",
        aplicar() {
          const p = this._player, team = this._team; if (!p) return "";
          ACADEMY_BRACKETS.forEach(b => { const arr = team.academy.brackets[b] && team.academy.brackets[b].players; if (arr) { const i = arr.indexOf(p); if (i >= 0) arr.splice(i, 1); } });
          delete p.academyBracket;
          p.num = findFreeNumber(team);
          p.contrato = { ...(p.contrato || {}), salarioMensal: generateContract(overall(p), p.age, { potential: p.potential }).salarioMensal };
          team.players.push(p);
          p.clubeFormadorId = team.id;
          const queimou = Math.random() < 0.35;
          if (queimou) p.potential = clamp(p.potential - 2, overall(p), 20);
          return queimou
            ? "Foi promovido de imediato — mas a exposição repentina pode ter travado um pouco o seu crescimento (queima precoce)."
            : "Foi promovido de imediato, e parece estar a lidar bem com o salto de nível.";
        },
      },
      {
        label: "Deixar crescer nos escalões",
        aplicar() {
          const p = this._player; if (!p) return "";
          const estagnou = Math.random() < 0.25;
          p.potential = clamp(p.potential + (estagnou ? -1 : 1), overall(p), 20);
          return estagnou
            ? "Continua na formação — sem a pressão de competir a sério, o desenvolvimento abrandou ligeiramente."
            : "Continua na formação, a um ritmo tranquilo e sem sobressaltos.";
        },
      },
      {
        label: "Emprestar a outro clube",
        aplicar() {
          const p = this._player, team = this._team; if (!p) return "";
          ACADEMY_BRACKETS.forEach(b => { const arr = team.academy.brackets[b] && team.academy.brackets[b].players; if (arr) { const i = arr.indexOf(p); if (i >= 0) arr.splice(i, 1); } });
          delete p.academyBracket;
          p.clubeFormadorId = team.id;
          // Simplificação da Fase 2: sem escolha de clube de destino (fora de âmbito) — ganha
          // rodagem "fora" simulada como um pequeno ganho de potencial, e sai do plantel/academia
          // (mesmo destino que os jovens não promovidos do Sub-19, ver runAcademySub19ExitPass).
          p.potential = clamp(p.potential + 1, overall(p), 20);
          archiveInactivePlayer(p, "emprestado-fenomeno-local");
          return "Foi emprestado para ganhar rodagem longe da pressão do primeiro plantel. O clube vai acompanhar a evolução à distância.";
        },
      },
    ],
    textos: [
      "Os olheiros não têm dúvidas: {jogador}, de apenas {idade} anos, joga a um nível muito acima da sua idade. A pergunta já não é «se», mas «quando».",
      "Há já quem compare {jogador} aos melhores que passaram pela academia. Aos {idade} anos, entrega desempenhos que fariam inveja a jogadores dez anos mais velhos.",
      "{jogador} tornou-se o nome mais falado na formação. Um talento assim não aparece todos os anos — e o clube sabe disso.",
    ],
  },
  {
    id: "motim-dos-veteranos", categoria: "balneario", raridade: "epico", peso: 6, cooldownDias: 200,
    titulo: "Motim dos Veteranos",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!team && team.players.filter(p => p.age >= 27 && (p.satisfacao != null ? p.satisfacao : 70) < 65).length >= 3;
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const veteranos = team.players.filter(p => p.age >= 27 && (p.satisfacao != null ? p.satisfacao : 70) < 65).sort((a, b) => overall(b) - overall(a)).slice(0, 4);
      this._veteranos = veteranos; this._team = team;
      return { jogadores: veteranos.map(p => playerLinkHtml(team.id, p)).join(", "), teamId: team.id };
    },
    escolhas: [
      {
        label: "Ceder às exigências dos veteranos",
        aplicar() {
          const team = this._team;
          this._veteranos.forEach(p => { p.moral = clamp((p.moral != null ? p.moral : 70) + 15, 0, 100); p.satisfacao = clamp((p.satisfacao != null ? p.satisfacao : 70) + 15, 0, 100); });
          if (team.financeiro) team.financeiro.saldo = (team.financeiro.saldo || 0) - Math.round(15000 + Math.random() * 15000);
          const bal = ensureBalneario(team); if (bal) bal.coesao = clamp(bal.coesao + 3, 3, 99);
          return "Aceitaste ouvir os veteranos e fizeste alguns ajustes. O ambiente no balneário melhorou, mas custou dinheiro à direcção.";
        },
      },
      {
        label: "Manter o rumo",
        aplicar() {
          const pior = this._veteranos.slice().sort((a, b) => (a.satisfacao != null ? a.satisfacao : 70) - (b.satisfacao != null ? b.satisfacao : 70))[0];
          if (!pior) return "Mantiveste o rumo, apesar do descontentamento.";
          pior.satisfacao = clamp((pior.satisfacao != null ? pior.satisfacao : 70) - 15, 0, 100);
          pior.transferListado = true;
          const bal = ensureBalneario(this._team); if (bal) bal.coesao = clamp(bal.coesao - 4, 3, 99);
          return `Mantiveste o rumo. ${pior.name} não escondeu o descontentamento e pediu para sair — foi colocado na lista de transferências.`;
        },
      },
      {
        label: "Punir o instigador",
        aplicar() {
          const team = this._team;
          const instigador = this._veteranos[0];
          if (instigador) instigador.moral = clamp((instigador.moral != null ? instigador.moral : 70) - 20, 0, 100);
          team.players.forEach(p => { if (p !== instigador) p.moral = clamp((p.moral != null ? p.moral : 70) + 3, 0, 100); });
          const bal = ensureBalneario(team); if (bal) bal.coesao = clamp(bal.coesao - 2, 3, 99);
          return instigador
            ? `${instigador.name} foi afastado do onze como exemplo. A disciplina no balneário melhorou, mas a relação com ele ficou danificada.`
            : "A disciplina no balneário melhorou.";
        },
      },
    ],
    textos: [
      "{jogadores} não escondem o descontentamento com a tua gestão. O ambiente no balneário está tenso — como vais reagir?",
      "Há dias que o balneário anda mais frio do que o habitual. {jogadores} são os principais focos de descontentamento, e algo tem de mudar.",
      "Chegam sinais preocupantes do balneário: {jogadores} puseram em causa a tua gestão em conversas privadas. Uma decisão tua pode acalmar ou piorar tudo.",
    ],
  },
  {
    id: "medico-revolucionario", categoria: "lesoes", raridade: "epico", peso: 5, cooldownDias: 200,
    titulo: "Médico Revolucionário",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!team && team.players.some(p => (p.diasLesao || 0) >= 20);
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const p = team.players.filter(p => (p.diasLesao || 0) >= 20).sort((a, b) => (b.diasLesao || 0) - (a.diasLesao || 0))[0];
      this._player = p;
      return { jogador: playerLinkHtml(team.id, p), teamId: team.id };
    },
    escolhas: [
      {
        label: "Operação rápida (arrisca uma recaída)",
        aplicar() {
          const p = this._player; if (!p) return "";
          if (Math.random() < 0.3) { p.diasLesao = Math.round((p.diasLesao || 20) * 1.4); return `A operação teve complicações — ${p.name} vai demorar ainda mais tempo a recuperar.`; }
          p.diasLesao = Math.max(1, Math.round((p.diasLesao || 20) * 0.5));
          return `A operação correu bem — ${p.name} deve recuperar bastante mais depressa do que o previsto.`;
        },
      },
      {
        label: "Recuperação tradicional",
        aplicar() { return this._player ? `Optaste pelo caminho seguro — ${this._player.name} segue o plano de recuperação habitual, sem sobressaltos.` : ""; },
      },
      {
        label: "Tratamento experimental (resultado imprevisível)",
        aplicar() {
          const p = this._player; if (!p) return "";
          const roll = Math.random();
          if (roll < 0.25) { p.diasLesao = Math.max(1, Math.round((p.diasLesao || 20) * 0.3)); return `Resultado surpreendente: ${p.name} recuperou muito mais depressa do que qualquer médico esperava.`; }
          if (roll < 0.55) { p.diasLesao = Math.round((p.diasLesao || 20) * 1.6); return `O tratamento experimental não correu como esperado — a recuperação de ${p.name} atrasou-se.`; }
          return `O tratamento experimental não teve efeito visível, para o bem e para o mal — ${p.name} continua o plano normal.`;
        },
      },
    ],
    textos: [
      "O departamento clínico traz uma proposta pouco habitual para acelerar a recuperação de {jogador}. A decisão é tua.",
      "Surge uma oportunidade rara: um especialista externo propõe um tratamento pouco convencional para {jogador}. Vale o risco?",
      "O departamento médico apresenta três caminhos possíveis para a recuperação de {jogador} — cada um com o seu risco.",
    ],
  },
  {
    id: "crise-financeira", categoria: "financeiras", raridade: "epico", peso: 6, cooldownDias: 250,
    titulo: "Crise Financeira",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!(team && team.financeiro && (team.financeiro.saldo || 0) < 30000);
    },
    montarContexto() { return { clube: state.teams[state.userTeamId].name, teamId: state.userTeamId }; },
    escolhas: [
      {
        label: "Vender jogadores",
        aplicar() {
          const team = state.teams[state.userTeamId];
          const candidatos = team.players.filter(p => !p.titular).sort((a, b) => overall(b) - overall(a)).slice(0, 2);
          candidatos.forEach(p => { p.transferListado = true; p.satisfacao = clamp((p.satisfacao != null ? p.satisfacao : 70) - 10, 0, 100); });
          const ganho = Math.round(20000 + Math.random() * 20000);
          if (team.financeiro) team.financeiro.saldo = (team.financeiro.saldo || 0) + ganho;
          return `A direcção autorizou a venda de jogadores para equilibrar as contas — ${candidatos.length} foram colocados na lista de transferências, e uma injecção imediata de ${ganho.toLocaleString("pt-PT")}€ alivia o caixa.`;
        },
      },
      {
        label: "Cortar salários",
        aplicar() {
          const team = state.teams[state.userTeamId];
          team.players.forEach(p => {
            if (p.contrato) p.contrato.salarioMensal = Math.round((p.contrato.salarioMensal || 0) * 0.9);
            p.satisfacao = clamp((p.satisfacao != null ? p.satisfacao : 70) - 8, 0, 100);
            p.moral = clamp((p.moral != null ? p.moral : 70) - 5, 0, 100);
          });
          return "Os salários de todo o plantel foram reduzidos em 10%. As contas agradecem — o balneário, nem por isso.";
        },
      },
      {
        label: "Apostar na formação",
        aplicar() {
          const team = state.teams[state.userTeamId];
          if (team.financeiro) team.financeiro.orcamentoTransferencias = Math.round((team.financeiro.orcamentoTransferencias || 0) * 0.5);
          if (team.academy) team.academy.talentoRegionalAte = addDays(state.currentDate, 365).toISOString();
          return "A direcção decidiu reduzir ainda mais o orçamento para reforços e apostar tudo na academia. Os resultados só se vão ver daqui a uns anos.";
        },
      },
    ],
    textos: [
      "Más notícias da direcção do {clube}: o patrocinador principal abandonou o barco, e as contas ficaram muito apertadas. Uma decisão difícil não pode esperar.",
      "A direcção do {clube} convoca-te com urgência: sem o apoio do patrocinador que acabou de sair, o clube precisa de uma solução imediata.",
      "O orçamento do {clube} sofreu um golpe sério com a saída de um patrocinador. Alguma coisa vai ter de ceder.",
    ],
  },
  {
    id: "lesao-que-muda-carreira", categoria: "lesoes", raridade: "epico", peso: 4, cooldownDias: 300,
    titulo: "Lesão que Muda Carreira",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!team && team.players.some(p => (p.diasLesao || 0) >= 40);
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const p = team.players.filter(p => (p.diasLesao || 0) >= 40).sort((a, b) => (b.diasLesao || 0) - (a.diasLesao || 0))[0];
      this._player = p;
      const roll = Math.random();
      // ~15% nunca recupera plenamente, ~50% recuperação lenta, ~35% regressa ainda melhor.
      this._desfecho = roll < 0.15 ? "nunca" : (roll < 0.65 ? "lenta" : "melhor");
      return { jogador: playerLinkHtml(team.id, p), teamId: team.id };
    },
    aplicarAutomatico() {
      const p = this._player; if (!p) return;
      if (this._desfecho === "nunca") {
        // Simplificação: sem sistema de reforma forçada por lesão, uma paragem muito longa
        // (10 anos de calendário) funciona, na prática, como "nunca mais volta a este nível".
        p.diasLesao = 3650;
        p.potential = clamp(overall(p), 0, 20);
      } else if (this._desfecho === "lenta") {
        p.diasLesao = Math.round((p.diasLesao || 40) * 1.8);
      } else {
        p.diasLesao = Math.round((p.diasLesao || 40) * 0.6);
        p.potential = clamp((p.potential || overall(p)) + 2, overall(p), 20);
      }
    },
    textos() {
      if (this._desfecho === "nunca") return [
        "O diagnóstico não podia ser pior: {jogador} sofreu uma rotura grave, e o departamento médico admite, em privado, que a carreira pode nunca mais ser a mesma.",
        "É a pior notícia possível vinda do departamento médico: a lesão de {jogador} é grave, e há sérias dúvidas sobre se voltará ao nível anterior.",
      ];
      if (this._desfecho === "lenta") return [
        "{jogador} sofreu uma rotura grave. O departamento médico é claro: vai ser um caminho longo, sem atalhos possíveis.",
        "A lesão de {jogador} é séria. A recuperação vai exigir paciência — não há forma de acelerar este processo.",
      ];
      return [
        "{jogador} sofreu uma rotura grave — más notícias à primeira vista. Mas o departamento médico está surpreendido com a forma como o corpo está a responder ao tratamento.",
        "A lesão de {jogador} parecia o fim de um ciclo. Em vez disso, o processo de recuperação está a transformar-se numa história de superação.",
      ];
    },
  },
  {
    id: "geracao-de-ouro", categoria: "academia", raridade: "lendario", peso: 3, cooldownDias: 365 * 8,
    titulo: "Geração de Ouro",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!(team && team.academy && team.academy.brackets && team.academy.brackets.sub13);
    },
    montarContexto() { return { clube: state.teams[state.userTeamId].name, teamId: state.userTeamId }; },
    aplicarAutomatico() {
      const team = state.teams[state.userTeamId];
      const b = team.academy.brackets.sub13;
      if (!b) return;
      const gr = generateAcademyPlayerForBracket(team, "sub13", b.players.length, null, true);
      const defesa = generateAcademyPlayerForBracket(team, "sub13", b.players.length + 1, null, false);
      const avancado = generateAcademyPlayerForBracket(team, "sub13", b.players.length + 2, null, false);
      [gr, defesa, avancado].forEach(p => { p.potential = 19; });
      b.players.push(gr, defesa, avancado);
    },
    textos: [
      "Aconteceu o que poucos directores desportivos vivem mais do que uma vez na carreira: a academia do {clube} produziu, na mesma geração, um guarda-redes, um defesa e um avançado de nível excepcional. Épocas como esta definem clubes.",
      "A formação do {clube} atravessa, este ano, um momento raríssimo — três jogadores de qualidade rara saem da academia ao mesmo tempo, em três posições-chave. O futuro do clube nunca pareceu tão risonho.",
      "Uma vez em vinte épocas, talvez menos: a academia do {clube} entrega, de uma só vez, um guarda-redes, um defesa e um avançado de craveira superior. O clube sabe que tem nas mãos algo especial.",
    ],
  },
  // FASE 3 (2026-09-28) — "Histórias Longas": arcos persistentes multi-época. Só a CONSAGRAÇÃO de
  // cada arco (tornar-se "a lenda"/"uma dinastia", ou o eco de uma dinastia ainda a esbater-se)
  // nasce da rolagem diária normal, porque essa condição é contínua (pode verificar-se em
  // qualquer dia). Os restantes capítulos de cada arco (um título com a lenda em campo, a reforma
  // da lenda, o fim de uma dinastia) estão ligados a acontecimentos discretos e reais do jogo, e
  // por isso disparam por chamada directa a partir do sítio exacto onde acontecem — ver
  // narrativeLendaTitulo/narrativeLendaReforma/narrativeDinastiaFimDeEra, mais abaixo, chamadas
  // respectivamente de awardClubTitle (08-evolucao-jogadores.js), processRetirements
  // (01-nucleo.js) e switchManagerToClub (04-financas.js).
  {
    id: "a-lenda-consagracao", categoria: "lenda", raridade: "lendario", peso: 3, cooldownDias: 365 * 10,
    titulo: "A Lenda",
    elegivel() {
      if (state.lendaJogadorId) return false;
      const team = state.teams[state.userTeamId];
      return !!(team && team.players.some(p => p.clubeFormadorId === team.id && p.age >= 29 && ((p.career && p.career.jogos || 0) + (p.season && p.season.jogos || 0)) >= 180));
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const candidatos = team.players.filter(p => p.clubeFormadorId === team.id && p.age >= 29 && ((p.career && p.career.jogos || 0) + (p.season && p.season.jogos || 0)) >= 180);
      candidatos.sort((a, b) => ((b.career && b.career.jogos || 0) + (b.season && b.season.jogos || 0)) - ((a.career && a.career.jogos || 0) + (a.season && a.season.jogos || 0)));
      const p = candidatos[0];
      this._player = p;
      const jogos = (p.career && p.career.jogos || 0) + (p.season && p.season.jogos || 0);
      return { jogador: playerLinkHtml(team.id, p), clube: team.name, jogos, idade: p.age };
    },
    aplicarAutomatico() {
      const p = this._player; if (!p) return;
      state.lendaJogadorId = p.id;
      p.lendaAnunciadaEm = state.season;
    },
    textos: [
      "Há jogadores que passam por um clube. E há {jogador}, que se tornou parte dele. Aos {idade} anos e com {jogos} jogos, {jogador} é hoje mais do que um jogador — é uma instituição no {clube}.",
      "{jogos} jogos com a camisola do {clube}, uma carreira inteira construída num só sítio. {jogador} deixou de ser apenas um jogador: tornou-se lenda.",
      "Não há estatística que explique tudo o que {jogador} significa para o {clube}. {jogos} jogos depois, o nome já está escrito na história do clube.",
    ],
  },
  {
    id: "o-vilao", categoria: "transferencias", raridade: "raro", peso: 6, cooldownDias: 120,
    titulo: "O Vilão",
    // player.vilaoDoClube/vilaoClubeId são marcados no momento da transferência (ver
    // applyAcceptedOffer, 04-financas.js) — este evento só faz o reencontro acontecer sempre que
    // o calendário voltar a juntar as duas equipas.
    elegivel() {
      const fx = nextUserFixture(); if (!fx) return false;
      const opId = opponentOfFixture(fx, state.userTeamId); if (!opId) return false;
      return Object.values(state.teams).some(t => (t.players || []).some(p => p.vilaoDoClube && p.vilaoClubeId === opId));
    },
    montarContexto() {
      const fx = nextUserFixture();
      const opId = opponentOfFixture(fx, state.userTeamId);
      const time = state.teams[opId];
      let alvo = null;
      Object.values(state.teams).forEach(t => (t.players || []).forEach(p => { if (!alvo && p.vilaoDoClube && p.vilaoClubeId === opId) alvo = p; }));
      this._player = alvo;
      alvo.vilaoEncontros = (alvo.vilaoEncontros || 0) + 1;
      this._primeiroEncontro = alvo.vilaoEncontros === 1;
      return { jogador: playerLinkHtml(opId, alvo), clube: time ? time.name : "", clubeAntigo: (state.teams[state.userTeamId] || {}).name || "" };
    },
    textos(ctx) {
      return this._primeiroEncontro ? [
        "O regresso mais aguardado da jornada: {jogador} vai defrontar o {clubeAntigo} pela primeira vez desde a saída. Os adeptos já sabem o que vão gritar.",
        "Não é um jogo qualquer — {jogador} está de volta ao antigo clube, agora do lado errado da bancada. A rivalidade nasceu hoje.",
        "Há reencontros que se esperam com um misto de curiosidade e ressentimento. Este é um deles: {jogador} frente ao {clubeAntigo}, pela primeira vez desde que saiu.",
      ] : [
        "Mais um capítulo da rivalidade: {jogador} volta a defrontar o {clubeAntigo}. Os adeptos não esqueceram — e ele sabe disso.",
        "Já lá vão vários encontros, mas o ambiente continua o mesmo sempre que {jogador} pisa o relvado contra o {clubeAntigo}.",
        "A história entre {jogador} e o {clubeAntigo} continua a escrever-se. Mais um capítulo, o mesmo calor de sempre.",
      ];
    },
  },
  {
    id: "a-dinastia-nascimento", categoria: "dinastia", raridade: "lendario", peso: 2, cooldownDias: 365 * 10,
    titulo: "A Dinastia",
    elegivel() {
      const team = state.teams[state.userTeamId];
      if (!team || team.dinastiaAnunciada) return false;
      const g = ensureManagerCareer();
      return Number.isFinite(g.epocaInicioClube) && (state.season - g.epocaInicioClube) >= NARRATIVE_DINASTIA_TEMPORADAS;
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      const g = ensureManagerCareer();
      const temporadas = state.season - g.epocaInicioClube;
      this._team = team; this._temporadas = temporadas;
      return { clube: team.name, temporadas };
    },
    aplicarAutomatico() {
      const team = this._team; if (!team) return;
      team.dinastiaAnunciada = true;
      team.dinastiaEpocaInicio = state.season - this._temporadas;
      team.dinastiaEstiloSnapshot = { ...(activeCoachingStats(team) || {}) };
    },
    textos: [
      "Já lá vão {temporadas} épocas no comando técnico do {clube} — não é mais um mandato, é uma era. A tua marca já se sente em cada decisão do clube.",
      "{temporadas} épocas ao leme do {clube}. Já não se fala apenas de resultados: fala-se de uma identidade, construída época após época.",
      "Poucos treinadores duram {temporadas} épocas no mesmo clube. No {clube}, já não és só o treinador — és parte da história recente.",
    ],
  },
  {
    id: "eco-da-dinastia", categoria: "dinastia", raridade: "raro", peso: 3, cooldownDias: 150,
    titulo: "Eco de uma Dinastia",
    elegivel() {
      const team = state.teams[state.userTeamId];
      return !!(team && team.legadoDinastia && team.legadoDinastia.forca > 0.15);
    },
    montarContexto() {
      const team = state.teams[state.userTeamId];
      return { clube: team.name };
    },
    textos: [
      "Passaram-se épocas, mas ainda hoje se nota: a forma como o {clube} joga tem a marca de quem por aqui passou e deixou escola.",
      "Há decisões, dentro e fora do relvado, que ainda hoje seguem uma lógica antiga no {clube}. Um legado não desaparece de um dia para o outro.",
      "Quem acompanha o {clube} de perto ainda reconhece traços de uma era passada. Alguns legados demoram a esbater-se.",
    ],
  },
];

// Nº de épocas seguidas no comando técnico do MESMO clube a partir do qual o mandato do
// utilizador passa a ser anunciado como "uma dinastia" (ver a-dinastia-nascimento, acima, e
// narrativeDinastiaFimDeEra, mais abaixo).
const NARRATIVE_DINASTIA_TEMPORADAS = 8;

// Notícia directa (fora da rolagem/cooldown do catálogo) — mesmo espírito do seguimento do Golo
// Fantasma: pushNews + registerNarrativeHistorico sem passar por fireNarrativeEvent, porque o
// contexto já é conhecido no sítio exacto da chamada (não há elegivel()/montarContexto() a
// recalcular aqui).
function pushDirectNarrativeNews(id, categoria, raridade, titulo, texto, teamId) {
  const tituloFinal = NARRATIVE_RARITY_BADGE[raridade] + titulo;
  pushNews(state.currentDate, texto, "evento", tituloFinal, { teamId: teamId || state.userTeamId });
  registerNarrativeHistorico({ id, categoria, raridade }, tituloFinal, texto);
}

// Chamado por awardClubTitle (08-evolucao-jogadores.js) sempre que o clube do utilizador conquista
// um título com "a lenda" ainda no plantel — mais um capítulo do arco, nunca repete a consagração.
function narrativeLendaTitulo(team, player, tituloLabel) {
  const jogos = (player.career && player.career.jogos || 0) + (player.season && player.season.jogos || 0);
  const numTitulos = Array.isArray(player.titulos) ? player.titulos.length : 0;
  const variantes = [
    `Mais um título para {jogador}: o {clube} venceu ${escapeHtml(tituloLabel)}, e a lenda continua a escrever-se — já são ${numTitulos} títulos na carreira.`,
    `A lenda do {clube} soma mais um troféu. {jogador} celebra ${escapeHtml(tituloLabel)} com a mesma fome de sempre, depois de ${jogos} jogos ao serviço do clube.`,
    `Não é o primeiro, e provavelmente não será o último: {jogador} volta a erguer um troféu pelo {clube} — ${escapeHtml(tituloLabel)} no currículo de uma carreira que já é história.`,
  ];
  const texto = fillNarrativeTemplate(variantes[Math.floor(Math.random() * variantes.length)], { jogador: playerLinkHtml(team.id, player), clube: team.name });
  pushDirectNarrativeNews("a-lenda-titulo", "lenda", "epico", "A Lenda", texto, team.id);
}

// Chamado por processRetirements (01-nucleo.js) quando quem se reforma é "a lenda" do clube do
// utilizador — fecha o arco (state.lendaJogadorId volta a null; pode nascer um novo mais tarde).
function narrativeLendaReforma(team, player) {
  const jogos = (player.career && player.career.jogos || 0) + (player.season && player.season.jogos || 0);
  const golos = (player.career && player.career.golos || 0) + (player.season && player.season.golos || 0);
  const numTitulos = Array.isArray(player.titulos) ? player.titulos.length : 0;
  const variantes = [
    `Termina hoje uma carreira inteira dedicada ao {clube}: ${escapeHtml(player.name)} pendura as botas depois de ${jogos} jogos, ${golos} golos e ${numTitulos} títulos. Poucos deixarão uma marca assim.`,
    `${escapeHtml(player.name)} diz adeus ao hóquei em patins tal como sempre o viveu — de {clube}. ${jogos} jogos e ${numTitulos} títulos depois, fica um nome que o clube não vai esquecer.`,
    `Uma era chega ao fim no {clube}: ${escapeHtml(player.name)} reforma-se depois de ${jogos} jogos ao serviço do clube que o viu crescer. Nem todos têm a sorte de escrever uma história assim, do início ao fim.`,
  ];
  const texto = fillNarrativeTemplate(variantes[Math.floor(Math.random() * variantes.length)], { clube: team.name });
  pushDirectNarrativeNews("a-lenda-reforma", "lenda", "lendario", "A Lenda", texto, team.id);
  if (state.lendaJogadorId === player.id) state.lendaJogadorId = null;
}

// Chamado por switchManagerToClub (04-financas.js) quando o gestor humano deixa um clube onde uma
// "dinastia" já tinha sido anunciada — guarda um eco duradouro do seu estilo (team.legadoDinastia),
// que se apaga lentamente (decayLegadosDinastia, chamado diariamente) em vez de desaparecer no
// instante em que o próximo treinador chega.
function narrativeDinastiaFimDeEra(oldTeam, gestor, date) {
  const inicio = Number.isFinite(oldTeam.dinastiaEpocaInicio) ? oldTeam.dinastiaEpocaInicio : gestor.epocaInicioClube;
  const temporadas = Math.max(1, state.season - inicio);
  oldTeam.legadoDinastia = { estilo: oldTeam.dinastiaEstiloSnapshot ? { ...oldTeam.dinastiaEstiloSnapshot } : null, temporadas, epocaFim: state.season, forca: 1 };
  const variantes = [
    `Termina uma era no {clube}. Depois de ${temporadas} épocas a moldar o clube à sua imagem, o comando técnico muda de mãos — mas o estilo que aqui ficou não desaparece de um dia para o outro.`,
    `Fim de uma dinastia no {clube}: ${temporadas} épocas de trabalho deixam uma marca que vai demorar a esbater-se, seja lá quem vier a seguir.`,
    `O {clube} despede-se de uma era de ${temporadas} épocas. Nem tudo o que ficou construído se perde com a saída — algumas coisas ficam para além de quem as criou.`,
  ];
  const texto = fillNarrativeTemplate(variantes[Math.floor(Math.random() * variantes.length)], { clube: oldTeam.name });
  pushDirectNarrativeNews("a-dinastia-fim-de-era", "dinastia", "lendario", "Fim de uma Era", texto, oldTeam.id);
}

// Esbatimento lento do legado de uma dinastia (Fase 3) — chamado uma vez por dia a partir de
// processNarrativeEventsForCurrentDate; desvanece ao longo de ~8 épocas (a mesma duração mínima
// exigida para uma dinastia nascer) até deixar de ter qualquer efeito narrativo (eco-da-dinastia
// deixa de ser elegível) e ser removido.
function decayLegadosDinastia() {
  Object.values(state.teams).forEach(team => {
    if (!team.legadoDinastia) return;
    team.legadoDinastia.forca -= 1 / (8 * 365);
    if (team.legadoDinastia.forca <= 0) team.legadoDinastia = null;
  });
}

function registerNarrativeHistorico(ev, titulo, texto) {
  state.eventosHistorico.unshift({ id: ev.id, categoria: ev.categoria, raridade: ev.raridade, data: state.currentDate.toISOString(), titulo, texto, season: state.season });
  if (state.eventosHistorico.length > 150) state.eventosHistorico.length = 150;
}

// Fase 4 (2026-09-28) — aba "Histórico de Eventos" (#viewHistorico/#eventosHistoricoList, ver
// index.html e setView em 01-nucleo.js): lista state.eventosHistorico, filtrável por raridade.
// Mesmo padrão do filtro de categoria da caixa de e-mail (newsInboxFilterKind, renderNews em
// 01-nucleo.js) — uma variável de UI simples, nunca persistida no save.
let eventosHistoricoFilterRaridade = null;
const NARRATIVE_RARITY_LABEL = { comum: "Comum", raro: "Raro", epico: "Épico", lendario: "Lendário" };
const NARRATIVE_RARITY_COLOR = { comum: "#7f8c8d", raro: "#2980b9", epico: "#8e44ad", lendario: "#f39c12" };

function renderEventosHistorico() {
  const box = document.getElementById("eventosHistoricoList");
  if (!box) return;
  ensureNarrativeEventState();
  if (!state.eventosHistorico.length) {
    box.innerHTML = '<div class="feed-empty" style="font-style:italic;">Ainda não há eventos — vão surgindo ao longo da carreira, com probabilidade baixa a cada dia.</div>';
    return;
  }
  const raridadesPresentes = NARRATIVE_RARITY_ORDER.filter(r => state.eventosHistorico.some(h => h.raridade === r));
  const filterHtml = `<div class="inbox-toolbar"><select id="eventosHistoricoFilterSelect" class="inbox-filter">
    <option value="">Todas as raridades</option>
    ${raridadesPresentes.map(r => `<option value="${r}"${eventosHistoricoFilterRaridade === r ? " selected" : ""}>${NARRATIVE_RARITY_LABEL[r] || r}</option>`).join("")}
  </select></div>`;
  const visible = eventosHistoricoFilterRaridade ? state.eventosHistorico.filter(h => h.raridade === eventosHistoricoFilterRaridade) : state.eventosHistorico;
  const style = newsSenderStyle("evento");
  // O título já vem com o prefixo de raridade ("[Lendário] ...", ver NARRATIVE_RARITY_BADGE em
  // fireNarrativeEvent/pushDirectNarrativeNews) — aqui a raridade já tem o seu próprio "pill"
  // colorido, por isso o prefixo é retirado para não aparecer duplicado.
  const listHtml = visible.length ? visible.map(h => `
    <div class="narrative-historico-item">
      <div class="narrative-historico-head">
        <span class="email-avatar" style="background:${style.color};" aria-hidden="true">${style.initials}</span>
        <span class="narrative-raridade-pill" style="background:${NARRATIVE_RARITY_COLOR[h.raridade] || "#7f8c8d"};">${NARRATIVE_RARITY_LABEL[h.raridade] || h.raridade}</span>
        <span class="narrative-historico-data">${fmtDateShort(h.data)} · Época ${seasonLabel(h.season)}</span>
      </div>
      <div class="narrative-historico-titulo">${escapeHtml(String(h.titulo || "").replace(/^\[[^\]]+\]\s*/, ""))}</div>
      <div class="narrative-historico-texto">${h.texto}</div>
    </div>
  `).join("") : '<div class="feed-empty" style="font-style:italic;">Sem eventos nesta raridade.</div>';
  box.innerHTML = `${filterHtml}<div class="narrative-historico-list">${listHtml}</div>`;
  const sel = document.getElementById("eventosHistoricoFilterSelect");
  if (sel) sel.addEventListener("change", () => { eventosHistoricoFilterRaridade = sel.value || null; renderEventosHistorico(); });
}

// Fase 2 (2026-09-28): eventos épicos/lendários com "escolhas" não resolvem de imediato — ficam
// pendentes (state.pendingNarrativeEvent) até o utilizador escolher no #eventoNarrativoModal
// (ver openEventoNarrativoModal/resolveNarrativeEventChoice, e os 2 pontos de pausa em
// 09-fluxo-epoca.js: o handler do #continuarBtn e runContinuarAutoAdvance). O cooldown do
// evento é marcado já aqui, no momento em que fica pendente — não quando é resolvido — para a
// rolagem diária nunca voltar a propor o mesmo evento enquanto uma decisão está por tomar.
function fireNarrativeEvent(ev) {
  const ctx = ev.montarContexto ? ev.montarContexto() : {};
  const texto = fillNarrativeTemplate(pickNarrativeText(ev, ctx), ctx);
  const titulo = NARRATIVE_RARITY_BADGE[ev.raridade] + (ev.titulo || deriveNewsTitle(texto));
  state.eventosCooldown[ev.id] = addDays(state.currentDate, ev.cooldownDias || NARRATIVE_DEFAULT_COOLDOWN_DIAS).toISOString();
  if (Array.isArray(ev.escolhas) && ev.escolhas.length) {
    state.pendingNarrativeEvent = { id: ev.id, ctx, titulo, texto, teamId: (ctx && ctx.teamId) || state.userTeamId };
    updateContinuarBtnLabel();
    return;
  }
  pushNews(state.currentDate, texto, "evento", titulo, { teamId: (ctx && ctx.teamId) || state.userTeamId });
  if (ev.aplicarAutomatico) ev.aplicarAutomatico(ctx);
  registerNarrativeHistorico(ev, titulo, texto);
}

function openEventoNarrativoModal() {
  const pending = state.pendingNarrativeEvent;
  const modal = document.getElementById("eventoNarrativoModal");
  if (!pending || !modal) return;
  const ev = NARRATIVE_EVENTS.find(e => e.id === pending.id);
  document.getElementById("eventoNarrativoTitulo").textContent = pending.titulo;
  document.getElementById("eventoNarrativoTexto").innerHTML = pending.texto;
  const opcoesEl = document.getElementById("eventoNarrativoOpcoes");
  opcoesEl.innerHTML = (ev && ev.escolhas || []).map((escolha, idx) =>
    `<button class="btn btn-primary evento-narrativo-escolha-btn" data-idx="${idx}">${escolha.label}</button>`
  ).join("");
  opcoesEl.querySelectorAll(".evento-narrativo-escolha-btn").forEach(btn => {
    btn.addEventListener("click", () => resolveNarrativeEventChoice(parseInt(btn.getAttribute("data-idx"), 10)));
  });
  modal.classList.remove("hidden");
}
function closeEventoNarrativoModal() {
  const modal = document.getElementById("eventoNarrativoModal");
  if (modal) modal.classList.add("hidden");
}

// Aplica a escolha do utilizador, publica a notícia final (situação + decisão + desfecho) e
// liberta o "Continuar". escolha.aplicar(ctx) pode devolver uma frase curta a descrever o
// desfecho — quando devolve nada, a notícia fica só com a situação e a decisão tomada.
function resolveNarrativeEventChoice(escolhaIdx) {
  const pending = state.pendingNarrativeEvent;
  if (!pending) return;
  const ev = NARRATIVE_EVENTS.find(e => e.id === pending.id);
  const escolha = ev && ev.escolhas && ev.escolhas[escolhaIdx];
  if (!ev || !escolha) { state.pendingNarrativeEvent = null; closeEventoNarrativoModal(); updateContinuarBtnLabel(); return; }
  // .call(ev, ...): escolha.aplicar é lido de ev.escolhas[idx], por isso uma chamada direta
  // escolha.aplicar(...) teria "this" a apontar para o objecto da ESCOLHA, não para o evento —
  // e é em "this" (ev) que montarContexto guarda o que calculou (this._player, this._team, ...).
  // Sem o .call(ev, ...) explícito, todo o efeito de qualquer escolha ficava invisível
  // (this._player undefined dentro de aplicar()), silenciosamente sem efeito nalguns casos e a
  // lançar exceção nos que não se protegiam com "if(!p) return".
  // Correção (2026-10-16): depois de carregar um save, o contexto em memória do evento
  // (this._team, this._player, ...) já não existe — algumas escolhas lançavam exceção, o evento
  // nunca era resolvido e cada "Continuar" reabria o modal (carreira bloqueada). Uma exceção
  // passa a resolver o evento sem efeito em vez de o deixar pendente para sempre.
  let desfecho = "";
  try { desfecho = escolha.aplicar ? escolha.aplicar.call(ev, pending.ctx) : ""; }
  catch(e){ console.warn("[HM2027] evento narrativo sem contexto (save carregado?)", pending.id, e); desfecho = ""; }
  const textoFinal = `${pending.texto}<br><br><b>Decisão: ${escolha.label}.</b>${desfecho ? " " + desfecho : ""}`;
  pushNews(state.currentDate, textoFinal, "evento", pending.titulo, { teamId: pending.teamId });
  registerNarrativeHistorico(ev, pending.titulo, textoFinal);
  state.pendingNarrativeEvent = null;
  closeEventoNarrativoModal();
  updateContinuarBtnLabel();
}

// Auxiliar de teste (exposto em __HM2027_TEST__): dispara um evento do catálogo pelo id,
// ignorando a probabilidade diária e o cooldown — só a elegibilidade continua a ser respeitada
// (sem ela, um teste podia disparar um evento em contexto impossível, ex. sem academia). Usado
// pelos scripts Playwright para validar texto+efeito+persistência de cada evento sem depender
// da RNG diária.
function forceNarrativeEventById(id) {
  ensureNarrativeEventState();
  const ev = NARRATIVE_EVENTS.find(e => e.id === id);
  if (!ev) return false;
  if (ev.elegivel && !ev.elegivel()) return false;
  fireNarrativeEvent(ev);
  return true;
}

function processNarrativeEventsForCurrentDate() {
  ensureNarrativeEventState();
  // Fase 3: o esbatimento do legado de uma dinastia é contínuo e independente de qualquer
  // decisão pendente — corre sempre, mesmo nos dias em que nada mais é sorteado.
  decayLegadosDinastia();
  // Fase 2: enquanto houver uma decisão por tomar (state.pendingNarrativeEvent), não se rola
  // nada de novo — nem sequer o seguimento do Golo Fantasma, que pode esperar mais um dia.
  if (state.pendingNarrativeEvent) return;
  // Seguimento pendente do Golo Fantasma — verificado antes de sortear um evento novo, para não
  // perder a segunda notícia por o dia já ter "gasto" o seu evento novo (um seguimento agendado
  // não conta como evento novo, não está sujeito ao limite de um por dia).
  if (state.eventoGoloFantasmaSeguimento && state.currentDate >= new Date(state.eventoGoloFantasmaSeguimento.data)) {
    const seg = state.eventoGoloFantasmaSeguimento;
    pushNews(state.currentDate, seg.texto, "evento", seg.titulo, { teamId: state.userTeamId });
    state.eventoGoloFantasmaSeguimento = null;
  }
  for (const raridade of NARRATIVE_RARITY_ORDER) {
    if (Math.random() >= (NARRATIVE_RARITY_DAILY_CHANCE[raridade] || 0)) continue;
    const candidatos = NARRATIVE_EVENTS.filter(ev => ev.raridade === raridade && !narrativeEventOnCooldown(ev) && ev.elegivel());
    const escolhido = pickWeightedNarrativeEvent(candidatos);
    if (!escolhido) continue;
    fireNarrativeEvent(escolhido);
    return; // no máximo um evento novo por dia
  }
}
