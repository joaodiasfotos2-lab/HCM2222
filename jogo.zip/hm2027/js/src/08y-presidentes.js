// Presidentes e objetivos da direção (2026-10-14, pedido do utilizador: "Presidentes/direções
// diferentes. A direção define objetivos: campeonato; manutenção; formação; equilíbrio financeiro;
// Europa; Taça").
// Decisões de desenho confirmadas por ele:
//  - PRESIDENTES com nome e perfil (ambicioso, rigoroso, formador, tradicionalista, empresário) que
//    mudam por eleição (mandatos de 3-4 épocas; reeleição possível, mais difícil com a direção
//    descontente);
//  - OBJETIVOS SUBSTITUEM as metas fixas anteriores (saldo, massa salarial, sub-23, patrocinador,
//    Taça): cada época a direção fixa 1 objetivo principal + até 2 secundários, escolhidos entre os
//    seis tipos, conforme a força do clube e o perfil do presidente; confiança, despedimento e
//    pedidos de investimento passam a depender deles. O objetivo do PATROCINADOR continua a existir
//    (financeiro.sponsorObjetivo) e só serve os bónus de patrocínio (08n);
//  - NEGOCIAÇÃO: no início da época o utilizador pode pedir UMA vez um objetivo principal mais
//    ambicioso (verba extra para reforços, mas mais risco) ou mais prudente (menos pressão); a
//    resposta depende do perfil, da confiança e das finanças.
//
// Tudo o que não vem de regulamento é ESTIMATIVA do jogo: perfis e pesos, patamares de força do
// clube, probabilidades de aceitação, prémio e risco da negociação, duração dos mandatos.

const PRES_PERFIS = {
  ambicioso: {
    label: "Ambicioso", icon: "🚀",
    desc: "Quer títulos e Europa e investe para os conseguir. Pouca paciência com maus resultados.",
    pesos: { campeonato: 3, europa: 3, taca: 1.5, formacao: 0.5, financeiro: 0.5, manutencao: 0 },
    deslocaDesportivo: 1, confNeg: 1.3, limiteDespedimento: 0.5, investMinTaxa: 0.4,
    aceitaMais: 0.95, aceitaMenos: 0.15, reeleicao: 0.6,
  },
  rigoroso: {
    label: "Rigoroso nas contas", icon: "🧮",
    desc: "Primeiro as contas: saldo positivo e massa salarial controlada. Desconfia de gastos e de investimentos.",
    pesos: { financeiro: 3, manutencao: 1, formacao: 1.5, taca: 1, europa: 0.5, campeonato: 0.5 },
    deslocaDesportivo: 0, confNeg: 1.0, limiteDespedimento: 0.45, investMinTaxa: 0.65,
    aceitaMais: 0.35, aceitaMenos: 0.6, reeleicao: 0.65,
  },
  formador: {
    label: "Formador", icon: "🌱",
    desc: "Acredita na academia e nos jovens. Aceita perder um pouco hoje se o clube estiver a crescer.",
    pesos: { formacao: 3, financeiro: 1.5, taca: 1, manutencao: 1, europa: 0.5, campeonato: 0.5 },
    deslocaDesportivo: 0, confNeg: 0.75, limiteDespedimento: 0.3, investMinTaxa: 0.5,
    aceitaMais: 0.5, aceitaMenos: 0.7, reeleicao: 0.6,
  },
  tradicionalista: {
    label: "Tradicionalista", icon: "🏛️",
    desc: "Vive pela história do clube: a Taça e os derbis contam muito. Exigente, mas previsível.",
    pesos: { taca: 3, campeonato: 2, europa: 1.5, formacao: 1, financeiro: 1, manutencao: 0.5 },
    deslocaDesportivo: 0, confNeg: 1.1, limiteDespedimento: 0.4, investMinTaxa: 0.5,
    aceitaMais: 0.6, aceitaMenos: 0.4, reeleicao: 0.6,
  },
  empresario: {
    label: "Empresário generoso", icon: "💼",
    desc: "Põe dinheiro do bolso e quer ver o clube na Europa. Entusiasma-se depressa e perde a paciência com a mesma rapidez.",
    pesos: { europa: 3, campeonato: 2, taca: 1.5, financeiro: 0.5, formacao: 0.5, manutencao: 0 },
    deslocaDesportivo: 1, confNeg: 1.2, limiteDespedimento: 0.45, investMinTaxa: 0.35,
    aceitaMais: 0.9, aceitaMenos: 0.3, reeleicao: 0.55,
  },
};
const PRES_ORDEM_PERFIS = ["ambicioso", "rigoroso", "formador", "tradicionalista", "empresario"];

const PRES_TIPOS = {
  campeonato: { label: "Campeonato", icon: "🏆" },
  manutencao: { label: "Manutenção", icon: "🛡️" },
  formacao:   { label: "Formação", icon: "🌱" },
  financeiro: { label: "Equilíbrio financeiro", icon: "🧮" },
  europa:     { label: "Europa", icon: "🌍" },
  taca:       { label: "Taça", icon: "🥇" },
};
const PRES_PESO_PRINCIPAL = 3, PRES_PESO_SEC1 = 2, PRES_PESO_SEC2 = 1;
const PRES_FORMACAO_MIN_JOGOS = 5;           // jogos mínimos para um sub-23 contar no objetivo de formação
const PRES_VERBA_EXTRA_FRAC = 0.03;          // verba de reforços extra (fração da receita anual) ao aceitar "mais ambicioso"
const PRES_CONF_FIM_EPOCA = 5;               // ajuste base da confiança no fim da época (principal cumprido/falhado)

const PRES_NOMES = {
  pt: { n: ["António","Manuel","José","João","Carlos","Fernando","Paulo","Rui","Jorge","Luís","Pedro","Miguel","Armando","Filipe","Nuno","Vítor","Henrique","Álvaro","Rogério","Joaquim","Augusto","Domingos"],
        a: ["Silva","Santos","Ferreira","Pereira","Oliveira","Costa","Rodrigues","Martins","Sousa","Fernandes","Gonçalves","Gomes","Lopes","Marques","Alves","Almeida","Ribeiro","Pinto","Carvalho","Teixeira","Moreira","Correia","Mendes","Nunes","Soares","Vieira","Monteiro","Cardoso","Rocha","Neves"] },
  es: { n: ["Javier","Josep","Joan","Pablo","Carlos","Jordi","Miguel","Antonio","Francisco","Manuel","Alberto","Ramón","Enrique","David"],
        a: ["García","Martínez","López","Sánchez","Pérez","Vila","Puig","Ferrer","Roca","Serra","Torres","Navarro","Molina","Ortega","Ruiz","Castro"] },
  it: { n: ["Marco","Luca","Giuseppe","Antonio","Paolo","Roberto","Stefano","Franco","Alberto","Giovanni","Massimo","Claudio"],
        a: ["Rossi","Bianchi","Ferrari","Russo","Romano","Colombo","Ricci","Marino","Greco","Bruno","Gallo","Conti","De Luca","Costa"] },
};

// Só os clubes realmente jogáveis/competitivos têm presidente e objetivos (não a nuvem europeia nem a 3.ª divisão abstrata)
const PRES_DIVISOES = ["placard", "2div", "3div", "ok-liga-plata", "ok-liga", "serie-a1"]; // 0.2.3: 3.ª Divisão jogável
function presElegivel(t){
  return !!t && !t.equipaPrincipalId && PRES_DIVISOES.includes(t.divisaoAtual) && !String(t.id).startsWith("selecaoNacional");
}
// 2026-10-16: no fecho da época applyPromotionAndRelegation já mudou divisaoAtual — um clube que desce
// à 3.ª (ou sobe dela) deixaria de ser (ou passaria a ser) "elegível" a meio da avaliação. Depois da
// transição, decide-se pelos objetivos que o clube tinha NESTA época.
function presElegivelNaEpoca(t){
  if(!t || t.equipaPrincipalId || String(t.id).startsWith("selecaoNacional")) return false;
  if(state.seasonTransitionApplied && state.promotionEvent){
    const o = t.objetivosEpoca;
    return !!(o && o.season === state.season && Array.isArray(o.itens) && o.itens.length);
  }
  return presElegivel(t);
}
function presOwner(team){
  return team && team.equipaPrincipalId && state.teams[team.equipaPrincipalId] ? state.teams[team.equipaPrincipalId] : team;
}
function presNomeAleatorio(team, rng){
  const pais = teamCountry(team);
  const L = PRES_NOMES[pais];
  return `${L.n[seededRnd(rng, 0, L.n.length - 1)]} ${L.a[seededRnd(rng, 0, L.a.length - 1)]}`;
}
// Perfil: clubes grandes puxam para ambicioso/tradicionalista/empresário, clubes pequenos para
// rigoroso/formador. `evitar` impede repetir o perfil do presidente anterior numa mudança.
function presEscolherPerfil(team, rng, evitar){
  const rep = normalizeClubReputation(team.reputacao, team);
  const big = rep >= 75 ? 1 : rep >= 55 ? 0 : -1;
  const w = {
    ambicioso:       big > 0 ? 3 : big === 0 ? 2 : 1,
    tradicionalista: big > 0 ? 3 : 2,
    empresario:      big > 0 ? 2 : big === 0 ? 2 : 1,
    rigoroso:        big < 0 ? 3 : 2,
    formador:        big < 0 ? 3 : 2,
  };
  if(evitar) w[evitar] = 0;
  const total = PRES_ORDEM_PERFIS.reduce((s, k) => s + w[k], 0);
  let r = rng() * total;
  for(const k of PRES_ORDEM_PERFIS){ r -= w[k]; if(r < 0) return k; }
  return "tradicionalista";
}
function presCriar(team, rng, evitarPerfil){
  const perfil = presEscolherPerfil(team, rng, evitarPerfil);
  return { nome: presNomeAleatorio(team, rng), perfil, desde: state.season, mandatoAnos: seededRnd(rng, 3, 4) };
}
function presEnsure(team){
  const dono = presOwner(team);
  if(!dono) return null;
  if(!dono.presidente || typeof dono.presidente !== "object" || !PRES_PERFIS[dono.presidente.perfil]){
    const rng = makeSeededRng(`presidente:${dono.id}:${state.season}`);
    dono.presidente = presCriar(dono, rng, null);
    // Os mandatos iniciais não começam todos no mesmo ano: desfasa-os para as eleições não
    // acontecerem todas na mesma época.
    dono.presidente.desde = state.season - seededRnd(rng, 0, dono.presidente.mandatoAnos - 1);
  }
  if(!Array.isArray(dono.presidentesHistorico)) dono.presidentesHistorico = [];
  return dono.presidente;
}
function presPerfil(team){
  const p = presEnsure(team);
  return PRES_PERFIS[p ? p.perfil : "tradicionalista"] || PRES_PERFIS.tradicionalista;
}

// ---------------------------------------------------------------------------------------------
// Força relativa do clube na sua competição (decide o patamar desportivo do objetivo)
// ---------------------------------------------------------------------------------------------
function presContexto(team){
  const comp = Object.values(state.competitions).find(c => c.teamIds.includes(team.id));
  const ids = comp ? comp.teamIds.filter(id => state.teams[id] && !state.teams[id].equipaPrincipalId) : [];
  const rep = id => normalizeClubReputation(state.teams[id].reputacao, state.teams[id]);
  const ordenados = ids.slice().sort((a, b) => rep(b) - rep(a));
  const rank = Math.max(1, ordenados.indexOf(team.id) + 1);
  const total = Math.max(rank, ordenados.length || 14);
  const estrangeiro = teamCountry(team) !== "pt";
  const topo = DIVISION_TIER[team.divisaoAtual] === 1;
  return { comp, rank, total, frac: rank / total, estrangeiro, topo, podeTaca: !estrangeiro };
}
// Vagas europeias diretas do país do clube (D'Hondt sobre o coeficiente dos países, ver 07g-europa.js)
function presVagasEuropa(team){
  const pais = teamCountry(team);
  try{
    const coef = {}; EUROPA_PAISES.forEach(p => coef[p] = europaCoefPaisAtual(p));
    const n = (dhondtSeats(8, coef)[pais] || 0) + (dhondtSeats(8, coef)[pais] || 0) + (dhondtSeats(7, coef)[pais] || 0);
    return Math.max(2, Math.min(8, n));
  }catch(e){ return 4; }
}

// Patamar desportivo: 0 manutenção, 1 Taça (ou manutenção nos clubes sem Taça), 2 Europa, 3 campeonato
function presNivelDesportivoBase(team, ctx){
  const f = ctx.frac;
  if(ctx.topo){
    const porRank = f <= 0.15 ? 3 : f <= 0.37 ? 2 : f <= 0.65 ? 1 : 0;
    // A reputação do clube é um piso: um gigante não aceita menos do que lutar pelo título
    const rep = normalizeClubReputation(team.reputacao, team);
    const piso = rep >= 90 ? 3 : rep >= 75 ? 2 : rep >= 55 ? 1 : 0;
    return Math.max(porRank, piso);
  }
  return f <= 0.2 ? 3 : f <= 0.5 ? 1 : 0;
}
function presTipoDoNivel(nivel, ctx){
  if(nivel >= 3) return "campeonato";
  if(nivel === 2) return ctx.topo ? "europa" : (ctx.podeTaca ? "taca" : "manutencao");
  if(nivel === 1) return ctx.podeTaca ? "taca" : "manutencao";
  return "manutencao";
}
function presNivelDoTipo(tipo){ return tipo === "campeonato" ? 3 : tipo === "europa" ? 2 : tipo === "taca" ? 1 : 0; }

// ---------------------------------------------------------------------------------------------
// Fábrica de objetivos
// ---------------------------------------------------------------------------------------------
function presFabricaObjetivo(tipo, team, ctx, perfilKey, opts){
  opts = opts || {};
  const perfil = PRES_PERFIS[perfilKey];
  const o = { tipo, principal: !!opts.principal, peso: opts.peso || 1 };
  if(tipo === "campeonato"){
    o.variante = ctx.topo ? "titulo" : "subida";
    o.label = o.variante === "titulo" ? "Ser campeão nacional" : "Lutar pela subida de divisão";
  }else if(tipo === "manutencao"){
    // 3.ª Divisão (0.2.3): não há descida abaixo — "manutenção" passa a ser terminar na metade superior da zona.
    if(team.divisaoAtual === "3div"){ o.metade = true; o.label = "Terminar na metade superior da tabela"; }
    else o.label = "Assegurar a manutenção";
  }else if(tipo === "europa"){
    o.vagas = presVagasEuropa(team);
    o.label = `Qualificar-se para as provas europeias (terminar nos ${o.vagas} primeiros)`;
  }else if(tipo === "taca"){
    const idx = clamp(tacaTargetPhaseIndex(team) + (opts.deltaTaca || 0), 0, TACA_FASES.length - 1);
    o.alvoIdx = idx;
    o.label = `Taça de Portugal — chegar a ${TACA_FASE_LABEL[TACA_FASES[idx]].replace("Taça de Portugal — ", "")}`;
  }else if(tipo === "formacao"){
    o.jogadores = clamp((opts.jogadores != null ? opts.jogadores : (perfilKey === "formador" ? 4 : 3)), 1, 6);
    o.minJogos = PRES_FORMACAO_MIN_JOGOS;
    o.label = `Formação: ${o.jogadores} pontos — cada sub-23 da equipa A com ${o.minJogos}+ jogos vale 1; cada formado no clube com 10+ jogos pela B (o Sub-19) vale ½`;
  }else if(tipo === "financeiro"){
    o.teto = clamp((opts.teto != null ? opts.teto : (perfilKey === "rigoroso" ? 0.65 : 0.7)), 0.5, 0.85);
    initClubFinance(team);
    o.dividaInicial = (team.financeiro.divida || 0);
    o.label = `Equilíbrio financeiro: saldo positivo, sem dívida nova e massa salarial abaixo de ${Math.round(o.teto * 100)}%`;
  }
  return o;
}

// Escolhe 1 principal + até 2 secundários.
function presGerarObjetivos(team){
  const dono = presOwner(team);
  const perfilKey = presEnsure(dono).perfil, perfil = PRES_PERFIS[perfilKey];
  const ctx = presContexto(dono);
  initClubFinance(dono);
  const base = presNivelDesportivoBase(dono, ctx);
  // Perfis ambiciosos sobem um patamar, mas nunca acima do que a força do clube justifica
  const teto = ctx.topo ? (ctx.frac <= 0.25 ? 3 : 2) : (ctx.frac <= 0.25 ? 3 : 1);
  const nivelFinal = clamp(base + (perfil.deslocaDesportivo || 0), 0, Math.max(base, teto));
  const tipoDesp = presTipoDoNivel(nivelFinal, ctx);

  // Principal: o desportivo, a não ser que o perfil prefira outra coisa para clubes que não lutam por títulos
  const saude = directionHealthTier(dono);
  let tipoPrincipal = tipoDesp;
  if(nivelFinal <= 1){
    if(perfilKey === "rigoroso" && (saude !== "saudavel" || nivelFinal === 0)) tipoPrincipal = "financeiro";
    else if(perfilKey === "formador") tipoPrincipal = "formacao";
  }
  const escolhidos = [tipoPrincipal];
  const candidatos = Object.keys(PRES_TIPOS).filter(t => {
    if(escolhidos.includes(t)) return false;
    if(t === "taca" && !ctx.podeTaca) return false;
    if(t === "europa" && !(ctx.topo && nivelFinal >= 2)) return false;       // Europa só como secundário para clubes de topo fortes
    if(t === "campeonato" && !(tipoPrincipal !== "campeonato" && nivelFinal >= 3)) return false;
    if(t === "manutencao" && !(tipoPrincipal === "financeiro" || tipoPrincipal === "formacao") && nivelFinal > 0) return false;
    return true;
  });
  const sporting = tipoPrincipal === "financeiro" || tipoPrincipal === "formacao";
  if(sporting && !escolhidos.includes(tipoDesp)) escolhidos.push(tipoDesp);     // o desportivo nunca fica de fora
  const resto = candidatos.filter(t => !escolhidos.includes(t))
    .map(t => ({ t, s: (perfil.pesos[t] || 0) + (seededRndFloat(makeSeededRng(`pres-obj:${dono.id}:${state.season}:${t}`), 0, 0.6)) }))
    .sort((a, b) => b.s - a.s);
  while(escolhidos.length < 3 && resto.length) escolhidos.push(resto.shift().t);

  const itens = escolhidos.map((t, i) => presFabricaObjetivo(t, dono, ctx, perfilKey, { principal: i === 0, peso: i === 0 ? PRES_PESO_PRINCIPAL : i === 1 ? PRES_PESO_SEC1 : PRES_PESO_SEC2 }));
  return {
    season: state.season, perfil: perfilKey, presidente: dono.presidente.nome, itens,
    negociacao: { estado: "pendente", direcao: null, aceite: null },
  };
}
function presObjetivosAtuais(team){
  const dono = presOwner(team);
  if(!dono) return null;
  if(!dono.objetivosEpoca || dono.objetivosEpoca.season !== state.season || !Array.isArray(dono.objetivosEpoca.itens) || !dono.objetivosEpoca.itens.length){
    dono.objetivosEpoca = presGerarObjetivos(dono);
  }
  return dono.objetivosEpoca;
}
function presGerarTodos(){
  Object.values(state.teams).forEach(t => {
    if(!presElegivel(t)) return;
    presEnsure(t);
    t.objetivosEpoca = presGerarObjetivos(t);
  });
}

// ---------------------------------------------------------------------------------------------
// Avaliação
// ---------------------------------------------------------------------------------------------
function presEpocaFechada(){
  // Janela entre `state.season += 1` e o fim de finalizeNewSeasonTail (ex.: à espera da Elite Cup): os
  // objetivos já são os da época NOVA, ainda sem jogos — nunca "falhados" (2026-10-15).
  if(state.presEpocaNovaDesde === state.season || state.eliteCupPostSequence==="newSeasonTail") return false;
  return !!(state.seasonOver || (state.inDefeso && !state.isPreSeasonDefeso) ||
    (state.promotionEvent && state.promotionEvent.epoca === seasonLabel(state.season)));
}
function presAvaliarObjetivo(team, o, snap){
  const fechada = snap.fechada;
  const pos = snap.finalPos, total = snap.total;
  let ok = false, estado = "", detalhe = "";
  if(o.tipo === "campeonato"){
    if(o.variante === "titulo"){
      ok = fechada ? snap.champion : (pos === 1);
      detalhe = fechada ? (snap.champion ? "Campeão" : "Não foi campeão") : `Posição atual: ${pos || "—"}.º`;
    }else{
      const subiu = !!(state.promotionEvent && ((state.promotionEvent.promoted || []).includes(team.id) || (state.promotionEvent.promotedFromThird || []).includes(team.id) || (state.promotionEvent.promotedEs || []).includes(team.id)));
      ok = fechada ? subiu : (pos != null && pos <= 2);
      detalhe = fechada ? (subiu ? "Subiu de divisão" : "Não subiu") : `Posição atual: ${pos || "—"}.º`;
    }
  }else if(o.tipo === "manutencao"){
    if(o.metade){
      ok = pos == null ? !fechada : pos <= Math.ceil(total / 2);
      detalhe = `${fechada ? "Posição final" : "Posição atual"}: ${pos || "—"}.º de ${total}`;
    }else{
    ok = fechada ? !snap.relegated : (pos == null || pos <= Math.max(1, total - 3));
    detalhe = fechada ? (snap.relegated ? "Desceu de divisão" : "Manteve-se") : `Posição atual: ${pos || "—"}.º de ${total}`;
    }
  }else if(o.tipo === "europa"){
    const n = o.vagas || 4;
    ok = pos != null && pos <= n;
    detalhe = `${fechada ? "Posição final" : "Posição atual"}: ${pos || "—"}.º (vagas até ao ${n}.º)`;
  }else if(o.tipo === "taca"){
    const alc = tacaProgressReachedIndex(team.id);
    ok = alc >= (o.alvoIdx != null ? o.alvoIdx : 0);
    detalhe = alc >= 0 ? `Já passou: ${TACA_FASE_LABEL[TACA_FASES[alc]].replace("Taça de Portugal — ", "")}` : "Ainda sem eliminatórias ganhas";
  }else if(o.tipo === "formacao"){
    const fp = fbPontos(team, o.minJogos || PRES_FORMACAO_MIN_JOGOS);
    ok = fp.pontos >= (o.jogadores || 3);
    detalhe = `${fbFmt(fp.pontos)} de ${o.jogadores || 3} pontos (${fp.subA.length} sub-23 na A${fp.formB.length ? ` + ${fp.formB.length} formados na B × ½` : ""})`;
  }else if(o.tipo === "financeiro"){
    const f = team.financeiro, wr = snap.wageRatio;
    const divOk = (f.divida || 0) <= (o.dividaInicial || 0);
    ok = f.saldo >= 0 && wr < (o.teto || 0.7) && divOk;
    detalhe = `Saldo ${f.saldo >= 0 ? "positivo" : "negativo"} · massa salarial ${Math.round(wr * 100)}% · ${divOk ? "sem dívida nova" : "dívida a crescer"}`;
  }
  estado = fechada ? (ok ? "cumprido" : "falhado") : (ok ? "em-linha" : "em-risco");
  return { ok, estado, detalhe };
}
function presAvaliar(team){
  const dono = presOwner(team);
  initClubFinance(dono);
  const obj = presObjetivosAtuais(dono);
  const comp = seasonEndCompetitionOf(dono.id);
  const tb = comp ? seasonEndTable(comp.id) : [];
  const finalPos = tb.findIndex(x => x.id === dono.id) + 1 || null;
  const champion = state.placardChampion === dono.id || state.okLigaChampion === dono.id || state.serieA1Champion === dono.id;
  const relegated = !!(state.promotionEvent && ((state.promotionEvent.relegated || []).includes(dono.id) || (state.promotionEvent.relegatedToThird || []).includes(dono.id) || (state.promotionEvent.relegatedEs || []).includes(dono.id)));
  const snap = { fechada: presEpocaFechada(), finalPos, total: tb.length || 14, champion, relegated, wageRatio: wageToBudgetRatio(dono) };
  const goals = obj.itens.map(o => {
    const r = presAvaliarObjetivo(dono, o, snap);
    return { label: `${PRES_TIPOS[o.tipo].label}: ${o.label}`, ok: r.ok, estado: r.estado, detalhe: r.detalhe, tipo: o.tipo, principal: o.principal, peso: o.peso };
  });
  const somaPesos = goals.reduce((s, g) => s + g.peso, 0) || 1;
  let taxa = goals.reduce((s, g) => s + (g.ok ? g.peso : 0), 0) / somaPesos;
  const principal = goals.find(g => g.principal);
  return { goals, passed: goals.filter(g => g.ok).length, total: goals.length, taxa, principalOk: principal ? principal.ok : null, snap };
}
// Taxa de objetivos cumpridos de uma avaliação (as antigas só têm passed/total)
function presTaxaAvaliacao(e){
  if(!e) return 1;
  return e.taxa != null ? e.taxa : e.passed / Math.max(1, e.total);
}
// Posição-alvo para o barómetro de confiança (ver directionObjectiveTargetPosition)
function presAlvoPosicao(team, total){
  const dono = presOwner(team);
  const obj = dono && dono.objetivosEpoca && dono.objetivosEpoca.season === state.season ? dono.objetivosEpoca : null;
  if(!obj) return null;
  const desp = obj.itens.find(o => ["campeonato", "europa", "taca", "manutencao"].includes(o.tipo) && o.principal)
    || obj.itens.find(o => ["campeonato", "europa", "taca", "manutencao"].includes(o.tipo));
  if(!desp) return null;
  if(desp.tipo === "campeonato") return desp.variante === "subida" ? Math.max(2, Math.round(total * 0.2)) : 1;
  if(desp.tipo === "europa") return clamp(desp.vagas || 4, 2, total);
  if(desp.tipo === "taca") return Math.ceil(total * 0.55);
  if(desp.metade) return Math.ceil(total / 2);
  return Math.max(1, total - 3);
}
function presMultConfianca(team, delta){
  if(delta >= 0 || !presElegivel(presOwner(team))) return delta;
  return delta * presPerfil(team).confNeg;
}

// Fim de época: ajusta a confiança conforme o objetivo principal e o risco assumido na negociação
function presFimDeEpoca(team, resultado){
  const dono = presOwner(team);
  if(!dono || !dono.objetivosEpoca) return;
  const neg = dono.objetivosEpoca.negociacao || {};
  // "Mais ambicioso" aceite: ganhar e perder pesa mais; "mais prudente": pesa menos
  const mult = neg.aceite && neg.direcao === "mais" ? 1.6 : neg.aceite && neg.direcao === "menos" ? 0.6 : 1;
  if(dono.confiancaDirecao == null) dono.confiancaDirecao = 60;
  const delta = (resultado.principalOk ? PRES_CONF_FIM_EPOCA : -PRES_CONF_FIM_EPOCA) * mult;
  dono.confiancaDirecao = roundDecimal(clamp(dono.confiancaDirecao + delta, 0, 100));
  dono.objetivosEpoca.fechado = { principalOk: !!resultado.principalOk, taxa: resultado.taxa, delta: Math.round(delta * 10) / 10 };
  if(isUserControlledTeam(dono)){
    const pres = dono.presidente;
    pushNews(state.currentDate, resultado.principalOk
      ? `${escapeHtml(pres.nome)}, presidente do ${escapeHtml(dono.name)}, fez um balanço positivo da época: o objetivo principal foi cumprido (${resultado.passed}/${resultado.total} objetivos).`
      : `${escapeHtml(pres.nome)}, presidente do ${escapeHtml(dono.name)}, mostrou-se desiludido: o objetivo principal não foi cumprido (${resultado.passed}/${resultado.total} objetivos).`,
      "direcao", resultado.principalOk ? "Balanço da época: presidente satisfeito" : "Balanço da época: presidente desiludido", { autoAdvanceStop: false });
  }
}
// Pedidos de investimento: perfis exigentes pedem mais objetivos cumpridos, perfis generosos menos
function presInvestimentoMinTaxa(team){
  return presElegivel(presOwner(team)) ? presPerfil(team).investMinTaxa : 0.5;
}
// Limiar de "época má" para o despedimento (ver checkManagerSacking)
function presLimiteDespedimento(team){
  return presElegivel(presOwner(team)) ? presPerfil(team).limiteDespedimento : 0.4;
}

// ---------------------------------------------------------------------------------------------
// Eleições
// ---------------------------------------------------------------------------------------------
// Corre uma vez por época, no fim (depois da avaliação anual). A direção descontente (confiança
// baixa) torna a reeleição mais difícil; o utilizador só é avisado do que se passa no SEU clube.
function presEleicoes(date){
  Object.values(state.teams).forEach(t => {
    if(!presElegivel(t)) return;
    const pres = presEnsure(t);
    if(!pres) return;
    const anos = state.season - pres.desde + 1;
    if(anos < pres.mandatoAnos) return;
    const perfil = PRES_PERFIS[pres.perfil];
    const conf = t.confiancaDirecao != null ? t.confiancaDirecao : 60;
    const rng = makeSeededRng(`eleicao:${t.id}:${state.season}`);
    const pReeleicao = clamp(perfil.reeleicao + (conf - 50) / 200, 0.1, 0.9);
    const reeleito = rng() < pReeleicao;
    const user = isUserControlledTeam(t);
    if(reeleito){
      pres.desde = state.season + 1; pres.mandatoAnos = seededRnd(rng, 3, 4);
      if(user) pushNews(date, `${escapeHtml(pres.nome)} foi reeleito presidente do ${escapeHtml(t.name)} para mais um mandato. O estilo da direção mantém-se: ${perfil.label.toLowerCase()}.`, "direcao", "Eleições no clube: presidente reeleito", { autoAdvanceStop: true });
      return;
    }
    t.presidentesHistorico.unshift({ nome: pres.nome, perfil: pres.perfil, desde: seasonLabel(pres.desde), ate: seasonLabel(state.season) });
    if(t.presidentesHistorico.length > 8) t.presidentesHistorico.length = 8;
    const novo = presCriar(t, rng, pres.perfil);
    novo.desde = state.season + 1;
    const antigo = pres;
    t.presidente = novo;
    if(user){
      const pn = PRES_PERFIS[novo.perfil];
      pushNews(date, `Houve eleições no ${escapeHtml(t.name)}: ${escapeHtml(novo.nome)} sucede a ${escapeHtml(antigo.nome)} na presidência. Perfil: ${pn.label} — ${pn.desc} Os objetivos da próxima época vão refletir o novo estilo.`, "direcao", "Eleições no clube: novo presidente", { autoAdvanceStop: true });
    }
  });
}

// ---------------------------------------------------------------------------------------------
// Negociação dos objetivos (utilizador, uma vez por época)
// ---------------------------------------------------------------------------------------------
function presPrincipal(obj){ return obj.itens.find(o => o.principal) || obj.itens[0]; }
// Devolve o novo objetivo principal se o ajuste for possível; null caso contrário
function presAjustarPrincipal(team, obj, direcao){
  const dono = presOwner(team), ctx = presContexto(dono), perfilKey = presEnsure(dono).perfil;
  const p = presPrincipal(obj);
  const passo = direcao === "mais" ? 1 : -1;
  if(["campeonato", "europa", "taca", "manutencao"].includes(p.tipo)){
    let nivel = presNivelDoTipo(p.tipo);
    for(let tentativa = 0; tentativa < 3; tentativa++){
      nivel += passo;
      if(nivel < 0 || nivel > 3) return null;
      const tipo = presTipoDoNivel(nivel, ctx);
      if(tipo === p.tipo) continue;
      if(!ctx.topo && tipo === "europa") continue;
      if(obj.itens.some(o => o !== p && o.tipo === tipo)) continue;         // já existe como secundário
      return presFabricaObjetivo(tipo, dono, ctx, perfilKey, { principal: true, peso: p.peso });
    }
    return null;
  }
  if(p.tipo === "formacao"){
    const n = p.jogadores + passo; if(n < 1 || n > 6) return null;
    return presFabricaObjetivo("formacao", dono, ctx, perfilKey, { principal: true, peso: p.peso, jogadores: n });
  }
  if(p.tipo === "financeiro"){
    const t = Math.round((p.teto - 0.05 * passo) * 100) / 100;               // mais ambicioso = teto mais baixo
    if(t < 0.5 || t > 0.85) return null;
    return presFabricaObjetivo("financeiro", dono, ctx, perfilKey, { principal: true, peso: p.peso, teto: t });
  }
  return null;
}
function presPodeNegociar(team){
  const obj = presObjetivosAtuais(team);
  return !!(obj && obj.negociacao && obj.negociacao.estado === "pendente");
}
// direcao: "aceitar" | "mais" | "menos"
function presNegociar(team, direcao){
  const dono = presOwner(team);
  const obj = presObjetivosAtuais(dono);
  if(!obj || obj.negociacao.estado !== "pendente") return { ok: false, reason: "Os objetivos desta época já foram fechados." };
  const pres = dono.presidente, perfil = PRES_PERFIS[pres.perfil];
  const neg = obj.negociacao;
  if(direcao === "aceitar"){
    neg.estado = "fechada"; neg.direcao = null; neg.aceite = null;
    return { ok: true, aceite: true, texto: "Objetivos aceites tal como a direção os propôs." };
  }
  if(direcao !== "mais" && direcao !== "menos") return { ok: false, reason: "Opção inválida." };
  const novo = presAjustarPrincipal(dono, obj, direcao);
  if(!novo) return { ok: false, reason: direcao === "mais" ? "Não há objetivo mais ambicioso para este clube." : "Não há objetivo mais prudente para este clube." };
  initClubFinance(dono);
  const conf = dono.confiancaDirecao != null ? dono.confiancaDirecao : 60;
  const saude = directionHealthTier(dono);
  let p = direcao === "mais" ? perfil.aceitaMais : perfil.aceitaMenos;
  p += (conf - 60) / 200;
  if(direcao === "mais" && saude !== "saudavel") p *= 0.6;
  p = clamp(p, 0.05, 0.97);
  const rng = makeSeededRng(`pres-neg:${dono.id}:${state.season}:${direcao}`);
  const aceite = rng() < p;
  neg.estado = "fechada"; neg.direcao = direcao; neg.aceite = aceite;
  if(!aceite){
    const pen = direcao === "menos" && pres.perfil === "ambicioso" ? 3 : 1.5;
    dono.confiancaDirecao = roundDecimal(clamp(conf - pen, 0, 100));
    return { ok: true, aceite: false, texto: direcao === "mais"
      ? `${pres.nome} não aceitou: acha que o clube não está em condições de assumir mais.`
      : `${pres.nome} recusou baixar a fasquia e ficou desagradado com o pedido.` };
  }
  const antigo = presPrincipal(obj);
  const idx = obj.itens.indexOf(antigo);
  obj.itens[idx] = novo;
  let texto;
  if(direcao === "mais"){
    const f = dono.financeiro;
    const receitaAnual = ((f.receitaMensalPatrocinio || 0) + (f.receitaMensalQuotas || 0) + (f.receitaMensalApoioMunicipal || 0) + (f.receitaMensalComercial || 0)) * 12;
    const verba = Math.max(1000, Math.round(receitaAnual * PRES_VERBA_EXTRA_FRAC / 100) * 100);
    f.orcamentoTransferencias = (f.orcamentoTransferencias || 0) + verba;
    neg.verba = verba;
    texto = `${pres.nome} aceitou o desafio: novo objetivo principal — ${novo.label}. A direção libertou ${fmtMoney(verba)} extra para reforços, mas a confiança sobe ou desce com mais força conforme o resultado.`;
  }else{
    texto = `${pres.nome} aceitou baixar a fasquia: novo objetivo principal — ${novo.label}. Menos pressão, sem verba extra.`;
  }
  return { ok: true, aceite: true, texto };
}

// ---------------------------------------------------------------------------------------------
// Painel (separador Direção)
// ---------------------------------------------------------------------------------------------
function presPainelHtml(team){
  const dono = presOwner(team);
  const pres = presEnsure(dono), perfil = PRES_PERFIS[pres.perfil];
  const obj = presObjetivosAtuais(dono);
  const live = presAvaliar(dono);
  const fim = pres.desde + pres.mandatoAnos - 1;
  const estadoLabel = { "cumprido": "✓ Cumprido", "falhado": "✕ Falhado", "em-linha": "● Em linha", "em-risco": "▲ Em risco" };
  const itens = live.goals.map((g, i) => {
    const o = obj.itens[i];
    const cor = g.ok ? "money-pos" : "money-neg";
    return `<div class="fixture-row pres-obj${g.principal ? " pres-obj-principal" : ""}" style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;">
      <span><b>${PRES_TIPOS[o.tipo].icon} ${g.principal ? "Principal · " : "Secundário · "}${escapeHtml(PRES_TIPOS[o.tipo].label)}</b><br>${escapeHtml(o.label)}<br><span class="helptext">${escapeHtml(g.detalhe)}</span></span>
      <b class="${cor}" style="white-space:nowrap;">${estadoLabel[g.estado] || ""}</b></div>`;
  }).join("");
  const neg = obj.negociacao || {};
  let negHtml;
  if(neg.estado === "pendente"){
    const podeMais = !!presAjustarPrincipal(dono, obj, "mais"), podeMenos = !!presAjustarPrincipal(dono, obj, "menos");
    negHtml = `<div class="pres-neg" style="margin-top:10px;">
      <p class="helptext" style="margin:0 0 8px;">A direção apresentou estes objetivos para ${seasonLabel(state.season)}. Podes aceitá-los ou negociar <b>uma vez</b> o objetivo principal: mais ambicioso (verba extra para reforços, mas mais risco) ou mais prudente (menos pressão).</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <button class="btn btn-primary" data-pres-neg="aceitar">Aceitar objetivos</button>
        <button class="btn btn-ghost" data-pres-neg="mais"${podeMais ? "" : " disabled"}>Pedir mais ambicioso</button>
        <button class="btn btn-ghost" data-pres-neg="menos"${podeMenos ? "" : " disabled"}>Pedir mais prudente</button>
      </div></div>`;
  }else{
    const t = neg.direcao ? (neg.aceite ? (neg.direcao === "mais" ? `Negociaste um objetivo mais ambicioso${neg.verba ? ` (+${fmtMoney(neg.verba)} para reforços)` : ""}.` : "Negociaste um objetivo mais prudente.") : "O teu pedido de negociação foi recusado pela direção.") : "Objetivos aceites sem alterações.";
    negHtml = `<p class="helptext" style="margin:8px 0 0;">${t}</p>`;
  }
  const hist = (dono.presidentesHistorico || []).slice(0, 4).map(h => `${escapeHtml(h.nome)} (${PRES_PERFIS[h.perfil] ? PRES_PERFIS[h.perfil].label : ""}, ${h.desde}–${h.ate})`).join(" · ");
  return `<div class="eyebrow" style="margin-bottom:8px;">Presidente</div>
    <div class="fixture-row" style="margin-bottom:14px;">
      <div><b>${perfil.icon} ${escapeHtml(pres.nome)}</b> · <span class="helptext">${escapeHtml(perfil.label)}</span><br>
      <span class="helptext">${escapeHtml(perfil.desc)}</span><br>
      <span class="helptext">Mandato: ${seasonLabel(pres.desde)} a ${seasonLabel(fim)}${hist ? ` · Anteriores: ${hist}` : ""}</span></div>
    </div>
    <div class="eyebrow" style="margin-bottom:8px;">Objetivos da direção — Época ${seasonLabel(state.season)}</div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px;">${itens}</div>
    ${negHtml}<div style="margin-bottom:16px;"></div>`;
}
function presLigarEventos(box, team, renderAgain){
  box.querySelectorAll("[data-pres-neg]").forEach(btn => btn.addEventListener("click", () => {
    const r = presNegociar(team, btn.getAttribute("data-pres-neg"));
    if(!r.ok){ alert(r.reason); return; }
    pushNews(state.currentDate, escapeHtml(r.texto), "direcao", "Objetivos da época: resposta da direção", { autoAdvanceStop: false });
    renderAgain();
  }));
}

// ---------------------------------------------------------------------------------------------
// Mensagem de boas-vindas da Direção (2026-10-15): "a mensagem de bem-vindo ao clube deve ser a
// primeira de todas (e não depois do Mundial), assinada pela direção, com visão geral e
// objetivos". Enviada no arranque da carreira (chooseClub) e depois reposicionada no fundo da
// caixa de entrada (a mais antiga), para ser a 1.ª a ler.
// ---------------------------------------------------------------------------------------------
function presBoasVindas(){
  const team = typeof myTeam === "function" ? myTeam() : null;
  if(!team) return;
  const elegivel = typeof presElegivel === "function" && presElegivel(team);
  const pres = elegivel ? presEnsure(team) : null;
  const perfil = pres ? PRES_PERFIS[pres.perfil] : null;
  const comp = state.competitions[state.userCompetitionId];
  const compNome = competitionLabel(state.userCompetitionId);
  const f = team.financeiro || {};
  const B = team.equipaBId && state.teams[team.equipaBId];
  const linhasVisao = [
    ["Competição", escapeHtml(compNome) + (comp ? ` · ${comp.teamIds.length} equipas` : "")],
    ["Plantel", `${team.players.length} jogadores${B ? ` · equipa B: ${escapeHtml(B.name)} (${B.players.length})` : ""}`],
  ];
  if(team.academy && team.academy.level) linhasVisao.push(["Academia", `nível ${team.academy.level}/10${B ? " · a equipa B é o escalão Sub-19" : ""}`]);
  if(f.orcamentoTransferencias != null) linhasVisao.push(["Orçamento de transferências", fmtMoney(f.orcamentoTransferencias)]);
  if(f.limiteSalarial != null) linhasVisao.push(["Limite salarial mensal", fmtMoney(f.limiteSalarial)]);
  if(pres) linhasVisao.push(["Presidente", `${escapeHtml(pres.nome)} · ${perfil.icon} ${escapeHtml(perfil.label)}`]);
  let linhasObj = [];
  if(elegivel){
    const obj = presObjetivosAtuais(team);
    linhasObj = (obj && obj.itens || []).map(o => [
      `${PRES_TIPOS[o.tipo].icon} ${o.principal ? "Principal" : "Secundário"}`, `${escapeHtml(o.label)}`]);
  } else {
    try { linhasObj = (evaluateDirectionGoals(team).goals || []).map(g => ["🎯", escapeHtml(g.label)]); } catch(e){ linhasObj = []; }
  }
  const secoes = [
    { icone: "🏟️", titulo: "Visão geral do clube", linhas: linhasVisao, cheia: true },
    { icone: "🎯", titulo: "Objetivos desta época", linhas: linhasObj.length ? linhasObj : [["", "A Direção acompanhará a época e comunicará os objetivos assim que estiverem definidos."]] },
  ];
  if(perfil) secoes.push({ icone: perfil.icon, titulo: "O que a Direção espera de si", texto: `${escapeHtml(perfil.desc)} O objetivo principal pode ser negociado uma vez por época no separador Direção; a avaliação é feita no fim da época e pesa na confiança da Direção.` });
  secoes.push({ icone: "✍️", titulo: "Com os melhores cumprimentos", cheia: true, texto: `<b>${pres ? escapeHtml(pres.nome) : "O Presidente"}</b><br>${pres ? "Presidente · " : ""}em nome da Direção do ${escapeHtml(team.name)}` });
  const resumo = `Em nome da Direção, damos-lhe as boas-vindas ao comando técnico do ${escapeHtml(team.name)}. Aqui fica um resumo do ponto de partida e do que esperamos de si nesta época.`;
  const html = repDoc({
    teamId: team.id, org: "A Direção", titulo: `Bem-vindo ao ${escapeHtml(team.name)}`,
    sub: `Época ${seasonLabel(state.season)} · ${escapeHtml(compNome)}`,
    chips: [repChip(escapeHtml(compNome)), perfil ? repChip(`${perfil.icon} Presidente ${escapeHtml(perfil.label.toLowerCase())}`) : null, linhasObj.length ? repChip(`${linhasObj.length} objetivo${linhasObj.length === 1 ? "" : "s"}`) : null].filter(Boolean),
    resumo, secoes,
    rodape: `${pres ? escapeHtml(pres.nome) + " · Presidente" : "O Presidente"} · A Direção do ${escapeHtml(team.name)}`,
  });
  // Primeira mensagem de todas: criada já, e reposicionada no fundo da caixa de entrada no fim de chooseClub.
  pushNews(state.currentDate, html, "direcao", `Bem-vindo ao ${team.name} — mensagem da Direção`);
  const n = state.news.find(x => x.title === `Bem-vindo ao ${team.name} — mensagem da Direção`);
  if(n) n.boasVindas = true;
}
// Move a mensagem de boas-vindas para o fundo (a mais antiga), com a data da mais antiga da caixa.
function presBoasVindasParaOFundo(){
  const i = state.news.findIndex(x => x.boasVindas);
  if(i < 0) return;
  const [n] = state.news.splice(i, 1);
  const minT = state.news.reduce((m, x) => Math.min(m, new Date(x.date).getTime()), new Date(n.date).getTime());
  n.date = new Date(minT);
  state.news.push(n);
  if(typeof updateEmailNavBadge === "function") updateEmailNavBadge();
}
