// ============================= 08ze-classicos.js =============================
// Clássicos e Jogos Grandes (0.2.4, pedido do João: "aumenta o entusiasmo nos derbies entre Benfica,
// Sporting, Porto, Óquei de Barcelos e Oliveirense, em particular com os 3 grandes; estes jogos são
// sempre televisionados e devem sair notícias — várias, para não repetir").
//
// Níveis (derbyNivel):
//   1 = Clássico dos Grandes (Benfica, Sporting e Porto entre si) — intensidade 1,0
//   2 = Jogo Grande (um dos 3 grandes contra Barcelos/Oliveirense, ou Barcelos–Oliveirense) — 0,6
//   3 = derbis "antigos" (equipas B, rivalidades de Espanha) — mantêm o comportamento anterior, sem notícias próprias
//
// "Febre do jogo" (0-100): base do nível + rivalidade acumulada + luta na tabela + sequência de
// confrontos + prova (playoff/taça) + televisão + forma. Alimenta: lotação, direitos de TV, ambiente
// (pequeno bónus de casa), temperamento dos jogadores, moral, patrocinadores e o texto das notícias.
//
// Tudo o que é número (bónus, probabilidades, audiências) é ESTIMATIVA de jogo — o RGHP não regula nada disto.
//
// Estado (state.derbies, gravado nos saves): { h2h:{chave:[{ep,h,a,hs,as,w,c}]}, rival:{chave:n}, feitos:{},
//   usados:{modelo:n}, recentes:[modelos], pend:[{due,tipo,d}] }

const CLASSICO_GRANDES = ["benfica", "sporting", "porto"];
const CLASSICO_MEDIOS = ["barcelos", "oliveirense"];
const CLASSICO_INTENS = { 1: 1, 2: 0.6, 3: 1 };
const CLASSICO_SENDER = "imprensa@noticias-hoquei.pt";

function derbyKey(a, b){ return a < b ? a + "|" + b : b + "|" + a; }
function derbyNivel(aId, bId){
  if(!aId || !bId || aId === bId) return 0;
  const ga = CLASSICO_GRANDES.includes(aId), gb = CLASSICO_GRANDES.includes(bId);
  const ma = CLASSICO_MEDIOS.includes(aId), mb = CLASSICO_MEDIOS.includes(bId);
  if(ga && gb) return 1;
  if((ga && mb) || (ma && gb) || (ma && mb)) return 2;
  return (typeof DERBY_PAIRS !== "undefined" && DERBY_PAIRS.has(aId + "|" + bId)) ? 3 : 0;
}
function derbyIntensidade(aId, bId){ return CLASSICO_INTENS[derbyNivel(aId, bId)] || 0; }
function derbyNome(n){ return n === 1 ? "Clássico" : n === 2 ? "Jogo Grande" : "Derbi"; }

function derbyEstado(){
  if(!state.derbies || typeof state.derbies !== "object") state.derbies = {};
  const s = state.derbies;
  if(!s.h2h || typeof s.h2h !== "object") s.h2h = {};
  if(!s.rival || typeof s.rival !== "object") s.rival = {};
  if(!s.feitos || typeof s.feitos !== "object") s.feitos = {};
  if(!s.usados || typeof s.usados !== "object") s.usados = {};
  if(!Array.isArray(s.recentes)) s.recentes = [];
  if(!Array.isArray(s.pend)) s.pend = [];
  return s;
}

// ---------------------------------------------------------------- febre do jogo
let _derbyFebreCache = { dia: "", mapa: {} };
function derbyPosicoes(aId, bId){
  try{
    const compId = typeof competitionIdForTeam === "function" ? competitionIdForTeam(aId) : null;
    const comp = compId && state.competitions[compId];
    if(!comp || !["placard", "2div"].includes(comp.divisionId) || !comp.teamIds.includes(bId)) return null;
    const tb = standingsForCompetition(comp.id) || [];
    const pa = tb.findIndex(t => t.id === aId) + 1, pb = tb.findIndex(t => t.id === bId) + 1;
    if(!pa || !pb) return null;
    return { pa, pb, total: tb.length, comp };
  }catch(e){ return null; }
}
function derbyFebre(aId, bId, opts){
  const n = derbyNivel(aId, bId);
  if(!n) return 0;
  if(n === 3) return 55;
  opts = opts || {};
  const dia = state.currentDate ? isoDate(state.currentDate) : "";
  if(_derbyFebreCache.dia !== dia) _derbyFebreCache = { dia, mapa: {} };
  const ck = aId + "|" + bId + "|" + (opts.comp || "liga");
  if(_derbyFebreCache.mapa[ck] != null) return _derbyFebreCache.mapa[ck];
  const st = derbyEstado(), key = derbyKey(aId, bId);
  let f = n === 1 ? 55 : 35;
  f += Math.min(30, st.rival[key] || 0) * 0.6;
  const pos = derbyPosicoes(aId, bId);
  if(pos){
    const top = (pos.pa <= 3 ? 1 : 0) + (pos.pb <= 3 ? 1 : 0);
    f += top === 2 ? 15 : top === 1 ? 6 : 0;
    if(top === 2 && pos.comp.currentRound >= pos.comp.fixtures.length - 4) f += 6;
  }
  const h = (st.h2h[key] || []).slice(-3);
  if(h.length >= 2 && h[h.length - 1].w && h[h.length - 1].w === h[h.length - 2].w) f += 6;
  if(h.length && Math.abs(h[h.length - 1].hs - h[h.length - 1].as) >= 3) f += 4;
  const comp = opts.comp || "liga";
  f += comp === "playoff" ? 15 : (comp === "taca" || comp === "supertaca" || comp === "elite") ? 8 : 0;
  if(typeof tvJogoTransmitido === "function" && tvJogoTransmitido(aId, bId)) f += 5;
  [aId, bId].forEach(id => {
    const t = state.teams[id], r = t && (t.recentResults || []).slice(-3);
    if(r && r.length === 3 && r.every(x => x === "V")) f += 2;
  });
  f = clamp(Math.round(f), 0, 100);
  _derbyFebreCache.mapa[ck] = f;
  return f;
}

// ---------------------------------------------------------------- efeitos no jogo
function derbyAtendimentoMult(hId, aId){
  const n = derbyNivel(hId, aId);
  if(!n) return 1;
  if(n === 3) return 1;
  return (CLASSICO_INTENS[n]) * (0.9 + 0.35 * derbyFebre(hId, aId) / 100);
}
function derbyPisoAtendimento(hId, aId, cap){
  const n = derbyNivel(hId, aId);
  if(n === 1) return cap;
  if(n === 2) return Math.round(cap * 0.88);
  return 0;
}
function derbyTvInteresse(aId, bId){
  const n = derbyNivel(aId, bId);
  return n === 1 ? 55 : n === 2 ? 29 : 15;     // 15 = comportamento anterior; os Clássicos entram sempre na escolha da Federação
}
function derbyTvDireitosMult(aId, bId){
  const n = derbyNivel(aId, bId);
  if(n !== 1 && n !== 2) return 1;
  return 1 + (n === 1 ? 0.5 : 0.25) * derbyFebre(aId, bId) / 100;
}
function derbyAmbienteCasa(hId, aId){
  const n = derbyNivel(hId, aId);
  if(n !== 1 && n !== 2) return { atk: 1, def: 1 };
  const x = CLASSICO_INTENS[n] * derbyFebre(hId, aId) / 100;
  return { atk: 1 + 0.02 * x, def: 1 + 0.01 * x };
}
function derbyAmbienteJogador(p, m, home, away){
  const n = derbyNivel(home.id, away.id);
  if(n !== 1 && n !== 2) return m;
  const k = CLASSICO_INTENS[n] * derbyFebre(home.id, away.id) / 100;
  const t = p.temperamento;
  if(t === "Volátil"){
    const u1 = Math.max(1e-9, Math.random()), u2 = Math.random();
    const g = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    m *= 1 + g * 0.016 * k;
  } else if(t === "Calmo") m *= 1 + 0.006 * k;
  else if(t === "Profissional") m *= 1 + 0.004 * k;
  else if(t === "Ambicioso") m *= 1 + 0.007 * k;
  return clamp(m, 0.93, 1.05);
}
function derbyTagJogo(hId, aId, opts){
  const n = derbyNivel(hId, aId);
  if(!n) return "";
  if(n === 3) return " · 🔥 Derbi";
  return ` · 🔥 ${derbyNome(n)} · febre ${derbyFebre(hId, aId, { comp: opts && opts.playoff ? "playoff" : "liga" })}`;
}
function derbyTagFixture(fx){
  if(!fx) return "";
  const n = derbyNivel(fx.home, fx.away);
  if(n !== 1 && n !== 2) return "";
  return `<span title="${derbyNome(n)} · febre ${derbyFebre(fx.home, fx.away)}" style="margin-left:6px;">🔥</span>`;
}

// ---------------------------------------------------------------- utilitários de texto
function derbyPick(arr, key){ return arr[Math.abs(key) % arr.length]; }
function derbyHash(s){ let h = 0; for(let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
function derbyN(id){ const t = state.teams[id]; return t ? t.name : id; }
function derbyL(id){ return state.teams[id] ? teamLinkHtml(id) : escapeHtml(String(id)); }
function derbyTreinador(id){
  if(id === state.userTeamId && state.managerName) return state.managerName;
  const t = state.teams[id];
  return (t && t.treinador && t.treinador.nome) || "o treinador";
}
function derbyPresidente(id){
  const t = state.teams[id];
  return (t && t.presidente && t.presidente.nome) || "o presidente";
}
function derbyMelhorMarcador(id){
  const t = state.teams[id];
  if(!t) return null;
  const p = (t.players || []).filter(x => !x.__provisional).slice().sort((a, b) => ((b.season && b.season.golos) || 0) - ((a.season && a.season.golos) || 0))[0];
  return p && p.season && p.season.golos > 0 ? { p, golos: p.season.golos } : null;
}
function derbyPlural(n, s, p){ return n === 1 ? s : p; }
function derbyH2hResumo(aId, bId, max){
  const st = derbyEstado(), arr = (st.h2h[derbyKey(aId, bId)] || []).slice(-(max || 5));
  if(!arr.length) return null;
  let va = 0, vb = 0, e = 0;
  arr.forEach(r => { if(r.w === aId) va++; else if(r.w === bId) vb++; else e++; });
  return { n: arr.length, va, vb, e, ultimo: arr[arr.length - 1] };
}

// ---------------------------------------------------------------- escolha de modelo sem repetir
function derbyEscolher(modelos, d){
  const st = derbyEstado();
  const aplic = modelos.filter(m => !m.cond || m.cond(d));
  if(!aplic.length) return null;
  const frescos = aplic.filter(m => !st.recentes.includes(m.id));
  const m = (frescos.length ? frescos : aplic)[0];
  const usos = st.usados[m.id] || 0;
  const v = m.v[(usos + derbyHash(d.key + m.id)) % m.v.length];
  st.usados[m.id] = usos + 1;
  st.recentes.push(m.id); if(st.recentes.length > 10) st.recentes.shift();
  return { id: m.id, v };
}
function derbyEnviar(d, escolha, quando){
  if(!escolha) return;
  const r = escolha.v(d);
  const febre = `<div style="margin-top:8px;font-size:11px;color:var(--texto-mute);">🔥 ${derbyNome(d.n)} · febre do jogo ${d.f}/100</div>`;
  pushNews(quando || state.currentDate, r.x + febre, "classico", r.t, { sender: CLASSICO_SENDER });
}

// ---------------------------------------------------------------- modelos: ANTES do jogo
const DERBY_PRE1 = [
  { id: "contagem", v: [
    d => ({ t: `Contagem decrescente: ${derbyN(d.home)} vs ${derbyN(d.away)}`, x: `Falta uma semana para o ${d.nome} entre ${derbyL(d.home)} e ${derbyL(d.away)}. Em ambos os balneários ninguém fala de outra coisa, e o pavilhão promete uma noite de ambiente à altura.` }),
    d => ({ t: `Já só faltam sete dias para ${derbyN(d.home)}–${derbyN(d.away)}`, x: `A semana é de ${d.nome}: ${derbyL(d.home)} recebe o ${derbyL(d.away)} em casa, com a atenção de todo o país do hóquei virada para a pista.` }),
    d => ({ t: `${derbyN(d.home)}–${derbyN(d.away)}: o jogo que ninguém quer perder`, x: `${d.n === 1 ? "Os três grandes cruzam-se outra vez" : "Um jogo grande a meio da jornada"} e a semana já ferve. ${derbyL(d.home)} e ${derbyL(d.away)} sabem que um ${d.nome} vale muito mais do que três pontos.` }),
  ] },
  { id: "tv", cond: d => d.tv && !d.user, v: [
    d => ({ t: `${d.nome} em directo: ${derbyN(d.home)} vs ${derbyN(d.away)}`, x: `A Federação confirmou a transmissão televisiva do ${d.nome} ${derbyL(d.home)}–${derbyL(d.away)}: ${d.tv.label}. Os direitos de transmissão valem mais do que num jogo normal, e as câmaras vão ter pavilhão cheio.` }),
    d => ({ t: `Televisão escolhe o ${d.nome}`, x: `Como se esperava, o jogo ${derbyL(d.home)}–${derbyL(d.away)} foi o escolhido para a transmissão em directo da jornada (${d.tv.label}). A expectativa de audiência é das mais altas da época.` }),
  ] },
  { id: "bilhetes", cond: d => d.n === 1 || d.f >= 60, v: [
    d => ({ t: `Bilhetes esgotados para ${derbyN(d.home)}–${derbyN(d.away)}`, x: `A bilheteira do ${derbyL(d.home)} fechou em ${d.horas} horas: não há mais bilhetes para o ${d.nome} com o ${derbyL(d.away)}. O clube lembra que há apenas lugares de lotação esgotada e pede aos adeptos que cheguem cedo.` }),
    d => ({ t: `Lotação esgotada à vista no ${derbyN(d.home)}`, x: `Foram precisas só ${d.horas} horas para vender todos os bilhetes do ${d.nome} frente ao ${derbyL(d.away)}. No mercado paralelo, os preços já são exorbitantes.` }),
  ] },
  { id: "seguranca", cond: d => d.n === 1, v: [
    d => ({ t: `Dispositivo de segurança reforçado no ${d.nome}`, x: `As autoridades vão reforçar a segurança à volta do pavilhão do ${derbyL(d.home)} para o ${d.nome} com o ${derbyL(d.away)}. Esperam-se milhares de pessoas e um ambiente muito quente dentro e fora de campo.` }),
    d => ({ t: `${derbyN(d.home)} prepara segurança especial`, x: `O ${derbyL(d.home)} está em contacto com a Federação e as forças de segurança para garantir a normalidade num ${d.nome} de risco elevado. As entradas abrem mais cedo do que o habitual.` }),
  ] },
  { id: "claques", v: [
    d => ({ t: `Claques preparam recepção quente`, x: `Os grupos organizados do ${derbyL(d.home)} preparam uma recepção especial ao ${derbyL(d.away)}: tarjas, cânticos e muita pirotecnia à vista (dentro do que o regulamento permite). O ambiente promete.` }),
    d => ({ t: `Adeptos pintam a cidade para o ${d.nome}`, x: `Nas ruas à volta do pavilhão do ${derbyL(d.home)} já se vêem cachecóis e bandeiras. Os adeptos garantem que vão fazer do ${d.nome} com o ${derbyL(d.away)} uma noite para recordar.` }),
  ] },
  { id: "caravana", cond: d => d.n === 1 || d.f >= 55, v: [
    d => ({ t: `Caravana de adeptos do ${derbyN(d.away)}`, x: `Centenas de adeptos do ${derbyL(d.away)} preparam-se para a deslocação ao pavilhão do ${derbyL(d.home)}. A claque visitante promete fazer-se ouvir do início ao fim.` }),
    d => ({ t: `${derbyN(d.away)} leva multidão em viagem`, x: `A deslocação ao pavilhão do ${derbyL(d.home)} já tem autocarros esgotados. Os adeptos do ${derbyL(d.away)} querem estar presentes no ${d.nome} e prometem apoio sem tréguas.` }),
  ] },
];
const DERBY_PRE2 = [
  { id: "treinadores", v: [
    d => ({ t: `Duelo de treinadores no ${d.nome}`, x: `${escapeHtml(derbyTreinador(d.home))} e ${escapeHtml(derbyTreinador(d.away))} voltam a cruzar-se num ${d.nome} que pode marcar a época. Os dois sabem que uma boa estratégia pode valer mais do que o talento individual.` }),
    d => ({ t: `${derbyN(d.home)} vs ${derbyN(d.away)}: o jogo de xadrez dos treinadores`, x: `Nos bastidores, ${escapeHtml(derbyTreinador(d.home))} e ${escapeHtml(derbyTreinador(d.away))} trabalham nos detalhes tácticos. Num jogo deste nível, uma troca de sistema pode mudar tudo.` }),
  ] },
  { id: "goleadores", cond: d => d.mH && d.mA, v: [
    d => ({ t: `Duelo de goleadores`, x: `${playerLinkHtml(d.home, d.mH.p)} (${d.mH.golos} ${derbyPlural(d.mH.golos, "golo", "golos")}) e ${playerLinkHtml(d.away, d.mA.p)} (${d.mA.golos} ${derbyPlural(d.mA.golos, "golo", "golos")}) são os melhores marcadores das duas equipas e estão em foco no ${d.nome} ${derbyL(d.home)}–${derbyL(d.away)}.` }),
    d => ({ t: `Quem marca no ${d.nome}?`, x: `Os melhores marcadores das duas equipas são ${playerLinkHtml(d.home, d.mH.p)} (${d.mH.golos}) e ${playerLinkHtml(d.away, d.mA.p)} (${d.mA.golos}). Os guarda-redes sabem que vão ter noite difícil.` }),
  ] },
  { id: "h2h", v: [
    d => {
      const r = d.h2h;
      const x = r ? `Nos últimos ${r.n} ${derbyPlural(r.n, "confronto", "confrontos")}: ${derbyN(d.home)} venceu ${r.vh}, ${derbyN(d.away)} venceu ${r.va}${r.e ? ` e houve ${r.e} ${derbyPlural(r.e, "empate", "empates")}` : ""}.` : `É o primeiro confronto entre os dois nesta carreira, e há muita curiosidade para ver como as equipas se apresentam.`;
      return { t: `O que dizem os últimos confrontos`, x: `${x} O ${d.nome} ${derbyL(d.home)}–${derbyL(d.away)} é sempre imprevisível.` };
    },
    d => {
      const r = d.h2h;
      const x = r && r.ultimo ? `No último encontro, o resultado foi ${r.ultimo.hs}–${r.ultimo.as}${r.ultimo.w ? ` a favor do ${derbyN(r.ultimo.w)}` : ", um empate"}.` : "Sem história recente entre os dois, tudo está em aberto.";
      return { t: `Histórico recente: ${derbyN(d.home)} vs ${derbyN(d.away)}`, x: `${x} Ambas as equipas chegam com a ideia de acertar contas.` };
    },
  ] },
  { id: "baixas", v: [
    d => ({ t: `Dúvidas e baixas antes do ${d.nome}`, x: d.baixas.length ? `Chegam ao ${d.nome} com ${d.baixas.length} ${derbyPlural(d.baixas.length, "baixa", "baixas")} entre as duas equipas: ${d.baixas.slice(0, 3).join(", ")}${d.baixas.length > 3 ? "…" : ""}. Os departamentos clínicos trabalham contra o relógio.` : `As duas equipas chegam ao ${d.nome} sem baixas de peso. Os departamentos clínicos garantem que todos os titulares estão disponíveis.` }),
    d => ({ t: `Boletim clínico do ${d.nome}`, x: d.baixas.length ? `Há ${d.baixas.length} ${derbyPlural(d.baixas.length, "jogador indisponível", "jogadores indisponíveis")} entre ${derbyL(d.home)} e ${derbyL(d.away)}: ${d.baixas.slice(0, 3).join(", ")}${d.baixas.length > 3 ? "…" : ""}.` : `Sem lesões a registar: ${derbyL(d.home)} e ${derbyL(d.away)} contam com todos os jogadores para o ${d.nome}.` }),
  ] },
  { id: "presidente", v: [
    d => ({ t: `Presidente do ${derbyN(d.away)} fala em «jogo decisivo»`, x: `${escapeHtml(derbyPresidente(d.away))}, presidente do ${derbyL(d.away)}, disse esperar «um grande espectáculo» no ${d.nome} e pediu à equipa que dê tudo em pista. No ${derbyL(d.home)}, ${escapeHtml(derbyPresidente(d.home))} respondeu que a casa «não se vende».` }),
    d => ({ t: `Provocação no ar: presidentes aquecem o ${d.nome}`, x: `${escapeHtml(derbyPresidente(d.home))} (${derbyL(d.home)}) lembrou que «em casa, quem manda somos nós»; ${escapeHtml(derbyPresidente(d.away))} (${derbyL(d.away)}) devolveu: «veremos em pista». Está lançado o ambiente.` }),
  ] },
  { id: "arbitros", v: [
    d => ({ t: `Árbitros de topo para o ${d.nome}`, x: `A Federação garantiu uma equipa de arbitragem de nível máximo para o ${d.nome} ${derbyL(d.home)}–${derbyL(d.away)}. Num jogo com esta pressão, a segurança do árbitro vale tanto como a dos jogadores.` }),
    d => ({ t: `Arbitragem sob a lupa no ${derbyN(d.home)}–${derbyN(d.away)}`, x: `A equipa de arbitragem escolhida para o ${d.nome} sabe que vai ter todos os olhos em cima. Qualquer decisão polémica será dissecada durante dias.` }),
  ] },
  { id: "lideranca", cond: d => d.pos && (d.pos.pa <= 3 && d.pos.pb <= 3), v: [
    d => ({ t: `Quem ganhar fica na frente`, x: `${derbyL(d.home)} (${d.pos.pa}.º) e ${derbyL(d.away)} (${d.pos.pb}.º) lutam pelos lugares cimeiros da tabela. O vencedor do ${d.nome} dá um passo importante na corrida ao título.` }),
    d => ({ t: `Tabela em jogo no ${d.nome}`, x: `Os dois chegam ao ${d.nome} nos três primeiros lugares: ${derbyN(d.home)} é ${d.pos.pa}.º e ${derbyN(d.away)} é ${d.pos.pb}.º. Mais do que orgulho, há pontos decisivos em disputa.` }),
  ] },
];

// ---------------------------------------------------------------- modelos: DEPOIS do jogo (crónica)
const DERBY_PRE_PO = DERBY_PRE1.filter(m => m.id !== "contagem" && m.id !== "tv").concat(DERBY_PRE2);
const DERBY_POS0 = [
  { id: "penaltis", cond: d => d.so, v: [
    d => ({ t: `${derbyN(d.winner)} vence nos penáltis o ${d.nome}`, x: `Depois de ${d.hs}–${d.as} no tempo regulamentar, o ${d.nome} ${derbyL(d.home)}–${derbyL(d.away)} só se decidiu nos penáltis, com festa para ${derbyL(d.winner)}. Um jogo de nervos de aço.` }),
    d => ({ t: `Loucura nos penáltis: ${derbyN(d.winner)} fica com o ${d.nome}`, x: `${d.hs}–${d.as} no fim do tempo normal e decisão nos penáltis. ${derbyL(d.winner)} teve mais sangue-frio e deixa ${derbyL(d.loser)} a ver o que podia ter sido.` }),
  ] },
  { id: "reviravolta", cond: d => d.winner && d.reviravolta, v: [
    d => ({ t: `Reviravolta histórica: ${derbyN(d.winner)} vira o ${d.nome}`, x: `Estava em desvantagem, mas ${derbyL(d.winner)} não desistiu e acabou por vencer por ${d.hs}–${d.as}. Um ${d.nome} para recordar, com uma recuperação que arrancou a ovação do pavilhão.` }),
    d => ({ t: `${derbyN(d.winner)} faz a diferença depois de estar a perder`, x: `Atrás no marcador, ${derbyL(d.winner)} reagiu e venceu ${d.hs}–${d.as} ${derbyL(d.loser)}. Foi o ${d.nome} das emoções fortes.` }),
  ] },
  { id: "golo_tardio", cond: d => d.late, v: [
    d => ({ t: `Golo nos instantes finais decide o ${d.nome}`, x: `${escapeHtml(d.late.name)} (${derbyL(d.late.teamId)}) marcou já no fim e ${d.late.tipo === "vitoria" ? `deu a vitória por ${d.hs}–${d.as}` : `evitou a derrota (${d.hs}–${d.as})`}. O pavilhão veio abaixo.` }),
    d => ({ t: `${d.late.name} ${d.late.tipo === "vitoria" ? "decide" : "salva"} o ${d.nome} nos últimos minutos`, x: `Quando já ninguém esperava, ${escapeHtml(d.late.name)} fez o golo que ${d.late.tipo === "vitoria" ? "garante a vitória" : "garante o ponto"} a ${derbyL(d.late.teamId)}. Final: ${d.hs}–${d.as}.` }),
  ] },
  { id: "hattrick", cond: d => d.hat, v: [
    d => ({ t: `Hat-trick de ${d.hat.name} no ${d.nome}`, x: `${playerLinkHtml(d.hat.teamId, d.hat.p)} marcou ${d.hat.golos} golos em ${derbyL(d.home)}–${derbyL(d.away)} (${d.hs}–${d.as}) e entrou para a história do ${d.nome}.` }),
    d => ({ t: `${d.hat.name} dá espectáculo`, x: `Três golos de ${playerLinkHtml(d.hat.teamId, d.hat.p)} marcaram o ${d.nome} entre ${derbyL(d.home)} e ${derbyL(d.away)} (${d.hs}–${d.as}). O pavilhão rendeu-se.` }),
  ] },
  { id: "gr_heroi", cond: d => d.gr, v: [
    d => ({ t: `${d.gr.name}, o herói da baliza`, x: `${playerLinkHtml(d.gr.teamId, d.gr.p)} fez defesas decisivas e foi o grande obreiro da vitória de ${derbyL(d.gr.teamId)} (${d.hs}–${d.as}). Parou ${d.gr.remates} remates.` }),
    d => ({ t: `Muralha na baliza decide o ${d.nome}`, x: `${playerLinkHtml(d.gr.teamId, d.gr.p)} travou ${d.gr.remates} remates e manteve a baliza de ${derbyL(d.gr.teamId)} firme quando mais importava. Triunfo por ${d.hs}–${d.as}.` }),
  ] },
  { id: "expulsao", cond: d => d.reds.length, v: [
    d => ({ t: `Expulsão marca o ${d.nome}`, x: `${escapeHtml(d.reds[0].name)} viu o vermelho e a partida mudou. O ${d.nome} ${derbyL(d.home)}–${derbyL(d.away)} terminou ${d.hs}–${d.as}${d.winner ? ` com vitória do ${derbyL(d.winner)}` : ""}.` }),
    d => ({ t: `Cartão vermelho no ${derbyN(d.home)}–${derbyN(d.away)}`, x: `A expulsão de ${escapeHtml(d.reds[0].name)} aqueceu o ambiente. No fim, ${d.hs}–${d.as}, com muitas reclamações e discussões nos bastidores.` }),
  ] },
  { id: "polemica", cond: d => d.anulados > 0, v: [
    d => ({ t: `Golo anulado levanta polémica`, x: `Houve ${d.anulados} ${derbyPlural(d.anulados, "golo anulado", "golos anulados")} no ${d.nome} ${derbyL(d.home)}–${derbyL(d.away)} (${d.hs}–${d.as}). As reclamações sobre a arbitragem vão durar dias.` }),
    d => ({ t: `Arbitragem no centro das atenções`, x: `Um golo anulado e muitas queixas marcaram o ${d.nome} entre ${derbyL(d.home)} e ${derbyL(d.away)}. Resultado final: ${d.hs}–${d.as}.` }),
  ] },
  { id: "goleada", cond: d => d.winner && d.margin >= 4, v: [
    d => ({ t: `Goleada no ${d.nome}: ${derbyN(d.winner)} impõe-se por ${d.hs}–${d.as}`, x: `${derbyL(d.winner)} não teve piedade e venceu por ${Math.max(d.hs, d.as)}–${Math.min(d.hs, d.as)} o ${d.nome} frente ao ${derbyL(d.loser)}. Uma exibição de força que deixa um aviso a toda a gente.` }),
    d => ({ t: `${derbyN(d.winner)} humilha o ${derbyN(d.loser)}`, x: `Resultado tão dilatado como raro num ${d.nome}: ${d.hs}–${d.as}. ${derbyL(d.loser)} nunca entrou no jogo e vai ter de dar explicações.` }),
  ] },
  { id: "vitoria", cond: d => !!d.winner, v: [
    d => ({ t: `${derbyN(d.winner)} vence o ${d.nome} (${d.hs}–${d.as})`, x: `${derbyL(d.winner)} levou a melhor sobre ${derbyL(d.loser)} num ${d.nome} muito disputado, decidido por ${d.margin === 1 ? "um golo" : d.margin + " golos"}. ${d.att ? `Assistência: ${d.att.toLocaleString("pt-PT")} espectadores.` : ""}` }),
    d => ({ t: `${derbyN(d.winner)} fica com os pontos no ${derbyN(d.home)}–${derbyN(d.away)}`, x: `Final ${d.hs}–${d.as}: ${derbyL(d.winner)} conquistou o ${d.nome} e deixa ${derbyL(d.loser)} a lamber as feridas. ${d.att ? `Estiveram ${d.att.toLocaleString("pt-PT")} adeptos nas bancadas.` : ""}` }),
    d => ({ t: `Noite de festa para o ${derbyN(d.winner)}`, x: `O ${d.nome} acabou ${d.hs}–${d.as} e o ${derbyL(d.winner)} celebrou em grande. ${derbyL(d.loser)} tem agora de reagir.` }),
  ] },
  { id: "empate", cond: d => !d.winner, v: [
    d => ({ t: `${d.nome} termina empatado (${d.hs}–${d.as})`, x: `${derbyL(d.home)} e ${derbyL(d.away)} dividiram os pontos num ${d.nome} equilibrado. Nenhuma das equipas conseguiu ganhar vantagem decisiva.` }),
    d => ({ t: `Empate sem vencedor no ${derbyN(d.home)}–${derbyN(d.away)}`, x: `Um ponto para cada lado (${d.hs}–${d.as}). Os adeptos dos dois lados saem com sabores diferentes — mas ambos sabem que podia ter sido pior.` }),
  ] },
];
const DERBY_AUDIENCIA = { id: "audiencia", v: [
  d => ({ t: `Audiência recorde para o ${d.nome}`, x: `O ${d.nome} ${derbyL(d.home)}–${derbyL(d.away)} foi acompanhado por cerca de ${d.audiencia} mil espectadores na televisão, uma das melhores audiências da época no hóquei em patins.` }),
  d => ({ t: `${d.nome} faz subir as audiências`, x: `Estima-se que ${d.audiencia} mil pessoas tenham visto o ${d.nome} em directo na televisão. As operadoras já falam em renovar os direitos.` }),
] };

// ---------------------------------------------------------------- modelos: DIA SEGUINTE e ressaca
const DERBY_POS1 = [
  { id: "conferencia", v: [
    d => {
      const w = d.winner, l = d.loser;
      if(w) return { t: `Treinadores falam após o ${d.nome}`, x: `${escapeHtml(derbyTreinador(w))} (${derbyL(w)}): «Mereci estes pontos, a equipa esteve ao nível.» ${escapeHtml(derbyTreinador(l))} (${derbyL(l)}): «Fizemos coisas boas, mas não chegou. Temos de olhar já para a próxima jornada.»` };
      return { t: `Treinadores satisfeitos (e nem tanto) com o empate`, x: `${escapeHtml(derbyTreinador(d.home))} (${derbyL(d.home)}): «Um ponto que sabe a pouco, jogámos em casa.» ${escapeHtml(derbyTreinador(d.away))} (${derbyL(d.away)}): «Levamos um ponto de um campo difícil.»` };
    },
    d => {
      const w = d.winner, l = d.loser;
      if(w) return { t: `Conferência de imprensa depois do ${d.nome}`, x: `«Orgulho nos meus jogadores», disse ${escapeHtml(derbyTreinador(w))} (${derbyL(w)}). Do outro lado, ${escapeHtml(derbyTreinador(l))} (${derbyL(l)}) admitiu: «Não estivemos à altura. Vamos corrigir.»` };
      return { t: `Empate com palavras cuidadosas`, x: `Ambos os treinadores — ${escapeHtml(derbyTreinador(d.home))} e ${escapeHtml(derbyTreinador(d.away))} — optaram pela prudência: «um resultado justo» foi a expressão mais repetida.` };
    },
  ] },
  { id: "pres_reacao", v: [
    d => {
      const w = d.winner, l = d.loser;
      if(w) return { t: `Presidentes reagem ao ${d.nome}`, x: `${escapeHtml(derbyPresidente(w))} (${derbyL(w)}) agradeceu aos jogadores e adeptos pelo ambiente. ${escapeHtml(derbyPresidente(l))} (${derbyL(l)}) foi directo: «Exigimos mais. Este resultado não é o que queremos.»` };
      return { t: `Presidentes comentam o empate`, x: `${escapeHtml(derbyPresidente(d.home))} e ${escapeHtml(derbyPresidente(d.away))} destacaram a «grande festa do hóquei». Nenhum quis alimentar polémica depois do ${d.nome}.` };
    },
    d => {
      const w = d.winner, l = d.loser;
      if(w) return { t: `Direcção do ${derbyN(w)} em festa`, x: `A direcção de ${derbyL(w)} felicitou publicamente o plantel pelo ${d.nome}. Já a direcção de ${derbyL(l)} anunciou que vai analisar o que correu mal.` };
      return { t: `Direcções pedem calma depois do ${d.nome}`, x: `As direcções de ${derbyL(d.home)} e ${derbyL(d.away)} pediram serenidade após o empate e lembraram que a época ainda vai longa.` };
    },
  ] },
  { id: "adeptos_reacao", v: [
    d => {
      const w = d.winner, l = d.loser;
      if(w) return { t: `Adeptos: festa de um lado, assobios do outro`, x: `Os adeptos de ${derbyL(w)} fizeram da noite uma festa que se prolongou até de madrugada. Em ${derbyL(l)}, a frustração é grande e já há quem peça mudanças.` };
      return { t: `Adeptos divididos depois do ${d.nome}`, x: `Os adeptos de ${derbyL(d.home)} e de ${derbyL(d.away)} saíram com sentimentos mistos. Os dois lados garantem que o ${d.nome} da segunda volta vai ser ainda mais quente.` };
    },
    d => {
      const w = d.winner, l = d.loser;
      if(w) return { t: `A cidade acordou diferente`, x: `Em ${derbyL(w)} só se fala da vitória no ${d.nome}. Em ${derbyL(l)}, o dia amanheceu mais silencioso e os adeptos exigem uma resposta rápida.` };
      return { t: `Ambiente de cortesia entre adeptos`, x: `Apesar do ${d.nome} ter sido muito disputado, os adeptos de ${derbyL(d.home)} e ${derbyL(d.away)} elogiaram o espectáculo. O empate ficou a gosto de ninguém e de toda a gente.` };
    },
  ] },
];
const DERBY_POS2 = [
  { id: "balanco", v: [
    d => {
      const pos = derbyPosicoes(d.home, d.away);
      const x = pos ? `Na tabela, ${derbyL(d.home)} é ${pos.pa}.º e ${derbyL(d.away)} é ${pos.pb}.º.` : "";
      return { t: `Balanço: o que muda depois do ${d.nome}`, x: `${d.winner ? `${derbyL(d.winner)} sai a ganhar do ${d.nome} com ${derbyL(d.loser)}.` : `O empate entre ${derbyL(d.home)} e ${derbyL(d.away)} deixa tudo em aberto.`} ${x} Faltam jogos e, no hóquei em patins, a tabela muda depressa.` };
    },
    d => {
      const pos = derbyPosicoes(d.home, d.away);
      const x = pos ? `Posições actuais: ${derbyN(d.home)} ${pos.pa}.º, ${derbyN(d.away)} ${pos.pb}.º.` : "";
      return { t: `Ressaca do ${d.nome}: as contas da época`, x: `${x} O resultado de ${d.hs}–${d.as} vai pesar nas contas do título, e os dois clubes sabem que ainda se vão voltar a cruzar.` };
    },
  ] },
  { id: "historico", v: [
    d => {
      const r = derbyH2hResumo(d.home, d.away, 5);
      const x = r ? `Nos últimos ${r.n} ${derbyPlural(r.n, "confronto", "confrontos")}, ${derbyN(d.home)} tem ${r.va} ${derbyPlural(r.va, "vitória", "vitórias")}, ${derbyN(d.away)} tem ${r.vb}${r.e ? ` e houve ${r.e} ${derbyPlural(r.e, "empate", "empates")}` : ""}.` : "O confronto está só a começar.";
      return { t: `A rivalidade em números`, x: `${x} A rivalidade entre ${derbyL(d.home)} e ${derbyL(d.away)} continua a crescer.` };
    },
    d => {
      const r = derbyH2hResumo(d.home, d.away, 5);
      const x = r ? `Na história recente, ${derbyN(d.home)} tem ${r.va} ${derbyPlural(r.va, "vitória", "vitórias")} e ${derbyN(d.away)} ${r.vb} em ${r.n} jogos.` : "Os números ainda são curtos.";
      return { t: `Quem manda no ${d.nome}?`, x: `${x} Ninguém quer perder terreno neste duelo.` };
    },
  ] },
];

// ---------------------------------------------------------------- relevância (0.2.5: só o meu clube ou jogos decisivos)
// As notícias de um Clássico/Jogo Grande só chegam à caixa se o clube do utilizador jogar, ou se o jogo for decisivo:
// playoff que pode fechar a série (passagem à fase seguinte ou título), eliminatória de taça, ou jogo dos primeiros
// classificados nas últimas jornadas da liga. Os efeitos de jogo (lotação, moral, TV...) aplicam-se sempre.
function derbyDecisivo(homeId, awayId, kind, compId){
  try{
    if(kind === "taca") return true;
    if(kind === "playoff"){
      const fontes = [state.playoff].concat(Object.values(state.competitions || {}).map(c => c && c.playoff)).filter(Boolean);
      for(const po of fontes){
        for(const fase of Object.keys(po.series || {})){
          const se = (po.series[fase] || []).find(x => x && !x.winner && ((x.teamTop === homeId && x.teamBottom === awayId) || (x.teamTop === awayId && x.teamBottom === homeId)));
          if(!se) continue;
          if(se.bestOf === 2) return (se.games || []).length >= 1;   // eliminatória a duas mãos: a 2.ª mão decide
          const precisa = Math.ceil((se.bestOf || 3) / 2);
          return Math.max((se.wins && se.wins[se.teamTop]) || 0, (se.wins && se.wins[se.teamBottom]) || 0) >= precisa - 1;
        }
      }
      return false;
    }
    const comp = compId && state.competitions && state.competitions[compId];
    if(!comp || !comp.fixtures) return false;
    const faltam = comp.fixtures.length - (comp.currentRound || 0);
    if(faltam > 3) return false;
    const pos = derbyPosicoes(homeId, awayId);
    return !!pos && pos.pa <= 3 && pos.pb <= 3;
  }catch(e){ return false; }
}
function derbyRelevante(homeId, awayId, kind, compId){
  return homeId === state.userTeamId || awayId === state.userTeamId || derbyDecisivo(homeId, awayId, kind, compId);
}

// ---------------------------------------------------------------- construção do contexto e envio
function derbyPreContexto(fx, n){
  const home = fx.home, away = fx.away, st = derbyEstado();
  const baixas = [];
  [home, away].forEach(id => (state.teams[id].players || []).forEach(p => { if((p.diasLesao || 0) > 0 && !p.__provisional) baixas.push(`${escapeHtml(p.name)} (${derbyN(id)})`); }));
  const r = derbyH2hResumo(home, away, 5);
  const h2h = r ? { n: r.n, vh: r.va, va: r.vb, e: r.e, ultimo: r.ultimo } : null;
  return {
    n, nome: derbyNome(n), home, away, key: derbyKey(home, away), f: derbyFebre(home, away),
    tv: fx.tv || null, user: home === state.userTeamId || away === state.userTeamId,
    horas: n === 1 ? 2 + Math.floor(Math.random() * 8) : 8 + Math.floor(Math.random() * 22),
    mH: derbyMelhorMarcador(home), mA: derbyMelhorMarcador(away), pos: derbyPosicoes(home, away), baixas, h2h,
  };
}
function derbyMarcar(chave){ const st = derbyEstado(); if(st.feitos[chave]) return false; st.feitos[chave] = 1; return true; }

function derbyDiario(){
  if(!state.currentDate || !state.competitions) return;
  const st = derbyEstado();
  const hoje = isoDate(state.currentDate);
  // 1) Notícias de antevisão: 7 a 3 dias antes (modelo 1) e 3 a 1 dia antes (modelo 2, só nos Clássicos).
  Object.values(state.competitions).forEach(comp => {
    if(!comp || !["placard", "2div"].includes(comp.divisionId) || !comp.fixtures) return;
    const round = comp.fixtures[comp.currentRound];
    if(!round || !round.date) return;
    const dias = typeof tvDiasAte === "function" ? tvDiasAte(round.date) : 99;
    if(dias < 1 || dias > 7) return;
    round.forEach((fx, i) => {
      if(fx.played) return;
      const n = derbyNivel(fx.home, fx.away);
      if(n !== 1 && n !== 2) return;
      if(!derbyRelevante(fx.home, fx.away, "liga", comp.id)) return;
      const base = `${state.season}|${comp.id}|${comp.currentRound}|${i}`;
      if(dias >= 3 && derbyMarcar(base + "|pre1")){
        const d = derbyPreContexto(fx, n);
        derbyEnviar(d, derbyEscolher(DERBY_PRE1, d));
      }
      if(dias <= 3 && derbyMarcar(base + "|pre2")){
        if(n === 1 || !st.feitos[base + "|pre1"]){
          const d = derbyPreContexto(fx, n);
          derbyEnviar(d, derbyEscolher(DERBY_PRE2, d));
        }
      }
    });
  });
  // 1b) Playoff: antevisão (1 a 3 dias antes) de cada jogo de uma série entre rivais de Clássico / Jogo Grande.
  try{
    const po = state.playoff;
    if(po && po.series && po.phase && po.nextGameDate && Array.isArray(po.series[po.phase])){
      const dias = typeof tvDiasAte === "function" ? tvDiasAte(po.nextGameDate) : 99;
      if(dias >= 1 && dias <= 3){
        po.series[po.phase].forEach((se, i) => {
          if(!se || se.winner || !se.teamTop || !se.teamBottom) return;
          const n = derbyNivel(se.teamTop, se.teamBottom);
          if(n !== 1 && n !== 2) return;
          if(!derbyRelevante(se.teamTop, se.teamBottom, "playoff")) return;
          const g = (se.games || []).length;
          if(!derbyMarcar(`${state.season}|po|${po.phase}|${i}|${g}|pre`)) return;
          const lados = typeof seriesGameSides === "function" ? seriesGameSides(se) : { home: se.teamTop, away: se.teamBottom };
          const d = derbyPreContexto({ home: lados.home, away: lados.away, tv: null }, n);
          d.playoff = true;
          derbyEnviar(d, derbyEscolher(DERBY_PRE_PO, d));
        });
      }
    }
  }catch(e){ /* antevisão do playoff é decorativa */ }
  // 2) Notícias diferidas (reacções e ressaca).
  const dueAgora = st.pend.filter(p => p.due <= hoje);
  if(dueAgora.length){
    st.pend = st.pend.filter(p => p.due > hoje);
    dueAgora.forEach(p => {
      const lista = p.tipo === "post1" ? DERBY_POS1 : DERBY_POS2;
      // Os Clássicos têm duas reacções no dia seguinte; os Jogos Grandes só uma.
      const e1 = derbyEscolher(lista, p.d); derbyEnviar(p.d, e1);
      if(p.tipo === "post1" && p.d.n === 1){ const d2 = p.d; const e2 = derbyEscolher(lista.filter(m => !e1 || m.id !== e1.id), d2); derbyEnviar(d2, e2); }
    });
  }
}

function derbyNovaEpoca(){
  const st = derbyEstado();
  Object.keys(st.rival).forEach(k => { st.rival[k] = Math.round(st.rival[k] * 0.8 * 10) / 10; if(st.rival[k] < 1) delete st.rival[k]; });
  Object.keys(st.feitos).forEach(k => { if(!k.startsWith(state.season + "|")) delete st.feitos[k]; });
  st.pend = [];
}

// ---------------------------------------------------------------- fim de jogo
function derbyAposJogo(ctx){
  const n = derbyNivel(ctx.homeId, ctx.awayId);
  if(!n) return;
  const st = derbyEstado();
  const hs = ctx.score.home, as = ctx.score.away;
  const soW = ctx.soWinner ? (ctx.soWinner === "home" ? ctx.homeId : ctx.awayId) : null;
  const winner = hs > as ? ctx.homeId : as > hs ? ctx.awayId : soW;
  const loser = winner ? (winner === ctx.homeId ? ctx.awayId : ctx.homeId) : null;
  const compKind = ctx.isPlayoff ? "playoff" : (ctx.competitionId && state.competitions[ctx.competitionId]) ? "liga" : "taca";
  const f = derbyFebre(ctx.homeId, ctx.awayId, { comp: compKind });
  const key = derbyKey(ctx.homeId, ctx.awayId);
  const margin = Math.abs(hs - as);
  const I = CLASSICO_INTENS[n] || 1;

  // Moral dos jogadores que jogaram (só Clássicos e Jogos Grandes).
  if(n === 1 || n === 2){
    ["home", "away"].forEach(side => {
      const team = state.teams[side === "home" ? ctx.homeId : ctx.awayId];
      const ids = ctx.playedSet && ctx.playedSet[side];
      if(!team || !ids) return;
      const ganhou = winner === team.id, perdeu = winner && winner !== team.id;
      const delta = (ganhou ? 4 : perdeu ? -3.5 : 0.5) * I * (0.8 + 0.4 * f / 100);
      team.players.forEach(p => { if(ids.has(p.id) && !p.__provisional) p.moral = clamp((p.moral != null ? p.moral : 60) + delta, 0, 100); });
    });
  }

  // Dados do jogo para as notícias.
  const reds = [], goalsBySide = { home: {}, away: {} };
  const timeline = []; let sh = 0, sa = 0, minDiffW = 0;
  (ctx.log || []).forEach(l => {
    if(l.type === "vermelho" && l.player) reds.push({ name: l.player, side: l.side });
    if(l.type === "golo" && l.side){
      if(l.side === "home") sh++; else sa++;
      timeline.push({ side: l.side, name: l.player, abs: l.abs, per: l.per, sh, sa });
      if(winner){
        const dW = winner === ctx.homeId ? sh - sa : sa - sh;
        if(dW < minDiffW) minDiffW = dW;
      }
    }
  });
  const reviravolta = !!winner && !soW && minDiffW <= -2;
  let late = null;
  const last = timeline[timeline.length - 1];
  if(last && last.abs != null && last.abs >= 2 * CATEGORY_PERIOD_SECONDS - 150 && last.per >= 2 && !soW){
    const lastTeam = last.side === "home" ? ctx.homeId : ctx.awayId;
    const antes = last.side === "home" ? (last.sh - 1) - last.sa : (last.sa - 1) - last.sh;
    if(winner === lastTeam && margin === 1) late = { name: last.name, teamId: lastTeam, tipo: "vitoria" };
    else if(!winner && antes === -1) late = { name: last.name, teamId: lastTeam, tipo: "empate" };
  }
  let hat = null;
  ["home", "away"].forEach(side => {
    const team = state.teams[side === "home" ? ctx.homeId : ctx.awayId];
    const ids = ctx.playedSet && ctx.playedSet[side];
    if(!team || !ids) return;
    team.players.forEach(p => { if(ids.has(p.id) && (p.__matchGoals || 0) >= 3 && (!hat || p.__matchGoals > hat.golos)) hat = { name: p.name, p, golos: p.__matchGoals, teamId: team.id }; });
  });
  let gr = null;
  if(winner && !soW){
    const side = winner === ctx.homeId ? "home" : "away", opp = side === "home" ? "away" : "home";
    const team = state.teams[winner], ids = ctx.playedSet && ctx.playedSet[side];
    const remates = ctx.shots ? (ctx.shots[opp] || 0) : 0;
    const concedidos = side === "home" ? as : hs;
    const g = team && ids ? team.players.find(p => p.pos === "GR" && ids.has(p.id)) : null;
    if(g && concedidos <= 2 && remates >= 15) gr = { name: g.name, p: g, teamId: winner, remates: Math.max(1, remates - concedidos) };
  }
  const anulados = ctx.disallowedGoals ? ((ctx.disallowedGoals.home || 0) + (ctx.disallowedGoals.away || 0)) : 0;
  const tvTxt = ctx.tv || null;

  // Rivalidade acumulada, historial, patrocinadores.
  if(n === 1 || n === 2){
    st.rival[key] = Math.min(60, (st.rival[key] || 0) + (n === 1 ? 6 : 4) + (margin >= 3 ? 3 : 0) + (reds.length ? 3 : 0) + (compKind === "playoff" ? 4 : 0));
  }
  (st.h2h[key] = st.h2h[key] || []).push({ ep: state.season, h: ctx.homeId, a: ctx.awayId, hs, as, w: winner, c: compKind });
  if(st.h2h[key].length > 12) st.h2h[key].shift();
  if(winner && (n === 1 || n === 2)){
    const t = state.teams[winner];
    if(t && t.financeiro){
      const base = (t.financeiro.receitaMensalPatrocinio || 0) * 0.05 * I * (0.7 + 0.6 * f / 100) * (tvTxt ? 1.5 : 1);
      const bonus = Math.round(base);
      if(bonus > 0) addFinanceMovement(t, "receita", "Patrocínio", `Prémio de visibilidade — ${derbyNome(n)} com o ${derbyN(loser)}`, bonus, state.currentDate);
    }
  }
  if(n !== 1 && n !== 2) return;
  if(!derbyRelevante(ctx.homeId, ctx.awayId, compKind, ctx.competitionId)) return;   // 0.2.5: sem notícias de jogos alheios que não decidem nada

  // Notícias: crónica já (+ audiência), reacções amanhã, ressaca daqui a 2 dias (Clássicos, ou jogos de relevo).
  const d = {
    n, nome: derbyNome(n), f, key, home: ctx.homeId, away: ctx.awayId, hs, as, winner, loser, margin, so: !!soW,
    reviravolta, late, hat: hat ? { name: hat.name, golos: hat.golos, teamId: hat.teamId, p: undefined, pid: hat.p.id } : null,
    gr: gr ? { name: gr.name, teamId: gr.teamId, remates: gr.remates, pid: gr.p.id } : null,
    reds, anulados, att: ctx.attendance || 0, tv: tvTxt, compKind, user: ctx.homeId === state.userTeamId || ctx.awayId === state.userTeamId,
    audiencia: Math.round(70 + f * 1.4 + Math.random() * 40),
  };
  // Reidratar jogadores (o contexto diferido é serializável): playerLinkHtml precisa do objecto.
  if(d.hat) d.hat.p = hat.p;
  if(d.gr) d.gr.p = gr.p;
  derbyEnviar(d, derbyEscolher(DERBY_POS0, d));
  if(d.tv) derbyEnviar(d, derbyEscolher([DERBY_AUDIENCIA], d));
  const serial = JSON.parse(JSON.stringify(Object.assign({}, d, { hat: d.hat ? { name: d.hat.name, golos: d.hat.golos, teamId: d.hat.teamId } : null, gr: d.gr ? { name: d.gr.name, teamId: d.gr.teamId, remates: d.gr.remates } : null })));
  const amanha = isoDate(addDays(state.currentDate, 1)), depois = isoDate(addDays(state.currentDate, 2));
  st.pend.push({ due: amanha, tipo: "post1", d: serial });
  if(n === 1 || margin >= 3 || compKind === "playoff") st.pend.push({ due: depois, tipo: "post2", d: serial });
}
