  // ============================= 07-playoff.js =============================
  // Playoff
  // Playoff — apuram-se os 8 primeiros da fase regular.
  // Quartos: 1v8, 2v7, 3v6, 4v5 (melhor de 3). Meias: cruzamento QF1/QF4 e QF2/QF3
  // (melhor de 3), o que garante que o 1º e o 2º só se podem cruzar na final
  // (melhor de 5). Jogos alternam casa/fora, começando em casa quem tiver tido
  // a melhor classificação na fase regular.
  // =================================================================
  // Configuração por divisão de topo com playoff próprio — o Placard (Portugal), a OK Liga
  // (Espanha) e, desde a Serie A1, a Itália. Um novo país só precisa de uma entrada aqui (campo
  // onde fica guardado o campeão dessa divisão, e o padrão de casa real das meias/final — RGHP
  // para Portugal é alternado simples; a OK Liga real usa 2-2-1, ver bases da FEP; a Serie A1
  // italiana é alternado simples tal como Portugal, confirmado pelo calendário real da final
  // 2026 Trissino-Bassano, apesar de uma fonte secundária lhe chamar "2-2-1" no texto). Isto é o
  // que permite ao MESMO motor de playoff (makeSeries/checkPlayoffPhaseCompletion/etc.) servir as
  // três competições sem as confundir, mesmo quando uma delas está a decorrer só por IA em
  // segundo plano (ver simulateAiPlayoffIfNeeded, mais abaixo). A Serie A1 tem ainda uma fase
  // extra que as outras duas não têm: `preliminaryRound:true` assinala que, antes dos 1/4 de
  // Final, há um Turno Preliminar a duas mãos (7º vs 10º, 8º vs 9º da fase regular) — ver a fase
  // "PR" em createPlayoffBracket/checkPlayoffPhaseCompletion.
  // runnerUpField (2026-09-12): acrescentado para a Supercopa de España, que precisa do
  // vice-campeão da OK Liga além do campeão — nenhuma prova até agora precisava disto. Só a
  // OK Liga o usa por agora (Placard/Serie A1 não têm nenhuma supertaça que precise do vice),
  // mas fica disponível para todas por generalidade.
  const PLAYOFF_DIVISION_CONFIG = {
    "placard":  { championField: "placardChampion",  runnerUpField: null,          sfFinalVenuePattern: "alt",   championLabel: "Campeonato Placard" },
    "ok-liga":  { championField: "okLigaChampion",    runnerUpField: "okLigaRunnerUp",  sfFinalVenuePattern: "2-2-1", championLabel: "OK Liga" },
    "serie-a1": { championField: "serieA1Champion",   runnerUpField: "serieA1RunnerUp", sfFinalVenuePattern: "alt",   championLabel: "Serie A1", preliminaryRound: true },
  };
  // Correção (2026-10-04, pedido do utilizador: "final four taça de portugal ao mesmo tempo do
  // playoff e liga dos campeoes depois", com levantamento de 5 épocas reais em anexo) — até aqui,
  // o Playoff arrancava sempre 4 dias depois do fim da fase regular (meados de abril), exactamente
  // ao mesmo tempo da Final Four da Taça de Portugal e dos 1/4 da Champions League/Europa. O
  // levantamento real do utilizador mostra as três provas sempre em sequência: Final Four da Taça
  // (finais de abril) → fase final europeia (4-15 de maio, ver europaChampionsKnockoutDates) →
  // Playoff (meados de maio a meados/finais de junho). "para todas as ligas usa as mesmas regras"
  // (pedido explícito do utilizador): a mesma âncora aplica-se às três divisões com playoff —
  // Placard, OK Liga e Serie A1 — através do mesmo PLAYOFF_DIVISION_CONFIG partilhado, nunca um
  // caso especial só para Portugal (o levantamento em si é do hóquei em patins português, mas a
  // regra de sequenciamento — taça → europa → playoff — é a mesma estrutura para as três ligas
  // deste jogo, que partilham sempre o mesmo motor de playoff).
  const PLAYOFF_START_TARGET_MONTH = 4; // maio (0-indexado)
  const PLAYOFF_START_TARGET_DAY = 16;  // meio do intervalo real (10-18 de maio nas 5 épocas estudadas)
  function playoffStartTargetDate(season){
    const y = 2026 + (season - 1);
    const target = nextWeekday(new Date(y+1, PLAYOFF_START_TARGET_MONTH, PLAYOFF_START_TARGET_DAY), 6); // 1º sábado a partir de 16 de maio
    // Salvaguarda (mesmo princípio de nationalCupSafeDates, 07e-copas-nacionais.js): se a fase
    // regular só terminar depois da data-alvo real (calendário excecionalmente comprimido ou
    // atrasado por reagendamentos em cadeia), agenda a partir de hoje com a mesma folga mínima
    // que já era usada antes desta correção, em vez de arriscar uma data já passada.
    if(state.currentDate && target.getTime() <= state.currentDate.getTime()) return addDays(state.currentDate, 4);
    return target;
  }
  // competitionId (2026-10-16): sem ele, os jogos de playoff eram registados como "amistoso" nas
  // estatísticas por competição (simulateMatchToCompletion / resolvePendingFixtureCompetitionId).
  function makeSeries(teamTop, teamBottom, bestOf, label, venuePattern, seeds, competitionId){
    return { teamTop, teamBottom, bestOf, games:[], wins:{[teamTop]:0,[teamBottom]:0}, winner:null, label, venuePattern: venuePattern||"alt", seeds: seeds||null, competitionId: competitionId||null };
  }
  function seriesGameSides(series){
    const gIdx = series.games.length;
    // Padrão real da 1/2 Final e Final da OK Liga (bases FEP): jogos 1, 2 e 5 em casa do
    // melhor classificado, jogos 3 e 4 em casa do pior ("2-2-1") — diferente do alternado
    // simples do Placard (RGHP), que continua a ser o padrão por omissão ("alt").
    const home = series.venuePattern==="2-2-1"
      ? ([0,1,4].includes(gIdx) ? series.teamTop : series.teamBottom)
      : (gIdx%2===0 ? series.teamTop : series.teamBottom);
    const away = home===series.teamTop ? series.teamBottom : series.teamTop;
    return { home, away };
  }
  // Constrói (ou reconstrói) os 1/4 de Final a partir de uma lista já ordenada de 8 apurados —
  // extraído para uma função própria porque a Serie A1 tem DUAS formas de chegar aos 1/4: direto
  // da fase regular (Placard/OK Liga, 8 primeiros) ou depois do Turno Preliminar (Serie A1, 6
  // primeiros diretos + 2 vencedores do Turno Preliminar — ver checkPlayoffPhaseCompletion, fase
  // "PR"). `comp.playoff` já tem de existir (competitionId/seeds/series.SF/series.F) antes de
  // chamar esta função; ela só preenche series.QF e a fase.
  function buildQuarterFinalsFromSeeds(comp, qfSeeds){
    const pairs = [[0,7],[1,6],[2,5],[3,4]];
    comp.playoff.series.QF = pairs.map(([a,b],idx)=>makeSeries(qfSeeds[a], qfSeeds[b], 3, `1/4 Final ${idx+1}`, "alt", comp.playoff.seeds, comp.id));
    comp.playoff.phase = "QF";
    // A classificação exibida usa sempre comp.playoff.seeds (a fase regular completa, 8 ou 10
    // equipas consoante o país) — não o índice dentro de qfSeeds, que na Serie A1 pós-Turno
    // Preliminar já não corresponde à posição real (os 2 últimos lugares do quadro podem ser o
    // 7º/8º/9º/10º classificado, consoante quem vence cada eliminatória).
    const rank = id => comp.playoff.seeds.indexOf(id)+1;
    const matchupsTxt = pairs.map(([a,b])=>`${teamLinkHtml(qfSeeds[a])} (${rank(qfSeeds[a])}º) vs ${teamLinkHtml(qfSeeds[b])} (${rank(qfSeeds[b])}º)`).join(" · ");
    const cfg = PLAYOFF_DIVISION_CONFIG[comp.divisionId];
    // Correção (pedido explícito do utilizador, 2026-09-27: "estao a sair imensas noticias dos
    // playoffs de italia e eu nem jogo nessa liga" / "tambem saem noticias do playoff de
    // portugal, basta ver os resultados") — o playoff de QUALQUER divisão de topo (Placard/OK
    // Liga/Serie A1) gerava sempre notícia, mesmo quando não é a competição do utilizador (a
    // resolução só por IA, simulateAiPlayoffIfNeeded, corre para as três em paralelo). Só a
    // competição do utilizador (state.userCompetitionId) publica agora estas notícias de
    // progresso do quadro — o quadro/tabela em Competições continua sempre visível para quem
    // quiser ver os resultados das outras divisões, só deixa de encher a caixa de e-mail.
    if(comp.id!==state.userCompetitionId) return;
    pushNews(state.currentDate, comp.divisionId==="placard"
      ? `Play Off apurado — 1/4 Final: ${matchupsTxt}.`
      : `Play Off apurado (${cfg.championLabel}) — 1/4 Final: ${matchupsTxt}.`, "sistema");
  }
  // Cria o quadro de playoff na competição indicada — usado tanto pelo fluxo interativo
  // (startPlayoffs) como pela resolução só por IA de uma competição que o utilizador não esteja
  // a jogar (simulateAiPlayoffIfNeeded). Na generalidade dos países, os 1/4 são semeados
  // diretamente pelos 8 primeiros da fase regular; a Serie A1 italiana (regulamento real da
  // FISR/Lega Nazionale Hockey 2026-27) tem primeiro um Turno Preliminar a duas mãos entre o
  // 7º-10º classificado, cujos 2 vencedores completam o quadro de 8 a par dos 6 primeiros — ver
  // PLAYOFF_DIVISION_CONFIG[...].preliminaryRound.
  function createPlayoffBracket(comp){
    const cfg = PLAYOFF_DIVISION_CONFIG[comp.divisionId];
    if(cfg && cfg.preliminaryRound){
      const seeds10 = standingsForCompetition(comp.id).slice(0,10).map(t=>t.id);
      const prPairs = [[6,9],[7,8]]; // 7º vs 10º, 8º vs 9º (índices 0-based dentro de seeds10)
      comp.playoff = {
        competitionId: comp.id,
        phase: "PR",
        seeds: seeds10,
        series: {
          PR: prPairs.map(([a,b],idx)=>{
            const s = makeSeries(seeds10[a], seeds10[b], 2, `Turno Preliminar ${idx+1}`, "alt", seeds10, comp.id);
            // Eliminatória a duas mãos, decidida por golos agregados (não por "1ª a X vitórias")
            // — ver o guarda correspondente em finishPlayoffGame e a fase "PR" em
            // checkPlayoffPhaseCompletion, que é quem realmente decide o vencedor.
            s.aggregateTie = true;
            return s;
          }),
          QF: [], SF: [], F: [],
        },
        nextGameDate: playoffStartTargetDate(state.season),
      };
      const matchupsTxt = prPairs.map(([a,b])=>`${teamLinkHtml(seeds10[a])} (${a+1}º) vs ${teamLinkHtml(seeds10[b])} (${b+1}º)`).join(" · ");
      // Correção (2026-09-27, mesmo pedido do utilizador que em buildQuarterFinalsFromSeeds):
      // só a competição do utilizador publica esta notícia.
      if(comp.id===state.userCompetitionId) pushNews(state.currentDate, `Play Off apurado (${cfg.championLabel}) — Turno Preliminar: ${matchupsTxt}.`, "sistema");
      return;
    }
    const seeds = standingsForCompetition(comp.id).slice(0,8).map(t=>t.id);
    comp.playoff = { competitionId: comp.id, phase: "QF", seeds, series: { QF: [], SF: [], F: [] }, nextGameDate: playoffStartTargetDate(state.season) };
    buildQuarterFinalsFromSeeds(comp, seeds);
  }
  function startPlayoffs(comp){
    // Correção: sortedStandings() sem argumento lê a competição atualmente VISTA
    // (state.viewedCompetitionId || state.userCompetitionId), não necessariamente o Placard —
    // se o utilizador estivesse a ver outra competição quando a fase regular do Placard
    // terminasse, o playoff nacional era semeado com a tabela errada (a mesma classe de bug já
    // corrigida para a liguilha Norte/Sul). standingsForCompetition fixa a competição pedida.
    // Generalizado para qualquer divisão de topo com playoff (Placard ou OK Liga): comp por
    // omissão é a competição atual do utilizador, que é sempre a que está a terminar a fase
    // regular quando isto é chamado (ver maybeAdvanceRound, 06-motor-jogo.js).
    comp = comp || currentCompetition();
    createPlayoffBracket(comp);
    state.playoffActive = true;
    // Correção: chamava sempre renderPlayoffTab() diretamente, sobrepondo o conteúdo do
    // separador Playoff com o do Placard mesmo que o utilizador estivesse a ver outra
    // competição (ex.: a 2ª Divisão, a acompanhar a liguilha de promoção). renderCompetitionView
    // já sabe qual o conteúdo certo a mostrar consoante a competição atualmente selecionada.
    if(document.getElementById("viewCompeticoes") && !document.getElementById("viewCompeticoes").classList.contains("hidden")) renderCompetitionView();
  }
  function seedLabel(teamId, series){
    const seeds = series && series.seeds;
    const idx = seeds ? seeds.indexOf(teamId) : -1;
    return idx>=0 ? `${idx+1}º da Fase Regular` : "";
  }
  function teamLinkHtml(teamId){
    return `<button class="jr-team-link" data-team="${teamId}">${state.teams[teamId].name}</button>`;
  }
  function finishPlayoffGame(series, homeId, awayId, hs, as, soWinner, attendance){
    const winnerId = soWinner ? (soWinner==="home"?homeId:awayId) : (hs>as ? homeId : awayId);
    series.games.push({ home:homeId, away:awayId, homeScore:hs, awayScore:as, soWinner: soWinner||null });
    series.wins[winnerId] = (series.wins[winnerId]||0)+1;
    // attendance (opcional): quando o jogo foi ao vivo, o chamador passa ctx.attendance (o
    // valor único já mostrado ao utilizador durante a partida) — ver processMatchFinances.
    processMatchFinances(homeId, awayId, state.currentDate, attendance!=null?{playoff:true, attendance}:{playoff:true});
    const soTxt = soWinner ? " (g.p.)" : "";
    // Correção (pedido explícito do utilizador, 2026-09-27: "estao a sair imensas noticias dos
    // playoffs de italia e eu nem jogo nessa liga" / "tambem saem noticias do playoff de
    // portugal, basta ver os resultados") — antes, TODOS os jogos de QUALQUER série de playoff
    // (mesmo de uma série ou divisão em que o utilizador não tem qualquer equipa envolvida —
    // outras séries do próprio Placard, ou a OK Liga/Serie A1 inteiras, resolvidas só por IA em
    // segundo plano) geravam uma notícia jogo-a-jogo. Passa a só publicar quando o clube do
    // utilizador é uma das duas equipas desta série — o quadro/resultados de qualquer playoff
    // continuam sempre visíveis em Competições, só deixa de encher a caixa de e-mail com jogos
    // que não lhe dizem respeito.
    const envolveUtilizador = homeId===state.userTeamId || awayId===state.userTeamId;
    if(envolveUtilizador) pushNews(state.currentDate, `<b>${series.label}</b>: ${teamLinkHtml(homeId)} ${hs}-${as} ${teamLinkHtml(awayId)}${soTxt}. Série: ${teamLinkHtml(series.teamTop)} ${series.wins[series.teamTop]||0}-${series.wins[series.teamBottom]||0} ${teamLinkHtml(series.teamBottom)}.`, "jogo");
    // Turno Preliminar (Serie A1): eliminatória a duas mãos, decidida por golos agregados só
    // depois da 2ª mão (ver fase "PR" em checkPlayoffPhaseCompletion) — nunca pela lógica "1ª a X
    // vitórias" abaixo, que decidiria (erradamente) já a seguir à 1ª mão, pois bestOf=2 dá
    // neededWins=1. Não-op para todas as séries existentes (Placard/OK Liga), cujo aggregateTie
    // é sempre falsy.
    if(series.aggregateTie) return;
    const neededWins = Math.ceil(series.bestOf/2);
    if(series.wins[winnerId] >= neededWins){
      series.winner = winnerId;
      // Mesma correção: só notícia se o clube do utilizador jogar esta série.
      if(envolveUtilizador) pushNews(state.currentDate, `🏒 ${teamLinkHtml(winnerId)} (${seedLabel(winnerId, series)}) vence a eliminatória "${series.label}" e avança de fase!`, "sistema");
      // Correção (verificação pedida pelo utilizador: notícia sempre que a equipa do utilizador
      // passa de fase ou sai da competição): a mensagem acima já nomeia o vencedor real (inclui
      // o próprio clube do utilizador quando é ele a avançar), mas nunca dizia explicitamente
      // "foste eliminado" quando era o utilizador a PERDER a eliminatória — só ficava implícito.
      // Acrescenta-se aqui uma notícia dedicada, mesmo padrão da Taça de Portugal, sempre que o
      // clube do utilizador é uma das duas equipas desta série e não venceu.
      const loserId = winnerId===series.teamTop ? series.teamBottom : series.teamTop;
      if(loserId===state.userTeamId){
        const cfgElim = PLAYOFF_DIVISION_CONFIG[currentCompetition().divisionId] || PLAYOFF_DIVISION_CONFIG.placard;
        pushNews(state.currentDate, `${teamLinkHtml(state.userTeamId)} foi eliminado da ${cfgElim.championLabel} ${seasonLabel(state.season)} nos "${series.label}", após perder para ${teamLinkHtml(winnerId)}.`, "sistema", `${myTeam().name} eliminado do Playoff`);
      }
    }
  }
  function playOneSeriesGameQuick(series){
    const { home, away } = seriesGameSides(series);
    const addedHome = ensureMinimumSquad(state.teams[home]);
    const addedAway = ensureMinimumSquad(state.teams[away]);
    const res = simulateMatchToCompletion(home, away, true, false, series.competitionId || null);
    finishPlayoffGame(series, home, away, res.home, res.away, res.soWinner, res.attendance);
    removeProvisionalPlayers(state.teams[home], addedHome);
    removeProvisionalPlayers(state.teams[away], addedAway);
  }
  // holder: a competição (objeto de state.competitions) cujo playoff está a ser avaliado — nunca
  // assumido via state.playoff/currentCompetition(), porque a resolução só por IA de uma
  // competição que o utilizador não joga (simulateAiPlayoffIfNeeded) tem de poder correr mesmo
  // que currentCompetition() seja outra qualquer (ou até tenha o SEU PRÓPRIO playoff em curso,
  // interativo) — usar sempre a competição explícita evita que uma resolução em segundo plano
  // sobreponha o quadro em curso do utilizador.
  function checkPlayoffPhaseCompletion(holder){
    holder = holder || currentCompetition();
    const playoff = holder.playoff;
    const phase = playoff.phase;
    const seriesList = playoff.series[phase];
    // O Turno Preliminar (fase "PR", só Serie A1) nunca ganha ".winner" por finishPlayoffGame
    // (ver o guarda aggregateTie lá) — a decisão é feita aqui mesmo, só depois de ambas as mãos
    // jogadas, por isso o critério de conclusão desta fase é "2 jogos por eliminatória", não
    // "tem vencedor".
    const allDone = phase==="PR" ? seriesList.every(s=>s.games.length>=2) : seriesList.every(s=>s.winner);
    const rank = id => playoff.seeds.indexOf(id);
    const orderTopBottom = (a,b) => rank(a)<rank(b) ? [a,b] : [b,a];
    const cfg = PLAYOFF_DIVISION_CONFIG[holder.divisionId] || PLAYOFF_DIVISION_CONFIG.placard;
    const isPlacard = holder.divisionId==="placard";
    if(allDone){
      if(phase==="PR"){
        // Vencedor de cada eliminatória a duas mãos por golos agregados; em caso de empate
        // agregado, vence quem tinha melhor classificação na fase regular (regulamento italiano:
        // sem prolongamento nem grandes penalidades no Turno Preliminar). teamTop é sempre, por
        // construção (ver createPlayoffBracket), o melhor classificado das duas equipas — por
        // isso o desempate por golos empatados favorecer teamTop já implementa a regra correta.
        seriesList.forEach(s=>{
          let golosTop=0, golosBottom=0;
          s.games.forEach(g=>{
            golosTop += (g.home===s.teamTop ? g.homeScore : g.awayScore);
            golosBottom += (g.home===s.teamBottom ? g.homeScore : g.awayScore);
          });
          s.winner = golosTop>=golosBottom ? s.teamTop : s.teamBottom;
          // Correção (2026-09-27, mesmo pedido): só notícia se o clube do utilizador jogar esta
          // eliminatória do Turno Preliminar.
          if(s.teamTop===state.userTeamId || s.teamBottom===state.userTeamId){
            pushNews(state.currentDate, `${teamLinkHtml(s.winner)} apura-se para os 1/4 de Final da ${cfg.championLabel} após o Turno Preliminar (${golosTop}-${golosBottom} no agregado).`, "sistema");
          }
          // Correção (verificação pedida pelo utilizador): o Turno Preliminar da Serie A1 nunca
          // dizia explicitamente quando era o clube do utilizador a ser eliminado aqui (só o
          // vencedor era anunciado) — mesmo padrão da eliminação normal em finishPlayoffGame.
          const loserId = s.winner===s.teamTop ? s.teamBottom : s.teamTop;
          if(loserId===state.userTeamId){
            pushNews(state.currentDate, `${teamLinkHtml(state.userTeamId)} foi eliminado da ${cfg.championLabel} ${seasonLabel(state.season)} no Turno Preliminar, após perder para ${teamLinkHtml(s.winner)} (${golosTop}-${golosBottom} no agregado).`, "sistema", `${myTeam().name} eliminado do Playoff`);
          }
        });
        const directSeeds = playoff.seeds.slice(0,6);
        const prWinners = seriesList.map(s=>s.winner).sort((a,b)=>rank(a)-rank(b));
        buildQuarterFinalsFromSeeds(holder, directSeeds.concat(prWinners));
      } else if(phase==="QF"){
        const w = seriesList.map(s=>s.winner);
        const [t1,b1] = orderTopBottom(w[0], w[3]);
        const [t2,b2] = orderTopBottom(w[1], w[2]);
        playoff.series.SF = [ makeSeries(t1,b1,5,"1/2 Final 1",cfg.sfFinalVenuePattern,playoff.seeds,holder.id), makeSeries(t2,b2,5,"1/2 Final 2",cfg.sfFinalVenuePattern,playoff.seeds,holder.id) ];
        playoff.phase = "SF";
        // Correção (2026-09-27, mesmo pedido do utilizador): marcos do quadro (meias/final/
        // campeão) só interessam a quem joga essa competição — a de outra divisão/país continua
        // sempre visível em Competições, só deixa de gerar notícia.
        if(holder.id===state.userCompetitionId) pushNews(state.currentDate, `Meias-finais definidas${isPlacard?"":" ("+cfg.championLabel+")"}: ${teamLinkHtml(t1)} vs ${teamLinkHtml(b1)} · ${teamLinkHtml(t2)} vs ${teamLinkHtml(b2)}.`, "sistema");
      } else if(phase==="SF"){
        const w = seriesList.map(s=>s.winner);
        const [t,b] = orderTopBottom(w[0], w[1]);
        playoff.series.F = [ makeSeries(t,b,5,"Final",cfg.sfFinalVenuePattern,playoff.seeds,holder.id) ];
        playoff.phase = "F";
        if(holder.id===state.userCompetitionId) pushNews(state.currentDate, `FINAL definida${isPlacard?"":" ("+cfg.championLabel+")"}: ${teamLinkHtml(t)} vs ${teamLinkHtml(b)} (à melhor de 5 jogos)!`, "sistema");
      } else if(phase==="F"){
        const champion = seriesList[0].winner;
        state[cfg.championField] = champion;
        if(cfg.runnerUpField){
          const finalSeries = seriesList[0];
          state[cfg.runnerUpField] = champion===finalSeries.teamTop ? finalSeries.teamBottom : finalSeries.teamTop;
        }
        if(holder.id===state.userCompetitionId) pushNews(state.currentDate, isPlacard
          ? `🏆 ${teamLinkHtml(champion)} SAGRA-SE CAMPEÃO do Campeonato Placard ${seasonLabel(state.season)}!`
          : `🏆 ${teamLinkHtml(champion)} SAGRA-SE CAMPEÃO da ${cfg.championLabel} ${seasonLabel(state.season)}!`, "sistema");
        if(holder.id===state.userCompetitionId) state.playoffActive = false;
      }
    }
    // O resto só interessa quando é o próprio quadro do utilizador a ser avaliado — uma
    // resolução em segundo plano (IA) não deve mexer no botão "Continuar", na data da hub nem
    // repintar o separador de competições, que refletem sempre a competição do utilizador.
    if(holder.id===state.userCompetitionId){
      if(state.playoffActive) playoff.nextGameDate = addDays(state.currentDate, 4);
      document.getElementById("continuarBtn").disabled = false;
      renderHubDate();
      if(document.getElementById("viewCompeticoes") && !document.getElementById("viewCompeticoes").classList.contains("hidden")) renderCompetitionView();
    }
  }
  function processPlayoffMatchday(){
    // Correção (bug real, encontrado num teste alargado de 5 épocas): o "dia de jogo" interativo
    // (matchDayReady + pendingFixture) é uma vaga única, partilhada por todas as provas com jogo
    // do próprio utilizador (Taça de Portugal, Supertaça, Liguilha/Final da 2ª Divisão, Playoff).
    // Se duas provas caíssem no mesmo dia, a segunda a correr sobrepunha pendingFixture da
    // primeira sem limpar a sua própria flag pendingXxx — e o handler de fim de jogo (que testa
    // as flags por ordem fixa) acabava a atribuir o resultado à prova errada, deixando
    // pendingPlayoffSeries preso para sempre e o playoff nunca mais avançava. Se a vaga de hoje já
    // estiver ocupada, adia-se tudo (incluindo os jogos IA-IA desta fase) para o dia seguinte —
    // o chamador (processPhaseFiveFinalsForCurrentDate) só invoca isto quando currentDate já
    // chegou ou passou nextGameDate, por isso a nova tentativa amanhã é garantida.
    if(state.matchDayReady) return false;
    const seriesList = state.playoff.series[state.playoff.phase];
    const active = seriesList.filter(s=>!s.winner);
    const userSeries = active.find(s=>s.teamTop===state.userTeamId || s.teamBottom===state.userTeamId);
    active.forEach(s => { if(s!==userSeries) playOneSeriesGameQuick(s); });
    renderTeams(); renderStats();
    if(!userSeries){ checkPlayoffPhaseCompletion(); return; }

    const { home, away } = seriesGameSides(userSeries);
    state.pendingProvisional = {
      mine: ensureMinimumSquad(myTeam()),
      opp: ensureMinimumSquad(state.teams[home===state.userTeamId?away:home]),
    };
    if(state.convocadosSelecionados) state.pendingProvisional.mine.forEach(p => { state.convocadosSelecionados[p.id] = true; });
    state.pendingPlayoffSeries = userSeries;
    state.pendingFixture = { home, away };
    state.pendingSuspensionServing = { home: getSuspendedIds(home), away: getSuspendedIds(away) };
    state.matchDayReady = true;
  }
  // Liguilha de promoção da 2ª Divisão (2º da Zona Norte vs. 2º da Zona Sul, a duas mãos) e
  // Final da 2ª Divisão (1º do Norte vs. 1º do Sul, pelo título — sem promoção associada,
  // apenas prestígio). Extraídas para funções autónomas porque têm de aparecer sempre,
  // independentemente de qual competição estiver a ser vista no ecrã (ver renderCompetitionView
  // em 10-estatisticas.js) — antes só apareciam quando se via especificamente o Placard.
  function promotionTieCard(){
    const tie = state.promotionTie;
    if(!tie) return "";
    const [a,b] = tie.participants;
    const gamesTxt = tie.games.map((g,i)=>{
      const marcador = g.played ? `${g.homeScore}-${g.awayScore}${g.soWinner?' (g.p.)':''}` : "por jogar";
      return `J${i+1} (${fmtDateShort(new Date(g.date))}): ${teamLinkHtml(g.home)} ${marcador} ${teamLinkHtml(g.away)}`;
    }).join("<br>");
    return `<div class="eyebrow" style="margin:14px 0 8px;">CN 2.ª Divisão Apuramento Promoção</div>
      <div class="mesa-card" style="background:rgba(0,0,0,0.03);color:var(--texto);margin-bottom:8px;">
        <div class="t" style="color:var(--texto-mute);">${teamLinkHtml(a)} vs ${teamLinkHtml(b)}${tie.status==="concluida"?" — concluída":""}</div>
        <div style="font-size:11px;color:var(--texto-mute);margin-top:4px;">${gamesTxt}</div>
        ${tie.winner?`<div style="font-size:12px;font-weight:700;color:var(--verde-ok);margin-top:4px;">✓ Vencedor — promovido ao Campeonato Placard: ${teamLinkHtml(tie.winner)}</div>`:""}
      </div>`;
  }
  function secondDivisionFinalCard(){
    const final = state.secondDivisionFinal;
    if(!final) return "";
    const [a,b] = final.participants;
    const gamesTxt = final.games.map((g,i)=>{
      const marcador = g.played ? `${g.homeScore}-${g.awayScore}${g.soWinner?' (g.p.)':''}` : "por jogar";
      return `J${i+1} (${fmtDateShort(new Date(g.date))}): ${teamLinkHtml(g.home)} ${marcador} ${teamLinkHtml(g.away)}`;
    }).join("<br>");
    return `<div class="eyebrow" style="margin:14px 0 8px;">CN 2.ª Divisão Apuramento Campeão</div>
      <div class="mesa-card" style="background:rgba(0,0,0,0.03);color:var(--texto);margin-bottom:8px;">
        <div class="t" style="color:var(--texto-mute);">${teamLinkHtml(a)} vs ${teamLinkHtml(b)}${final.status==="concluida"?" — concluída":""}</div>
        <div style="font-size:11px;color:var(--texto-mute);margin-top:4px;">${gamesTxt}</div>
        ${final.winner?`<div style="font-size:12px;font-weight:700;color:var(--verde-ok);margin-top:4px;">🏆 Campeão da 2.ª Divisão ${seasonLabel(state.season)}: ${teamLinkHtml(final.winner)} (sem promoção associada — só prestígio)</div>`:""}
      </div>`;
  }
  // CN 3.ª Divisão Apuramento Campeão/Promoção: mini-ligas de 4 equipas — mostradas sempre,
  // independentemente de qual competição estiver a ser vista (mesma correção aplicada acima
  // à Liguilha/Final da 2ª Divisão). Usa apuramentoStandings (não standingsForCompetition),
  // porque as duas mini-ligas partilham equipas com as 4 zonas e team.stats fica contaminado.
  function apuramentoCardHtml(compId, titulo, notaVencedor){
    const comp = state.competitions[compId];
    if(!comp) return "";
    const table = apuramentoStandings(comp);
    const linhas = table.map((t,i)=>`${i+1}.º ${teamLinkHtml(t.id)}`).join(" · ");
    const jogosTxt = comp.fixtures.flat().filter(g=>g.played).map(g=>`${teamLinkHtml(g.home)} ${g.homeScore}-${g.awayScore} ${teamLinkHtml(g.away)}`).slice(-6).join("<br>");
    return `<div class="eyebrow" style="margin:14px 0 8px;">${titulo}</div>
      <div class="mesa-card" style="background:rgba(0,0,0,0.03);color:var(--texto);margin-bottom:8px;">
        <div class="t" style="color:var(--texto-mute);">${linhas}${comp.status==="concluida"?" — concluída":""}</div>
        ${jogosTxt?`<div style="font-size:11px;color:var(--texto-mute);margin-top:4px;">Últimos resultados:<br>${jogosTxt}</div>`:''}
        ${comp.status==="concluida"?`<div style="font-size:12px;font-weight:700;color:var(--verde-ok);margin-top:4px;">${notaVencedor(table)}</div>`:""}
      </div>`;
  }
  function terceiraDivisaoApuramentoCard(){
    return apuramentoCardHtml("3div-apuramento-campeao-2026-27","CN 3.ª Divisão Apuramento Campeão",
        table=>`🏆 Campeão da 3.ª Divisão ${seasonLabel(state.season)}: ${teamLinkHtml(table[0].id)} (sem promoção associada — só prestígio)`)
      + apuramentoCardHtml("3div-apuramento-promocao-2026-27","CN 3.ª Divisão Apuramento Promoção",
        table=>`✓ Sobem à 2.ª Divisão: ${teamLinkHtml(table[0].id)} e ${teamLinkHtml(table[1].id)}`);
  }
  // Taça de Portugal: mostrada sempre na aba Playoff, independentemente de qual competição
  // estiver a ser vista — mesmo princípio já aplicado à Liguilha/Final da 2ª Divisão e ao
  // Apuramento da 3ª. Dado o quadro poder ter até 32 eliminatórias em simultâneo, mostra-se a
  // fase atual, o percurso do clube do utilizador (se ainda estiver na prova) e o campeão
  // quando decidido — não a árvore completa.
  function tacaPortugalCard(){
    const tp = state.tacaPortugal;
    if(!tp) return "";
    const fasesConcluidas = TACA_FASES.filter(f=>tp.jogos[f] && tp.jogos[f].length && tp.jogos[f].every(j=>j.played));
    const historicoUtilizador = [];
    TACA_FASES.forEach(fase=>{
      const jogo = (tp.jogos[fase]||[]).find(j=>j.home===state.userTeamId||j.away===state.userTeamId);
      if(jogo) historicoUtilizador.push({fase,jogo});
    });
    const percursoHtml = historicoUtilizador.map(({fase,jogo})=>{
      const marcador = jogo.played ? `${jogo.homeScore}-${jogo.awayScore}${jogo.soWinner?' (g.p.)':''}` : "por jogar";
      const venceu = jogo.played && tacaTieWinner(jogo)===state.userTeamId;
      return `${TACA_FASE_LABEL[fase].replace('Taça de Portugal — ','')}: ${teamLinkHtml(jogo.home)} ${marcador} ${teamLinkHtml(jogo.away)}${jogo.played?(venceu?' ✓':' ✗'):''}`;
    }).join("<br>");
    const statusHtml = tp.fase==="concluida"
      ? `<div style="font-size:12px;font-weight:700;color:var(--verde-ok);margin-top:4px;">🏆 Campeão da Taça de Portugal ${seasonLabel(state.season)}: ${teamLinkHtml(tp.campeao)}</div>`
      : `<div style="font-size:11px;color:var(--texto-mute);margin-top:4px;">Fase atual: ${TACA_FASE_LABEL[tp.fase]}</div>`;
    return `<div class="eyebrow" style="margin:14px 0 8px;">Taça de Portugal</div>
      <div class="mesa-card" style="background:rgba(0,0,0,0.03);color:var(--texto);margin-bottom:8px;">
        ${percursoHtml?`<div style="font-size:11px;color:var(--texto-mute);">${percursoHtml}</div>`:'<div style="font-size:11px;color:var(--texto-mute);">O teu clube ainda não tem eliminatória agendada nesta fase.</div>'}
        ${statusHtml}
      </div>`;
  }
  function renderPlayoffTab(){
    const box = document.getElementById("tabPlayoff");
    if(!box) return;
    // Correção: esta função é sempre e só sobre o playoff da competição de topo do UTILIZADOR
    // (state.playoff aponta sempre para currentCompetition(), nunca para a competição vista no
    // ecrã — ver o getter em 02-estado.js) — mas acrescentava incondicionalmente os cartões da
    // liguilha/apuramento da 2ª e 3ª Divisão no fim, mesmo quando se está mesmo a ver o Placard
    // (onde esse conteúdo não faz sentido nenhum). Esses cartões já são mostrados nos sítios
    // certos por renderCompetitionView, quando a competição vista é a 2ª ou a 3ª Divisão — não
    // devem duplicar-se aqui.
    if(!state.playoff){ box.innerHTML = '<p style="font-size:12px;color:var(--texto-mute);">O playoff só começa depois da fase regular (26 jornadas).</p>'; return; }
    // Correção: o texto era sempre fixo "Campeonato Placard Play Off", nunca generalizado quando
    // a OK Liga foi acrescentada — um utilizador a jogar na OK Liga via aqui os seus próprios
    // 1/4, meias e final rotulados como se fossem do Campeonato Placard. Com a Serie A1 (que tem
    // ainda uma fase extra, o Turno Preliminar) a acrescentar um terceiro país, corrige-se aqui,
    // usando sempre o championLabel da divisão de topo realmente em jogo.
    const cfg = PLAYOFF_DIVISION_CONFIG[currentCompetition().divisionId] || PLAYOFF_DIVISION_CONFIG.placard;
    const isPlacard = currentCompetition().divisionId==="placard";
    const tituloPrefix = isPlacard ? "Campeonato Placard Play Off" : `${cfg.championLabel} Play Off`;
    function seriesCard(s){
      const gamesTxt = s.games.map((g,i)=>`J${i+1}: ${teamLinkHtml(g.home)} ${g.homeScore}-${g.awayScore} ${teamLinkHtml(g.away)}${g.soWinner?' (g.p.)':''}`).join("<br>");
      // Turno Preliminar (Serie A1): eliminatória a duas mãos por golos agregados — o "wins-wins"
      // usado nas outras fases (contagem de jogos ganhos) não faz sentido aqui, mostra-se antes
      // o resultado agregado, atualizado à medida que cada mão é jogada.
      let marcadorTxt;
      if(s.aggregateTie){
        let golosTop=0, golosBottom=0;
        s.games.forEach(g=>{
          golosTop += (g.home===s.teamTop ? g.homeScore : g.awayScore);
          golosBottom += (g.home===s.teamBottom ? g.homeScore : g.awayScore);
        });
        marcadorTxt = `<div style="text-align:center;"><span style="font-family:var(--font-mono);font-weight:800;font-size:15px;">${golosTop}-${golosBottom}</span><div style="font-size:9px;color:var(--texto-mute);">agregado</div></div>`;
      } else {
        marcadorTxt = `<span style="font-family:var(--font-mono);font-weight:800;font-size:15px;">${s.wins[s.teamTop]||0}-${s.wins[s.teamBottom]||0}</span>`;
      }
      return `<div class="mesa-card" style="background:rgba(0,0,0,0.03);color:var(--texto);margin-bottom:8px;">
        <div class="t" style="color:var(--texto-mute);">${s.label}${s.winner?' — concluída':''}</div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin:4px 0;">
          <div><button class="jr-team-link" style="font-weight:700;" data-team="${s.teamTop}">${state.teams[s.teamTop].name}</button><div class="pf-seed">${seedLabel(s.teamTop, s)}</div></div>
          ${marcadorTxt}
          <div style="text-align:right;"><button class="jr-team-link" style="font-weight:700;" data-team="${s.teamBottom}">${state.teams[s.teamBottom].name}</button><div class="pf-seed">${seedLabel(s.teamBottom, s)}</div></div>
        </div>
        <div style="font-size:11px;color:var(--texto-mute);">${gamesTxt||"Ainda sem jogos."}</div>
        ${s.winner?`<div style="font-size:12px;font-weight:700;color:var(--verde-ok);margin-top:4px;">✓ Apurado: ${teamLinkHtml(s.winner)}</div>`:''}
      </div>`;
    }
    const p = state.playoff;
    const temTurnoPreliminar = p.series.PR && p.series.PR.length>0;
    box.innerHTML = `
      ${temTurnoPreliminar ? `<div class="eyebrow" style="margin-bottom:8px;">${tituloPrefix} — Turno Preliminar</div>${p.series.PR.map(seriesCard).join("")}` : ''}
      ${p.series.QF.length ? `<div class="eyebrow" style="margin:${temTurnoPreliminar?'14px':'0'} 0 8px;">${tituloPrefix} — 1/4 Final</div>${p.series.QF.map(seriesCard).join("")}` : ''}
      ${p.series.SF.length ? `<div class="eyebrow" style="margin:14px 0 8px;">${tituloPrefix} — 1/2 Final</div>${p.series.SF.map(seriesCard).join("")}` : ''}
      ${p.series.F.length ? `<div class="eyebrow" style="margin:14px 0 8px;">${tituloPrefix} — Final</div>${p.series.F.map(seriesCard).join("")}` : ''}
    `;
  }


  // =================================================================
  // Fase 5: liguilha de promocao e transicao 1.a/2.a Divisao
  // =================================================================
  function competitionByDivisionZone(divisionId,zona){
    return Object.values(state.competitions).find(c=>c.divisionId===divisionId && (zona==null || c.zona===zona)) || null;
  }
  function competitionIdForTeam(teamId){
    const c=Object.values(state.competitions).find(comp=>comp.teamIds.includes(teamId));
    return c ? c.id : null;
  }
  function teamMatchPoints(hs,as){ return hs>as ? [3,0] : as>hs ? [0,3] : [1,1]; }
  // Correção (auditoria, bug crítico #1): nada impedia uma equipa B de ser promovida ao
  // Placard (ou até de ser campeã nacional, via subida direta ou liguilha) — a classificação
  // desportiva de uma equipa B é legítima (pode terminar em 1.º na sua zona), mas a elegibilidade
  // para subir ao escalão principal não é a mesma coisa. Uma equipa B nunca é elegível para o
  // Placard; a vaga passa sempre para o próximo clube elegível na tabela.
  function eligiblePromotionRanking(table){
    return table.filter(t=>!isBTeamId(t.id));
  }
  function maybeStartPromotionTie(){
    if(state.promotionTie) return;
    const norte=competitionByDivisionZone("2div","norte"), sul=competitionByDivisionZone("2div","sul");
    if(!norte || !sul || norte.status!=="concluida" || sul.status!=="concluida") return;
    const nTable=standingsForCompetition(norte.id), sTable=standingsForCompetition(sul.id);
    const nEligible=eligiblePromotionRanking(nTable), sEligible=eligiblePromotionRanking(sTable);
    if(nEligible.length<2 || sEligible.length<2) return;
    const northSecond=nEligible[1].id, southSecond=sEligible[1].id;
    state.promotionTie={
      id:"2div-liguilha-"+seasonLabel(state.season), status:"ativa",
      participants:[northSecond,southSecond], games:[
        {home:northSecond,away:southSecond,date:addDays(state.currentDate,4),played:false,homeScore:0,awayScore:0,soWinner:null},
        {home:southSecond,away:northSecond,date:addDays(state.currentDate,8),played:false,homeScore:0,awayScore:0,soWinner:null},
      ], winner:null,
    };
    pushNews(state.currentDate,`CN 2.ª Divisão Apuramento Promoção definido: ${teamLinkHtml(northSecond)} frente a ${teamLinkHtml(southSecond)}, a duas maos.`,"sistema");
  }
  function finishPromotionTieIfReady(){
    const tie=state.promotionTie;
    if(!tie || tie.status!=="ativa" || !tie.games.every(g=>g.played)) return;
    const pts={[tie.participants[0]]:0,[tie.participants[1]]:0};
    const goals={[tie.participants[0]]:0,[tie.participants[1]]:0};
    tie.games.forEach(g=>{
      const p=teamMatchPoints(g.homeScore,g.awayScore);
      pts[g.home]+=p[0]; pts[g.away]+=p[1]; goals[g.home]+=g.homeScore; goals[g.away]+=g.awayScore;
    });
    const [a,b]=tie.participants;
    if(pts[a]!==pts[b]) tie.winner=pts[a]>pts[b]?a:b;
    else if(goals[a]!==goals[b]) tie.winner=goals[a]>goals[b]?a:b;
    else {
      tie.winner=Math.random()<0.5?a:b;
      tie.games[1].soWinner=tie.games[1].home===tie.winner?"home":"away";
      pushNews(state.currentDate,`O CN 2.ª Divisão Apuramento Promoção terminou empatado em pontos e golos. ${teamLinkHtml(tie.winner)} venceu nas grandes penalidades.`,"sistema");
    }
    tie.status="concluida";
    pushNews(state.currentDate,`${teamLinkHtml(tie.winner)} venceu o CN 2.ª Divisão Apuramento Promoção e conquistou a terceira vaga de promocao ao Campeonato Placard.`,"sistema");
  }
  function recordPromotionTieResult(gameIndex,hs,as){
    const tie=state.promotionTie, game=tie&&tie.games[gameIndex];
    if(!game || game.played) return;
    game.played=true; game.homeScore=hs; game.awayScore=as;
    pushNews(state.currentDate,`CN 2.ª Divisão Apuramento Promoção: ${teamLinkHtml(game.home)} ${hs}-${as} ${teamLinkHtml(game.away)}.`,"jogo");
    finishPromotionTieIfReady();
  }
  function processPromotionTieForCurrentDate(){
    const tie=state.promotionTie;
    if(!tie || tie.status!=="ativa") return false;
    // Correção (bug real, teste alargado de 5 épocas): "g.date<=currentDate" em vez de
    // sameDay — se o dia exato deste jogo coincidir com o de outra prova do utilizador e a vaga
    // do dia já estiver ocupada (ver guarda abaixo), a data exata passa e sameDay nunca mais
    // voltaria a ser verdade, perdendo o jogo para sempre. Com "chegou ou já passou" a tentativa
    // repete-se no dia seguinte, já com a vaga livre.
    const gameIndex=tie.games.findIndex(g=>!g.played && g.date<=state.currentDate);
    if(gameIndex<0) return false;
    const game=tie.games[gameIndex];
    const involvesUser=game.home===state.userTeamId || game.away===state.userTeamId;
    if(!involvesUser){
      const res=simulateMatchToCompletion(game.home,game.away,false,false,"liguilha-promocao");
      recordPromotionTieResult(gameIndex,res.home,res.away); return true;
    }
    // Correção: mesma vaga única (matchDayReady/pendingFixture) partilhada com o Playoff, a Taça
    // de Portugal, a Supertaça e a Final da 2ª Divisão — se já estiver ocupada hoje por outra
    // prova, não se sobrepõe (isso corrompia o resultado da prova errada); fica por jogar até à
    // próxima chamada com a vaga livre.
    if(state.matchDayReady) return false;
    const oppId=game.home===state.userTeamId?game.away:game.home;
    state.pendingProvisional={mine:ensureMinimumSquad(myTeam()),opp:ensureMinimumSquad(state.teams[oppId])};
    state.pendingFixture=game; state.pendingPromotionTieGameIndex=gameIndex;
    state.pendingSuspensionServing={home:getSuspendedIds(game.home),away:getSuspendedIds(game.away)};
    state.matchDayReady = true; return true;
  }
  // Correção (bug real, reportado pelo utilizador: "não consegui ver o playoff da liga placard
  // nem apareceu noticia com o campeao nacional", a jogar com um clube fora do Placard, ex.: o
  // Tojal, na 2ª Divisão): esta função resolvia o playoff do Placard às escuras — três "rondas"
  // cegas com simulateMatchToCompletion direto, sem nunca preencher state.playoff (a estrutura
  // que renderPlayoffTab() lê para desenhar o quadro) e só com UMA notícia seca no fim, fácil de
  // perder no meio do resto. Um utilizador fora do Placard que fosse ver Competições > Placard >
  // Playoff ficava preso para sempre em "só começa depois da fase regular", mesmo depois de o
  // título já estar decidido. Passa a montar o MESMO quadro QF/SF/Final que a via interativa usa
  // (makeSeries/playOneSeriesGameQuick/checkPlayoffPhaseCompletion, mais acima neste ficheiro) e
  // a resolver série a série, um jogo de cada vez por série ativa — exatamente a mesma cadência e
  // as mesmas notícias por fase (quartos apurados, meias definidas, final definida, 🏆 campeão) de
  // quem joga no Placard. playoffActive fica sempre false (não há dia de jogo interativo nenhum a
  // aguardar — continua a resolver-se tudo de uma só vez), mas o quadro final fica gravado em
  // state.playoff, consultável a qualquer momento.
  // Resolve integralmente por IA, num só passo, o playoff de uma divisão de topo (Placard ou OK
  // Liga) sempre que o utilizador NÃO a esteja a jogar — exatamente como já acontecia só para o
  // Placard, agora parametrizado por divisionId (ver PLAYOFF_DIVISION_CONFIG). Escreve sempre
  // diretamente em comp.playoff (a própria competição, nunca em state.playoff/
  // currentCompetition()) — se escrevesse na competição atualmente vista pelo utilizador, uma
  // resolução em segundo plano do Placard podia sobrepor-se ao quadro interativo da OK Liga que
  // o utilizador esteja mesmo a jogar nesse momento, e vice-versa.
  function simulateAiPlayoffIfNeeded(divisionId){
    const comp = competitionByDivisionZone(divisionId, null);
    const cfg = PLAYOFF_DIVISION_CONFIG[divisionId];
    if(!comp || !cfg || comp.status!=="concluida" || state[cfg.championField]) return;
    if(state.userCompetitionId===comp.id) return;
    createPlayoffBracket(comp);
    comp.playoff.nextGameDate = state.currentDate;
    let guard=0;
    while((comp.playoff.phase!=="F" || !comp.playoff.series.F[0].winner) && guard<40){
      guard++;
      const seriesList = comp.playoff.series[comp.playoff.phase];
      seriesList.filter(s=>!s.winner).forEach(s=>playOneSeriesGameQuick(s));
      checkPlayoffPhaseCompletion(comp);
    }
  }
  function simulateAiPlacardPlayoffIfNeeded(){ simulateAiPlayoffIfNeeded("placard"); }
  function simulateAiOkLigaPlayoffIfNeeded(){ simulateAiPlayoffIfNeeded("ok-liga"); }
  function simulateAiSerieA1PlayoffIfNeeded(){ simulateAiPlayoffIfNeeded("serie-a1"); }
  // Final da 2ª Divisão (1.º do Norte vs. 1.º do Sul, a duas mãos) — sem promoção associada
  // (essa vaga já é decidida pela Liguilha, entre os 2.os classificados), só o título de
  // campeão da 2ª Divisão e algum prestígio (pequeno bónus de reputação) para o vencedor.
  // Segue exatamente o mesmo padrão da Liguilha de Promoção, incluindo o jogo interativo
  // quando o próprio clube do utilizador está envolvido.
  function maybeStartSecondDivisionFinal(){
    if(state.secondDivisionFinal) return;
    const norte=competitionByDivisionZone("2div","norte"), sul=competitionByDivisionZone("2div","sul");
    if(!norte || !sul || norte.status!=="concluida" || sul.status!=="concluida") return;
    const nTable=standingsForCompetition(norte.id), sTable=standingsForCompetition(sul.id);
    if(!nTable.length || !sTable.length) return;
    const northFirst=nTable[0].id, southFirst=sTable[0].id;
    state.secondDivisionFinal={
      id:"2div-final-"+seasonLabel(state.season), status:"ativa",
      participants:[northFirst,southFirst], games:[
        {home:northFirst,away:southFirst,date:addDays(state.currentDate,5),played:false,homeScore:0,awayScore:0,soWinner:null},
        {home:southFirst,away:northFirst,date:addDays(state.currentDate,9),played:false,homeScore:0,awayScore:0,soWinner:null},
      ], winner:null,
    };
    pushNews(state.currentDate,`CN 2.ª Divisão Apuramento Campeão definido: ${teamLinkHtml(northFirst)} frente a ${teamLinkHtml(southFirst)}, a duas mãos, pelo título de campeão da 2.ª Divisão (sem promoção associada — essa vaga já foi decidida pelo Apuramento Promoção).`,"sistema");
  }
  function finishSecondDivisionFinalIfReady(){
    const final=state.secondDivisionFinal;
    if(!final || final.status!=="ativa" || !final.games.every(g=>g.played)) return;
    const pts={[final.participants[0]]:0,[final.participants[1]]:0};
    const goals={[final.participants[0]]:0,[final.participants[1]]:0};
    final.games.forEach(g=>{
      const p=teamMatchPoints(g.homeScore,g.awayScore);
      pts[g.home]+=p[0]; pts[g.away]+=p[1]; goals[g.home]+=g.homeScore; goals[g.away]+=g.awayScore;
    });
    const [a,b]=final.participants;
    if(pts[a]!==pts[b]) final.winner=pts[a]>pts[b]?a:b;
    else if(goals[a]!==goals[b]) final.winner=goals[a]>goals[b]?a:b;
    else {
      final.winner=Math.random()<0.5?a:b;
      final.games[1].soWinner=final.games[1].home===final.winner?"home":"away";
      pushNews(state.currentDate,`O CN 2.ª Divisão Apuramento Campeão terminou empatado em pontos e golos. ${teamLinkHtml(final.winner)} venceu nas grandes penalidades.`,"sistema");
    }
    final.status="concluida";
    const team = state.teams[final.winner];
    if(team){
      team.reputacaoPontos = clamp((team.reputacaoPontos!=null?team.reputacaoPontos:normalizeClubReputation(team.reputacao, team)) + 2, 5, 99);
      team.reputacao = reputationFromPoints(team.reputacaoPontos);
    }
    pushNews(state.currentDate,`🏆 ${teamLinkHtml(final.winner)} sagrou-se Campeão do CN 2.ª Divisão ${seasonLabel(state.season)}! Sem promoção associada, mas ganha algum prestígio.`,"sistema");
  }
  function recordSecondDivisionFinalResult(gameIndex,hs,as){
    const final=state.secondDivisionFinal, game=final&&final.games[gameIndex];
    if(!game || game.played) return;
    game.played=true; game.homeScore=hs; game.awayScore=as;
    pushNews(state.currentDate,`CN 2.ª Divisão Apuramento Campeão: ${teamLinkHtml(game.home)} ${hs}-${as} ${teamLinkHtml(game.away)}.`,"jogo");
    finishSecondDivisionFinalIfReady();
  }
  function processSecondDivisionFinalForCurrentDate(){
    const final=state.secondDivisionFinal;
    if(!final || final.status!=="ativa") return false;
    // Correção: ver nota equivalente em processPromotionTieForCurrentDate — "chegou ou já
    // passou" em vez de sameDay, para não perder o jogo para sempre se a vaga do dia estiver
    // ocupada por outra prova.
    const gameIndex=final.games.findIndex(g=>!g.played && g.date<=state.currentDate);
    if(gameIndex<0) return false;
    const game=final.games[gameIndex];
    const involvesUser=game.home===state.userTeamId || game.away===state.userTeamId;
    if(!involvesUser){
      const res=simulateMatchToCompletion(game.home,game.away,false,false,"final-2div");
      recordSecondDivisionFinalResult(gameIndex,res.home,res.away); return true;
    }
    // Correção: mesma vaga única partilhada com o Playoff/Taça/Supertaça/Liguilha — não se
    // sobrepõe se já estiver ocupada hoje (ver nota em processPromotionTieForCurrentDate).
    if(state.matchDayReady) return false;
    const oppId=game.home===state.userTeamId?game.away:game.home;
    state.pendingProvisional={mine:ensureMinimumSquad(myTeam()),opp:ensureMinimumSquad(state.teams[oppId])};
    state.pendingFixture=game; state.pendingSecondDivisionFinalGameIndex=gameIndex;
    state.pendingSuspensionServing={home:getSuspendedIds(game.home),away:getSuspendedIds(game.away)};
    state.matchDayReady = true; return true;
  }
  // OK Liga Plata (2.ª divisão espanhola, 2026-10-21): eliminatória de promoção entre o 2.º classificado
  // elegível da zona Norte e o 2.º da zona Sur, a duas mãos (mesmo padrão da Liguilha de Promoção
  // portuguesa acima). O 1.º de cada zona sobe diretamente; o vencedor desta eliminatória é o
  // terceiro promovido à OK Liga. Equipas B nunca são elegíveis (eligiblePromotionRanking).
  function plataZoneCompetitions(){
    return { norte:competitionByDivisionZone("ok-liga-plata","norte"), sul:competitionByDivisionZone("ok-liga-plata","sul") };
  }
  function maybeStartPlataTie(){
    if(state.plataTie) return;
    const {norte,sul}=plataZoneCompetitions();
    if(!norte || !sul || norte.status!=="concluida" || sul.status!=="concluida") return;
    const nEligible=eligiblePromotionRanking(standingsForCompetition(norte.id)), sEligible=eligiblePromotionRanking(standingsForCompetition(sul.id));
    if(nEligible.length<2 || sEligible.length<2) return;
    const northSecond=nEligible[1].id, southSecond=sEligible[1].id;
    // Bases FEP 2026-27: eliminatória de ascenso a 5 e 13 de junho (sábado/domingo de 2027). Se a
    // data real já tiver passado (calendário atrasado), recorre à folga habitual a partir de hoje.
    const tieYear = 2026 + state.season;
    let d1 = new Date(tieYear,5,5), d2 = new Date(tieYear,5,13);
    if(d1.getTime() <= state.currentDate.getTime()){ d1 = addDays(state.currentDate,4); d2 = addDays(state.currentDate,8); }
    state.plataTie={
      id:"plata-liguilha-"+seasonLabel(state.season), status:"ativa",
      participants:[northSecond,southSecond], games:[
        {home:northSecond,away:southSecond,date:d1,played:false,homeScore:0,awayScore:0,soWinner:null},
        {home:southSecond,away:northSecond,date:d2,played:false,homeScore:0,awayScore:0,soWinner:null},
      ], winner:null,
    };
    pushNews(state.currentDate,`OK Liga Plata — Eliminatória de promoção definida: ${teamLinkHtml(northSecond)} frente a ${teamLinkHtml(southSecond)}, a duas mãos, pela terceira vaga na OK Liga.`,"sistema");
  }
  function finishPlataTieIfReady(){
    const tie=state.plataTie;
    if(!tie || tie.status!=="ativa" || !tie.games.every(g=>g.played)) return;
    const pts={[tie.participants[0]]:0,[tie.participants[1]]:0};
    const goals={[tie.participants[0]]:0,[tie.participants[1]]:0};
    tie.games.forEach(g=>{
      const p=teamMatchPoints(g.homeScore,g.awayScore);
      pts[g.home]+=p[0]; pts[g.away]+=p[1]; goals[g.home]+=g.homeScore; goals[g.away]+=g.awayScore;
    });
    const [a,b]=tie.participants;
    if(pts[a]!==pts[b]) tie.winner=pts[a]>pts[b]?a:b;
    else if(goals[a]!==goals[b]) tie.winner=goals[a]>goals[b]?a:b;
    else {
      tie.winner=Math.random()<0.5?a:b;
      tie.games[1].soWinner=tie.games[1].home===tie.winner?"home":"away";
      pushNews(state.currentDate,`A eliminatória de promoção da OK Liga Plata terminou empatada em pontos e golos. ${teamLinkHtml(tie.winner)} venceu nas grandes penalidades.`,"sistema");
    }
    tie.status="concluida";
    pushNews(state.currentDate,`${teamLinkHtml(tie.winner)} venceu a eliminatória de promoção da OK Liga Plata e conquistou a terceira vaga de subida à OK Liga.`,"sistema");
  }
  function recordPlataTieResult(gameIndex,hs,as){
    const tie=state.plataTie, game=tie&&tie.games[gameIndex];
    if(!game || game.played) return;
    game.played=true; game.homeScore=hs; game.awayScore=as;
    pushNews(state.currentDate,`OK Liga Plata — Eliminatória de promoção: ${teamLinkHtml(game.home)} ${hs}-${as} ${teamLinkHtml(game.away)}.`,"jogo");
    finishPlataTieIfReady();
  }
  function processPlataTieForCurrentDate(){
    const tie=state.plataTie;
    if(!tie || tie.status!=="ativa") return false;
    const gameIndex=tie.games.findIndex(g=>!g.played && g.date<=state.currentDate);
    if(gameIndex<0) return false;
    const game=tie.games[gameIndex];
    const involvesUser=game.home===state.userTeamId || game.away===state.userTeamId;
    if(!involvesUser){
      const res=simulateMatchToCompletion(game.home,game.away,false,false,"liguilha-plata");
      recordPlataTieResult(gameIndex,res.home,res.away); return true;
    }
    // Vaga única de dia de jogo partilhada com as outras provas — ver processPromotionTieForCurrentDate.
    if(state.matchDayReady) return false;
    const oppId=game.home===state.userTeamId?game.away:game.home;
    state.pendingProvisional={mine:ensureMinimumSquad(myTeam()),opp:ensureMinimumSquad(state.teams[oppId])};
    state.pendingFixture=game; state.pendingPlataTieGameIndex=gameIndex;
    state.pendingSuspensionServing={home:getSuspendedIds(game.home),away:getSuspendedIds(game.away)};
    state.matchDayReady = true; return true;
  }
  function plataTieCard(){
    const tie = state.plataTie;
    if(!tie) return "";
    const [a,b] = tie.participants;
    const gamesTxt = tie.games.map((g,i)=>{
      const marcador = g.played ? `${g.homeScore}-${g.awayScore}${g.soWinner?' (g.p.)':''}` : "por jogar";
      return `J${i+1} (${fmtDateShort(new Date(g.date))}): ${teamLinkHtml(g.home)} ${marcador} ${teamLinkHtml(g.away)}`;
    }).join("<br>");
    return `<div class="eyebrow" style="margin:14px 0 8px;">OK Liga Plata — Eliminatória de promoção</div>
      <div class="mesa-card" style="background:rgba(0,0,0,0.03);color:var(--texto);margin-bottom:8px;">
        <div class="t" style="color:var(--texto-mute);">${teamLinkHtml(a)} vs ${teamLinkHtml(b)}${tie.status==="concluida"?" — concluída":""}</div>
        <div style="font-size:11px;color:var(--texto-mute);margin-top:4px;">${gamesTxt}</div>
        ${tie.winner?`<div style="font-size:12px;font-weight:700;color:var(--verde-ok);margin-top:4px;">✓ Vencedor — promovido à OK Liga: ${teamLinkHtml(tie.winner)}</div>`:""}
      </div>`;
  }
  // CN 3.ª Divisão Apuramento Campeão e Apuramento Promoção: mini-ligas de 4 equipas a duas
  // voltas (6 jornadas, 12 jogos, tal como a competição oficial), o 1.º e o 2.º classificado de
  // cada uma das 4 zonas (Norte A/B, Sul A/B). Modeladas como competições normais (não como um
  // objeto de "tie" à parte, como a Liguilha/Final da 2ª Divisão) porque já é exatamente esse o
  // formato — todos contra todos —, e assim a simulação diária trata-as automaticamente como
  // qualquer outra competição, sem precisar de lógica interativa (a 3ª Divisão é só simulação,
  // o utilizador nunca lá joga).
  function maybeStart3divApuramentos(){
    if(state.competitions["3div-apuramento-campeao-2026-27"] || state.competitions["3div-apuramento-promocao-2026-27"]) return;
    const zonas = ["norte-a","norte-b","sul-a","sul-b"];
    const comps = zonas.map(z=>competitionByDivisionZone("3div",z));
    if(comps.some(c=>!c || c.status!=="concluida")) return;
    const tables = comps.map(c=>standingsForCompetition(c.id));
    if(tables.some(t=>t.length<2)) return;
    // O Apuramento Campeão é só título/prestígio (sem promoção associada) — uma equipa B pode
    // legitimamente vencer a sua zona e disputá-lo, exatamente como já acontecia no Placard
    // (uma equipa B pode ser campeã da 2ª Divisão, só não pode subir). Por isso usa a tabela
    // real da zona, sem filtrar equipas B.
    const campeaoIds = tables.map(t=>t[0].id);
    // Já o Apuramento Promoção decide subidas de verdade — uma equipa B nunca pode subir à 2ª
    // Divisão (nunca pode coexistir com o clube principal na mesma divisão), por isso a vaga do
    // "2º lugar" de cada zona (e a subida direta do 1º, mais abaixo) usa só as equipas elegíveis
    // (não-B), com a vaga a passar para a equipa seguinte melhor colocada quando necessário.
    const eligibleTables = tables.map(t=>t.filter(x=>!isBTeamId(x.id)));
    if(eligibleTables.some(t=>t.length<2)) return; // precisa de pelo menos 2 equipas elegíveis por zona
    const promotionWinners = eligibleTables.map(t=>t[0].id);
    const promocaoIds = eligibleTables.map(t=>t[1].id);
    // Snapshot dos vencedores de zona ELEGÍVEIS (sobem sempre), capturado ANTES de qualquer jogo
    // do apuramento acontecer — a partir daqui, os participantes vão ganhar mais pontos/golos em
    // team.stats por jogarem os apuramentos, e team.stats é partilhado/cumulativo entre
    // competições. Se a subida à 2ª Divisão fosse decidida mais tarde por nova leitura das
    // tabelas de zona, o vencedor podia sair mal identificado por contaminação de estatísticas.
    // Guardado aqui, uma única vez, enquanto ainda está limpo.
    state.terceiraDivisaoZoneWinners = promotionWinners.slice();
    // 0.2.3 (3.ª Divisão jogável): tabelas finais das 4 zonas, congeladas pela mesma razão — o
    // apuramento acrescenta jogos a team.stats e baralharia a classificação de zona dos 8 clubes
    // que o disputam (objetivos da direção, avaliação, histórico).
    state.terceiraDivisaoZoneTables = {};
    comps.forEach((c,i)=>{ state.terceiraDivisaoZoneTables[c.id] = tables[i].map(t=>t.id); });
    [
      {id:"3div-apuramento-campeao-2026-27", teamIds:campeaoIds},
      {id:"3div-apuramento-promocao-2026-27", teamIds:promocaoIds},
    ].forEach(({id,teamIds})=>{
      const fixtures = generateValidatedFixtures(teamIds);
      let date = addDays(state.currentDate,5);
      fixtures.forEach((round,idx)=>{ if(idx>0) date=addDays(date,5); round.date=new Date(date); });
      // reputacaoCompeticao 5 pontos acima do valor de base da 3ª Divisão (ver 02-estado.js) —
      // mantém a mesma diferença relativa desde que a reputação de base era 40 (apuramento a 45).
      state.competitions[id] = { id, divisionId:"3div", zona:null, epoca: state.season, teamIds, fixtures, currentRound:0, playoff:null, status:"regular", reputacaoCompeticao:35 };
    });
    // As duas mini-ligas só entram na agenda diária depois de reconstruída — rebuildGlobalAgenda
    // lê sempre state.competitions de novo, por isso basta chamar outra vez agora.
    rebuildGlobalAgenda();
    pushNews(state.currentDate, `CN 3.ª Divisão Apuramento Campeão e Apuramento Promoção definidos, com os classificados das 4 zonas.`, "sistema");
    // 0.2.3 (3.ª Divisão jogável): se o clube do utilizador está num dos apuramentos, passa a jogá-lo
    // como qualquer outra liga — a competição do utilizador muda para o apuramento (state.fixtures/
    // currentRound/jogo do dia seguem-na) e a época deixa de estar "terminada" até ele acabar.
    const uid = state.userTeamId;
    const mine = uid && ["3div-apuramento-campeao-2026-27","3div-apuramento-promocao-2026-27"].map(id=>state.competitions[id]).find(c=>c && c.teamIds.includes(uid));
    if(mine){
      state.userZonaCompetitionId = state.userCompetitionId;
      state.userCompetitionId = mine.id;
      state.seasonOver = false; state.seasonOverSinceDate = null; state.seasonCloseWaitSince = null; state.seasonCloseStuckWarned = false;
      state.playoffClinchedAnnounced = true;
      pushNews(state.currentDate, `O ${teamLinkHtml(uid)} está apurado para o ${competitionLinkHtml(mine.id)} — ${mine.id.includes("campeao")?"disputa o título de campeão da 3.ª Divisão":"luta por uma das duas vagas de subida à 2.ª Divisão"}. Primeira jornada a ${fmtDateShort(mine.fixtures[0].date)}.`, "sistema", null, {autoAdvanceStop:true});
    }
  }
  function finish3divApuramentosIfReady(){
    const campeao = state.competitions["3div-apuramento-campeao-2026-27"];
    const promocao = state.competitions["3div-apuramento-promocao-2026-27"];
    if(!campeao || !promocao || campeao.status!=="concluida" || promocao.status!=="concluida") return;
    if(state.terceiraDivisaoResultadoProcessado===state.season) return;
    const campeaoTable = apuramentoStandings(campeao);
    const campeaoId = campeaoTable[0].id;
    const team = state.teams[campeaoId];
    if(team){
      team.reputacaoPontos = clamp((team.reputacaoPontos!=null?team.reputacaoPontos:normalizeClubReputation(team.reputacao, team))+2,5,99);
      team.reputacao = reputationFromPoints(team.reputacaoPontos);
    }
    pushNews(state.currentDate, `🏆 ${teamLinkHtml(campeaoId)} sagrou-se Campeão do CN 3.ª Divisão ${seasonLabel(state.season)}!`, "sistema");
    state.terceiraDivisaoResultadoProcessado = state.season;
  }
  // Ranking próprio das mini-ligas de apuramento da 3ª Divisão, calculado diretamente dos jogos
  // já disputados (não via team.stats/standingsForCompetition). Necessário porque team.stats é
  // partilhado e cumulativo entre competições — as mesmas 4 equipas já jogaram a fase de zona
  // antes de entrarem aqui, e usar as suas estatísticas acumuladas (zona + apuramento) daria uma
  // classificação sem sentido nenhum dentro do próprio apuramento.
  function apuramentoStandings(comp){
    const pts={}, gm={}, gs={};
    comp.teamIds.forEach(id=>{pts[id]=0;gm[id]=0;gs[id]=0;});
    comp.fixtures.forEach(round=>round.forEach(g=>{
      if(!g.played) return;
      const p=teamMatchPoints(g.homeScore,g.awayScore);
      pts[g.home]+=p[0]; pts[g.away]+=p[1];
      gm[g.home]+=g.homeScore; gs[g.home]+=g.awayScore;
      gm[g.away]+=g.awayScore; gs[g.away]+=g.homeScore;
    }));
    return comp.teamIds.slice().sort((a,b)=> pts[b]-pts[a] || (gm[b]-gs[b])-(gm[a]-gs[a]) || gm[b]-gm[a]).map(id=>({id}));
  }
  function processPhaseFiveFinalsForCurrentDate(){
    simulateAiPlacardPlayoffIfNeeded(); simulateAiOkLigaPlayoffIfNeeded(); simulateAiSerieA1PlayoffIfNeeded(); maybeStartPromotionTie(); processPromotionTieForCurrentDate();
    maybeStartPlataTie(); processPlataTieForCurrentDate();
    maybeStartSecondDivisionFinal(); processSecondDivisionFinalForCurrentDate();
    maybeStart3divApuramentos(); finish3divApuramentosIfReady();
    processTacaPortugalForCurrentDate();
    processSupertacaForCurrentDate();
    // Correção (bug real, reportado pelo utilizador): a Elite Cup nunca fazia parte deste ciclo
    // diário — só era processada "manualmente" a partir de finalizePreSeasonDefeso/
    // finalizeNewSeason (uma só vez, resolvendo logo a prova inteira) e do próprio jogo do
    // utilizador. Ao contrário da Taça de Portugal e da Supertaça — já verificadas aqui todos os
    // dias, cada uma com a sua própria data-gate — a Elite Cup nunca esperava pelo calendário
    // chegar à data certa. Agora que processEliteCupForCurrentDate() só resolve quando
    // state.currentDate já chegou à data real da fase corrente, passa a ser chamada aqui também,
    // exatamente como as outras — é isto que permite acompanhá-la dia a dia, mesmo sem jogar.
    processEliteCupForCurrentDate();
    // Copa del Rey / Coppa Italia (07e-copas-nacionais.js): apuramento a meio da época (top 8 da
    // 1ª volta da OK Liga/Serie A1), depois disputadas em bloco concentrado — verificadas aqui
    // como qualquer outra prova diária, cada uma com a sua própria data-gate.
    maybeStartNationalCup("copa-del-rey"); processNationalCupForCurrentDate("copa-del-rey");
    maybeStartNationalCup("coppa-italia"); processNationalCupForCurrentDate("coppa-italia");
    // Copa de la Princesa (copa da OK Liga Plata): Final Four a 13-14 de março, apurada pela 1.ª volta da Plata.
    maybeStartCopaPrincesa(); processNationalCupForCurrentDate("copa-princesa");
    // Supercopa de España (Final Four de pré-época, 1ª semana de outubro) e Supercoppa Italiana
    // (eliminatória a duas mãos, novembro/dezembro real) — ambas iniciadas com antecedência em
    // initSupercopaEspana/initSupercoppaItaliana (chamadas de chooseClub/finalizeNewSeason, tal
    // como a Supertaça/Elite Cup), mas só resolvidas aqui, dia a dia, quando o calendário chega
    // mesmo à data de cada jogo (07f-supertacas-internacionais.js).
    processSupercopaEspanaForCurrentDate();
    processSupercoppaItalianaForCurrentDate();
    // Competições Europeias (07g-europa.js): WSE Champions League/Cup/Trophy + Ronda de
    // Qualificação, cada uma com a sua própria data-gate, exatamente como as provas acima —
    // arrancam em chooseClub()/finalizeNewSeason() (europaInitEdition), só resolvidas aqui dia a
    // dia quando o calendário chega mesmo às datas de cada jornada/eliminatória.
    processEuropaForCurrentDate();
    // Seleções Nacionais (07h-selecoes.js): mesmo padrão — a edição é preparada e anunciada
    // (sorteio+convocatória) em chooseClub()/beginDefeso(), mas cada jornada de grupo e cada
    // eliminatória só se resolve e publica a sua notícia aqui, dia a dia, quando o calendário
    // chega mesmo à sua data fixa (pedido do utilizador, 2026-09-27: "o jogo tem de começar com a
    // noticia da convocatória... depois vemos as noticias dos jogos").
    processSelecoesForCurrentDate();
  }
  function globalSeasonReadyToClose(){
    const regularDone=Object.values(state.competitions).every(c=>c.status==="concluida");
    const apCampeao=state.competitions["3div-apuramento-campeao-2026-27"], apPromocao=state.competitions["3div-apuramento-promocao-2026-27"];
    // As duas mini-ligas de apuramento da 3ª Divisão só existem depois de as 4 zonas
    // terminarem — se ainda não existirem, a época não pode fechar (regularDone já garante que
    // as 4 zonas de facto terminaram; falta confirmar que as mini-ligas foram criadas E concluídas).
    const thirdDivisionDone = !!apCampeao && apCampeao.status==="concluida" && !!apPromocao && apPromocao.status==="concluida";
    const tacaDone = !state.tacaPortugal || state.tacaPortugal.fase==="concluida";
    // Copa del Rey/Coppa Italia: ou já concluídas, ou nunca chegaram a começar por a época ter
    // fechado antes de a OK Liga/Serie A1 completarem a 1ª volta (não deveria acontecer em
    // condições normais, mas fica coberto, tal como tacaDone acima cobre o mesmo caso-limite).
    const copaDelReyDone = !state.copaDelRey || !state.copaDelRey.edicao || state.copaDelRey.edicao.fase==="concluida";
    const coppaItaliaDone = !state.coppaItalia || !state.coppaItalia.edicao || state.coppaItalia.edicao.fase==="concluida";
    const copaPrincesaDone = !state.copaPrincesa || !state.copaPrincesa.edicao || state.copaPrincesa.edicao.fase==="concluida";
    const supercoppaItalianaDone = !state.supercoppaItaliana || !state.supercoppaItaliana.jogo || state.supercoppaItaliana.jogo.concluida;
    const supercopaEspanaDone = !state.supercopaEspana || !state.supercopaEspana.edicao || state.supercopaEspana.edicao.fase==="concluida";
    // Correção (bug real reportado pelo utilizador, 2026-09-27: "apurei-me para a final da
    // champions e nao consegui jogar, a epoca acabou") — esta função nunca verificava as
    // competições europeias (state.europa.edicao — WSE Champions League/Cup/Trophy), ao
    // contrário de TODAS as outras taças (Taça de Portugal, Copa del Rey, Coppa Italia,
    // Supercoppa/Supercopa). A época fechava e chamava beginDefeso() mesmo com a Champions League
    // do utilizador ainda a meio — europaInitEdition() (07g-europa.js), ao arrancar a EDIÇÃO
    // SEGUINTE, encontrava a anterior por concluir e resolvia-a inteira por IA em segundo plano
    // via europaForceConcludeIfPending() (a proteção contra bloqueio indefinido dessa função),
    // incluindo a própria final do utilizador — que nunca chegava a ser jogada. Mesmo padrão das
    // outras taças: a época só fecha quando não há edição europeia por concluir.
    const europaDone = !state.europa || !state.europa.edicao || state.europa.edicao.concluida;
    return regularDone && !!state.placardChampion && !!state.okLigaChampion && !!state.serieA1Champion && !!state.promotionTie && state.promotionTie.status==="concluida" && (!plataZoneCompetitions().norte || (!!state.plataTie && state.plataTie.status==="concluida")) && !!state.secondDivisionFinal && state.secondDivisionFinal.status==="concluida" && thirdDivisionDone && tacaDone && copaDelReyDone && coppaItaliaDone && copaPrincesaDone && supercoppaItalianaDone && supercopaEspanaDone && europaDone;
  }
  // Diagnóstico (pedido do utilizador: "a frase fica presa no fim do playoff" — a época nunca
  // fechava e não havia forma nenhuma de perceber porquê, só a mensagem genérica "Playoff
  // terminado"). Decompõe exatamente a mesma conjunção de globalSeasonReadyToClose() nas suas
  // condições individuais, devolvendo só as que ainda estão por cumprir — usado pelo aviso de
  // "época bloqueada" em advanceOneDayOrPhaseStep (09-fluxo-epoca.js) e disponível também via
  // window.__HM2027_TEST__ para diagnóstico manual. Mantido deliberadamente sem qualquer efeito
  // colateral (só lê estado, nunca o altera).
  function globalSeasonCloseBlockers(){
    const blockers = [];
    const regularesPorConcluir = Object.values(state.competitions).filter(c=>c.status!=="concluida").map(c=>c.id);
    if(regularesPorConcluir.length) blockers.push(`competições regulares por concluir: ${regularesPorConcluir.join(", ")}`);
    if(!state.placardChampion) blockers.push("Campeonato Placard sem campeão definido");
    if(!state.okLigaChampion) blockers.push("OK Liga sem campeão definido");
    if(!state.serieA1Champion) blockers.push("Serie A1 sem campeão definido");
    if(!state.promotionTie || state.promotionTie.status!=="concluida") blockers.push("Liguilha de Promoção da 2.ª Divisão por concluir");
    if(plataZoneCompetitions().norte && (!state.plataTie || state.plataTie.status!=="concluida")) blockers.push("Eliminatória de promoção da OK Liga Plata por concluir");
    if(!state.secondDivisionFinal || state.secondDivisionFinal.status!=="concluida") blockers.push("Final da 2.ª Divisão por concluir");
    const apCampeao=state.competitions["3div-apuramento-campeao-2026-27"], apPromocao=state.competitions["3div-apuramento-promocao-2026-27"];
    if(!(!!apCampeao && apCampeao.status==="concluida" && !!apPromocao && apPromocao.status==="concluida")) blockers.push("Apuramentos da 3.ª Divisão (Campeão e/ou Promoção) por concluir");
    if(!(!state.tacaPortugal || state.tacaPortugal.fase==="concluida")) blockers.push("Taça de Portugal por concluir");
    if(!(!state.copaDelRey || !state.copaDelRey.edicao || state.copaDelRey.edicao.fase==="concluida")) blockers.push("Copa del Rey por concluir");
    if(!(!state.coppaItalia || !state.coppaItalia.edicao || state.coppaItalia.edicao.fase==="concluida")) blockers.push("Coppa Italia por concluir");
    if(!(!state.copaPrincesa || !state.copaPrincesa.edicao || state.copaPrincesa.edicao.fase==="concluida")) blockers.push("Copa de la Princesa por concluir");
    if(!(!state.supercoppaItaliana || !state.supercoppaItaliana.jogo || state.supercoppaItaliana.jogo.concluida)) blockers.push("Supercoppa Italiana por concluir");
    if(!(!state.supercopaEspana || !state.supercopaEspana.edicao || state.supercopaEspana.edicao.fase==="concluida")) blockers.push("Supercopa de España por concluir");
    // Correção (2026-09-27, mesmo bug real da Champions League por jogar): mesmo padrão das
    // taças acima, agora também para as competições europeias (state.europa.edicao).
    if(!(!state.europa || !state.europa.edicao || state.europa.edicao.concluida)){
      const ed = state.europa.edicao;
      blockers.push(`Competições europeias por concluir (Champions: ${ed.champions.fase}, Cup: ${ed.cup.fase}, Trophy: ${ed.trophy.fase})`);
    }
    return blockers;
  }
  function preferredZoneForRelegated(teamId){
    const def=CLUB_DEFS.find(d=>d.id===teamId), z=def&&(def.zonaDestino||def.zona);
    return z==="sul"?"sul":"norte";
  }
  function chooseBalancedPlacardAllocation(relegatedIds,norteSlots,sulSlots){
    if(norteSlots<0 || sulSlots<0 || norteSlots+sulSlots!==relegatedIds.length){
      throw new Error(`Vagas incompatíveis na 2.ª Divisão: Norte ${norteSlots}, Sul ${sulSlots}, despromovidos ${relegatedIds.length}.`);
    }
    const solutions=[];
    function visit(index,zones){
      if(index===relegatedIds.length){
        const northCount=zones.filter(z=>z==="norte").length;
        const southCount=zones.length-northCount;
        if(northCount!==norteSlots || southCount!==sulSlots) return;
        const penalty=zones.reduce((sum,zona,i)=>sum+(zona===preferredZoneForRelegated(relegatedIds[i])?0:10),0);
        solutions.push({zones:zones.slice(),penalty}); return;
      }
      visit(index+1,zones.concat("norte")); visit(index+1,zones.concat("sul"));
    }
    visit(0,[]);
    if(!solutions.length) throw new Error("Não foi possível equilibrar as zonas da 2.ª Divisão.");
    solutions.sort((a,b)=>a.penalty-b.penalty || a.zones.join().localeCompare(b.zones.join()));
    return solutions[0].zones;
  }
  function validateDivisionTransition(placard,norte,sul){
    const expected=14, problems=[];
    if(placard.teamIds.length!==expected) problems.push(`Placard: ${placard.teamIds.length}`);
    if(norte.teamIds.length!==expected) problems.push(`Norte: ${norte.teamIds.length}`);
    if(sul.teamIds.length!==expected) problems.push(`Sul: ${sul.teamIds.length}`);
    const all=placard.teamIds.concat(norte.teamIds,sul.teamIds);
    if(new Set(all).size!==all.length) problems.push("existem clubes repetidos entre competições");
    all.forEach(id=>{if(!state.teams[id])problems.push(`clube inexistente: ${id}`);});
    if(problems.length) throw new Error("Transição de divisões inválida: "+problems.join("; "));
    return true;
  }
  // Ligação 2ª Divisão ↔ 3ª Divisão (secção nova): descem os últimos 3 da Zona Norte e os
  // últimos 3 da Zona Sul da 2ª Divisão; sobem sempre os 4 vencedores de zona da 3ª Divisão
  // (Norte A/B, Sul A/B), mais os 2 primeiros classificados do CN 3.ª Divisão Apuramento
  // Promoção — 6 sobem, 6 descem. Norte vai sempre para Norte, Sul vai sempre para Sul (nunca
  // cruzam de região); dentro de cada região, os despromovidos entram na sub-zona (A ou B) que
  // ficar com menos equipas, para equilibrar o tamanho dos dois grupos.
  function distributeRelegatedWithinRegion(relegatedIds, compA, compB){
    relegatedIds.forEach(id=>{
      const target = compA.teamIds.length <= compB.teamIds.length ? compA : compB;
      target.teamIds.push(id);
      adaptClubFinanceToDivision(state.teams[id],state.teams[id].divisaoAtual,"3div","descida-2div"); state.teams[id].divisaoAtual="3div"; state.teams[id].zona=target.zona;
    });
  }
  // Corretivo de tamanho genérico (usado a dois níveis: entre 2div Norte/Sul, e entre as duas
  // sub-zonas de cada região da 3ª Divisão) — as regras de subida/descida definidas não
  // garantem sozinhas que cada lado se mantenha exatamente no tamanho-alvo (ver explicação mais
  // abaixo, na chamada); desloca a equipa que sobrar do lado que cresceu para o lado que
  // encolheu, entrando sempre na sub-zona/zona com menos equipas do lado de destino.
  function rebalanceTwoWay(zoneA, zoneB, targetA){
    while(zoneA.teamIds.length > targetA){
      const movedId = zoneA.teamIds.pop();
      zoneB.teamIds.push(movedId); state.teams[movedId].zona = zoneB.zona;
    }
    while(zoneA.teamIds.length < targetA){
      const movedId = zoneB.teamIds.pop();
      zoneA.teamIds.push(movedId); state.teams[movedId].zona = zoneA.zona;
    }
  }
  function applyThirdDivisionPromotionAndRelegation(frozenPlan){
    const norte2=competitionByDivisionZone("2div","norte"), sul2=competitionByDivisionZone("2div","sul");
    const nTable2=frozenPlan&&frozenPlan.nTable2||standingsForCompetition(norte2.id), sTable2=frozenPlan&&frozenPlan.sTable2||standingsForCompetition(sul2.id);
    const relegatedNorte=(frozenPlan&&frozenPlan.relegatedNorte||nTable2.slice(-3).map(t=>t.id)).slice();
    const relegatedSul=(frozenPlan&&frozenPlan.relegatedSul||sTable2.slice(-3).map(t=>t.id)).slice();

    const norteA=competitionByDivisionZone("3div","norte-a"), norteB=competitionByDivisionZone("3div","norte-b");
    const sulA=competitionByDivisionZone("3div","sul-a"), sulB=competitionByDivisionZone("3div","sul-b");
    if(!norteA || !norteB || !sulA || !sulB) return null; // 3ª Divisão ainda não inicializada (compatibilidade com saves antigos)

    // Usa o snapshot dos vencedores de zona capturado em maybeStart3divApuramentos (antes da
    // contaminação de team.stats pelos jogos do apuramento) — nunca relê as tabelas de zona
    // aqui, precisamente pelo motivo explicado nesse snapshot.
    const zoneWinners = state.terceiraDivisaoZoneWinners && state.terceiraDivisaoZoneWinners.length===4
      ? state.terceiraDivisaoZoneWinners.slice()
      : [norteA,norteB,sulA,sulB].map(comp=>standingsForCompetition(comp.id).filter(t=>!isBTeamId(t.id))[0].id);
    const apuramentoPromocao = state.competitions["3div-apuramento-promocao-2026-27"];
    const apuramentoTable = apuramentoPromocao ? apuramentoStandings(apuramentoPromocao) : [];
    const promotedFromApuramento = apuramentoTable.slice(0,2).map(t=>t.id);
    const promotedFromThird = zoneWinners.concat(promotedFromApuramento);
    if(new Set(promotedFromThird).size !== 6) throw new Error("A subida da 3.ª Divisão produziu clubes duplicados.");

    const promotedNorte = promotedFromThird.filter(id=>(state.teams[id].zona||"").startsWith("norte"));
    const promotedSul = promotedFromThird.filter(id=>(state.teams[id].zona||"").startsWith("sul"));

    // 0.2.2: o tamanho de cada região da 3.ª Divisão já não é fixo (28/27) — uma equipa B que cesse a
    // participação (ver enforceBTeamRule) reduz a região. Os alvos são os tamanhos à entrada da transição.
    const norteRegionTarget = norteA.teamIds.length + norteB.teamIds.length;
    const sulRegionTarget = sulA.teamIds.length + sulB.teamIds.length;
    [norteA,norteB,sulA,sulB].forEach(comp=>{ comp.teamIds = comp.teamIds.filter(id=>!promotedFromThird.includes(id)); });
    norte2.teamIds = norte2.teamIds.filter(id=>!relegatedNorte.includes(id)).concat(promotedNorte);
    sul2.teamIds = sul2.teamIds.filter(id=>!relegatedSul.includes(id)).concat(promotedSul);

    // Academia e Juvenis (Fase 2, 2026-09-22, decisão 9 do utilizador): um clube de 3ª divisão
    // nunca tem academia — ao subir à 2ª divisão fica elegível de imediato, por isso
    // bootstrapAcademyIfEmpty cria-lha já neste preciso momento (4 escalões preenchidos, nomes
    // do país do clube), sem esperar pela próxima admissão anual (que já correu mais cedo nesta
    // mesma chamada de beginDefeso, antes de applyPromotionAndRelegation). Idempotente e seguro
    // chamar mesmo que o clube já tivesse (por algum motivo) uma academia.
    // Staff — Treinadores (2026-09-22): mesma regra da Academia — um clube de 3ª divisão nunca
    // tem treinador próprio (fica dependente da IA genérica); ao subir fica elegível de imediato.
    promotedFromThird.forEach(id=>{ state.teams[id].__zona3=state.teams[id].zona; });   // 0.2.3: zona da 3.ª onde jogava (para a B regressar)
    promotedNorte.forEach(id=>{ adaptClubFinanceToDivision(state.teams[id],state.teams[id].divisaoAtual,"2div","promocao-3div"); state.teams[id].divisaoAtual="2div"; state.teams[id].zona="norte"; bootstrapAcademyIfEmpty(state.teams[id]); bootstrapTreinadorIfEmpty(state.teams[id]); });
    promotedSul.forEach(id=>{ adaptClubFinanceToDivision(state.teams[id],state.teams[id].divisaoAtual,"2div","promocao-3div"); state.teams[id].divisaoAtual="2div"; state.teams[id].zona="sul"; bootstrapAcademyIfEmpty(state.teams[id]); bootstrapTreinadorIfEmpty(state.teams[id]); });

    distributeRelegatedWithinRegion(relegatedNorte, norteA, norteB);
    distributeRelegatedWithinRegion(relegatedSul, sulA, sulB);

    // Corretivo de tamanho (ver comentário em rebalanceTwoWay): os 2 promovidos do Apuramento
    // Promoção podem vir de qualquer combinação de regiões (0, 1 ou 2 do Norte) — sem correção,
    // isso desequilibraria tanto a 2ª Divisão Norte/Sul como as sub-zonas da 3ª Divisão, e o
    // desequilíbrio pode compor-se ano após ano em vez de se auto-corrigir.
    // Corretivo de tamanho (ver comentário em rebalanceTwoWay): os 2 promovidos do Apuramento
    // Promoção podem vir de qualquer combinação de regiões (0, 1 ou 2 do Norte) — sem correção,
    // isso desequilibraria tanto a 2ª Divisão Norte/Sul como as regiões da 3ª Divisão, e o
    // desequilíbrio pode compor-se ano após ano em vez de se auto-corrigir. Corrige primeiro o
    // total de cada REGIÃO da 3ª Divisão (Norte = 28, Sul = 27) — rebalanceTwoWay só sabe
    // equilibrar duas zonas cuja soma já é a correta, por isso o total tem de ser corrigido antes.
    rebalanceTwoWay(norte2, sul2, 14);
    let norteRegionTotal = norteA.teamIds.length + norteB.teamIds.length;
    while(norteRegionTotal > norteRegionTarget){
      const fromZone = norteA.teamIds.length>=norteB.teamIds.length ? norteA : norteB;
      const toZone = sulA.teamIds.length<=sulB.teamIds.length ? sulA : sulB;
      const movedId = fromZone.teamIds.pop();
      toZone.teamIds.push(movedId); state.teams[movedId].zona = toZone.zona;
      norteRegionTotal--;
    }
    while(norteRegionTotal < norteRegionTarget){
      const fromZone = sulA.teamIds.length>=sulB.teamIds.length ? sulA : sulB;
      const toZone = norteA.teamIds.length<=norteB.teamIds.length ? norteA : norteB;
      const movedId = fromZone.teamIds.pop();
      toZone.teamIds.push(movedId); state.teams[movedId].zona = toZone.zona;
      norteRegionTotal++;
    }
    rebalanceTwoWay(norteA, norteB, Math.ceil(norteRegionTarget/2));
    rebalanceTwoWay(sulA, sulB, Math.floor(sulRegionTarget/2));

    delete state.competitions["3div-apuramento-campeao-2026-27"];
    delete state.competitions["3div-apuramento-promocao-2026-27"];

    return { promotedFromThird, relegatedToThird: relegatedNorte.concat(relegatedSul), apuramentoOrder: apuramentoTable.map(t=>t.id) };
  }
  // OK Liga Plata ↔ OK Liga (2026-10-21): sobem à OK Liga o 1.º elegível de cada zona da Plata e o
  // vencedor da eliminatória entre os 2.os; descem à Plata os 3 últimos da OK Liga na tabela da fase
  // regular. A Plata mantém sempre 14 + 14 clubes. Um clube despromovido nunca fica na mesma zona da
  // sua própria equipa B (regra real: principal e filial não competem no mesmo grupo). Por decisão
  // do utilizador, por agora ninguém desce da Plata (a Bronce não está modelada).
  function chooseBalancedPlataAllocation(relegatedIds,norteSlots,sulSlots){
    if(norteSlots<0 || sulSlots<0 || norteSlots+sulSlots!==relegatedIds.length){
      throw new Error(`Vagas incompatíveis na OK Liga Plata: Norte ${norteSlots}, Sur ${sulSlots}, despromovidos ${relegatedIds.length}.`);
    }
    const bZone=id=>{ const t=state.teams[id], bId=t&&t.equipaBId, b=bId&&state.teams[bId]; return b?b.zona:null; };
    const solutions=[];
    function visit(index,zones){
      if(index===relegatedIds.length){
        const northCount=zones.filter(z=>z==="norte").length;
        if(northCount!==norteSlots || zones.length-northCount!==sulSlots) return;
        const penalty=zones.reduce((sum,zona,i)=>sum+(bZone(relegatedIds[i])===zona?100:0),0);
        solutions.push({zones:zones.slice(),penalty}); return;
      }
      visit(index+1,zones.concat("norte")); visit(index+1,zones.concat("sul"));
    }
    visit(0,[]);
    if(!solutions.length) throw new Error("Não foi possível equilibrar as zonas da OK Liga Plata.");
    solutions.sort((a,b)=>a.penalty-b.penalty || a.zones.join().localeCompare(b.zones.join()));
    return solutions[0].zones;
  }
  function applySpanishPromotionAndRelegation(){
    const okLiga=competitionByDivisionZone("ok-liga",null), {norte,sul}=plataZoneCompetitions();
    if(!okLiga || !norte || !sul || !state.plataTie || state.plataTie.status!=="concluida") return null;
    const okTable=standingsForCompetition(okLiga.id), nTable=standingsForCompetition(norte.id), sTable=standingsForCompetition(sul.id);
    const nEligible=eligiblePromotionRanking(nTable), sEligible=eligiblePromotionRanking(sTable);
    if(!nEligible.length || !sEligible.length) return null;
    const promoted=[nEligible[0].id,sEligible[0].id,state.plataTie.winner];
    const relegated=okTable.slice(-3).map(t=>t.id);
    if(new Set(promoted).size!==3) throw new Error("A subida da Plata produziu clubes duplicados.");
    if(promoted.some(id=>relegated.includes(id))) throw new Error("Transição inválida: clube promovido e despromovido ao mesmo tempo (Espanha).");
    okLiga.teamIds=okLiga.teamIds.filter(id=>!relegated.includes(id)).concat(promoted);
    norte.teamIds=norte.teamIds.filter(id=>!promoted.includes(id));
    sul.teamIds=sul.teamIds.filter(id=>!promoted.includes(id));
    const allocation=chooseBalancedPlataAllocation(relegated,14-norte.teamIds.length,14-sul.teamIds.length);
    relegated.forEach((id,index)=>{
      const zona=allocation[index], competition=zona==="norte"?norte:sul;
      competition.teamIds.push(id); adaptClubFinanceToDivision(state.teams[id],state.teams[id].divisaoAtual,"ok-liga-plata","descida-ok-liga");
      state.teams[id].divisaoAtual="ok-liga-plata"; state.teams[id].zona=zona;
    });
    promoted.forEach(id=>{ adaptClubFinanceToDivision(state.teams[id],state.teams[id].divisaoAtual,"ok-liga","promocao-plata"); state.teams[id].divisaoAtual="ok-liga"; state.teams[id].zona=null; });
    const all=okLiga.teamIds.concat(norte.teamIds,sul.teamIds);
    if(okLiga.teamIds.length!==14 || norte.teamIds.length!==14 || sul.teamIds.length!==14 || new Set(all).size!==all.length)
      throw new Error(`Transição de divisões inválida (Espanha): OK Liga ${okLiga.teamIds.length}, Norte ${norte.teamIds.length}, Sur ${sul.teamIds.length}.`);
    return { promotedEs:promoted.slice(), relegatedEs:relegated.slice(), relegatedEsAllocation:Object.fromEntries(relegated.map((id,i)=>[id,allocation[i]])) };
  }

  // =================================================================
  // Regra das equipas B nas descidas (0.2.2) — Regulamento Geral do Hóquei em Patins, art. 43.º:
  //  · "No caso de a equipa principal descer à Divisão onde se encontra a equipa B, esta descerá de forma
  //    automática à divisão imediatamente inferior, independentemente da classificação desportiva."
  //  · "No caso de a equipa principal descer à divisão mais baixa cessará a participação da equipa B."
  // Corre no fim de applyPromotionAndRelegation, com as divisões já atualizadas. Aplica-se a Portugal
  // (Placard › 2.ª › 3.ª); em Espanha a Bronce não está modelada (ver regra própria da Plata).
  // =================================================================
  const PT_DIVISION_ORDER = ["placard","2div","3div"];
  function btrFindReplacement(b, ctx){
    const region = b.zona==="sul" ? "sul" : "norte";
    const inRegion = id=>{ const t=state.teams[id]; return t && t.divisaoAtual==="3div" && !isBTeamId(id) && !t.equipaExtinta && String(t.zona||"").startsWith(region); };
    const pool=[];
    (ctx.apuramentoOrder||[]).forEach(id=>pool.push(id));
    const tables=Object.keys(ctx.frozenTables||{}).filter(k=>k.startsWith("3div-")&&!k.includes("apuramento")).map(k=>ctx.frozenTables[k]);
    const maxLen=Math.max(0,...tables.map(t=>t.length));
    for(let i=1;i<maxLen;i++) tables.forEach(t=>{ if(t[i]) pool.push(t[i]); });   // 2.os, 3.os... das zonas da 3.ª Divisão
    return pool.find(inRegion) || pool.find(id=>{ const t=state.teams[id]; return t && t.divisaoAtual==="3div" && !isBTeamId(id) && !t.equipaExtinta; }) || null;
  }
  function btrDropBTeam(a,b,ctx){
    const compB2=Object.values(state.competitions).find(c=>c.divisionId==="2div" && c.teamIds.includes(b.id));
    const candId=btrFindReplacement(b,ctx);
    const cand=candId&&state.teams[candId];
    const compC3=cand&&Object.values(state.competitions).find(c=>c.divisionId==="3div" && c.teamIds.includes(candId));
    if(!compB2 || !cand || !compC3) return null;
    // Troca de lugares: a B ocupa a vaga do clube que sobe, para os tamanhos das competições não mudarem.
    compC3.teamIds=compC3.teamIds.filter(id=>id!==cand.id).concat(b.id);
    compB2.teamIds=compB2.teamIds.filter(id=>id!==b.id).concat(cand.id);
    adaptClubFinanceToDivision(cand,cand.divisaoAtual,"2div","promocao-3div");
    const bZona=b.zona;
    b.divisaoAtual="3div"; b.zona=compC3.zona;
    cand.divisaoAtual="2div"; cand.zona=bZona;
    bootstrapAcademyIfEmpty(cand); bootstrapTreinadorIfEmpty(cand);
    pushNews(state.currentDate,`Regra A/B: ${teamLinkHtml(a.id)} desceu à 2.ª Divisão, onde jogava a equipa B — a ${teamLinkHtml(b.id)} desce automaticamente à 3.ª Divisão e ${teamLinkHtml(cand.id)} ocupa a vaga na 2.ª Divisão.`,"sistema");
    return {tipo:"desce",a:a.id,b:b.id,substituto:cand.id};
  }
  function btrCeaseBTeam(a,b){
    Object.values(state.competitions).forEach(c=>{ if(c.teamIds.includes(b.id)) c.teamIds=c.teamIds.filter(id=>id!==b.id); });
    // Empréstimos: jogadores do clube emprestados a terceiros passam a regressar à equipa A; jogadores de
    // outros clubes que estavam emprestados à B voltam já aos donos.
    Object.values(state.teams).forEach(t=>(t.players||[]).forEach(p=>{ if(p.emprestimo && p.emprestimo.ownerId===b.id) p.emprestimo.ownerId=a.id; }));
    (b.players||[]).slice().forEach(p=>{
      if(p.emprestimo && p.emprestimo.destinationId===b.id){
        const owner=state.teams[p.emprestimo.ownerId];
        if(owner){ b.players=b.players.filter(x=>x.id!==p.id); owner.players.push(p); p.emprestimo=null; p.titular=false; }
      }
    });
    const moved=(b.players||[]).length;
    (b.players||[]).forEach(p=>{ archiveInternalStint(p,b); p.titular=false; p.__exB=b.id; a.players.push(p); });
    b.players=[]; b.equipaExtinta=true; a.equipaBId="";
    (state.bTeamsExtintas=state.bTeamsExtintas||[]).push({b:b.id,a:a.id,epoca:seasonLabel(state.season),zona3:a.zona||null});
    a.marketNeedDirty=true;
    pushNews(state.currentDate,`Regra A/B: ${teamLinkHtml(a.id)} desceu à 3.ª Divisão, a divisão mais baixa — cessa a participação da equipa ${escapeHtml(b.name)}; os ${moved} jogadores passam para a equipa principal.`,"sistema");
    return {tipo:"cessa",a:a.id,b:b.id,jogadores:moved};
  }
  // 0.2.3: quando a equipa principal volta a subir da 3.ª Divisão (onde a B tinha cessado), a B é
  // reativada e regressa à 3.ª Divisão, na mesma zona onde a principal jogava — essa zona fica com +1 clube.
  // Os antigos jogadores da B que ainda estejam na principal (e sejam jovens) regressam; o resto é
  // completado pela academia (ensureBTeamMinimums).
  function btrReviveBTeams(){
    const events=[];
    (state.bTeamsExtintas||[]).slice().forEach(rec=>{
      const a=state.teams[rec.a], b=state.teams[rec.b];
      if(!a || !b || !b.equipaExtinta) return;
      if(PT_DIVISION_ORDER.indexOf(a.divisaoAtual)<0 || a.divisaoAtual==="3div") return;   // só quando a principal já não está na 3.ª
      const zonaId = a.__zona3 || rec.zona3 || null;
      let comp = zonaId ? competitionByDivisionZone("3div", zonaId) : null;
      if(!comp){
        const region = (a.zona==="sul") ? "sul" : "norte";
        const A_ = competitionByDivisionZone("3div", region+"-a"), B_ = competitionByDivisionZone("3div", region+"-b");
        comp = (A_ && B_) ? (A_.teamIds.length<=B_.teamIds.length ? A_ : B_) : (A_||B_);
      }
      if(!comp) return;
      b.equipaExtinta=false; a.equipaBId=b.id;
      b.divisaoAtual="3div"; b.zona=comp.zona;
      if(!comp.teamIds.includes(b.id)) comp.teamIds.push(b.id);
      const volta=a.players.filter(p=>p.__exB===b.id && !p.emprestimo && (p.age||99)<=22 && !p.__provisional).slice(0,10);
      volta.forEach(p=>{ archiveInternalStint(p,a); a.players=a.players.filter(x=>x.id!==p.id); p.titular=false; delete p.__exB; b.players.push(p); });
      a.players.forEach(p=>{ if(p.__exB===b.id) delete p.__exB; });
      a.marketNeedDirty=true;
      state.bTeamsExtintas=state.bTeamsExtintas.filter(x=>!(x.b===b.id));
      delete a.__zona3;
      pushNews(state.currentDate,`Regra A/B: ${teamLinkHtml(a.id)} subiu da 3.ª Divisão — a equipa ${teamLinkHtml(b.id)} regressa à competição, na ${competitionLinkHtml(comp.id)}${volta.length?` (${volta.length} jogador${volta.length===1?"":"es"} voltam da equipa principal)`:""}.`,"sistema");
      events.push({tipo:"regressa",a:a.id,b:b.id,zona:comp.id,jogadores:volta.length});
    });
    if(events.length && typeof ensureBTeamMinimums==="function") events.forEach(e=>ensureBTeamMinimums(e.b));
    return events;
  }
  function enforceBTeamRule(ctx){
    const events=btrReviveBTeams();
    Object.values(state.teams).filter(a=>a.equipaBId && state.teams[a.equipaBId] && !state.teams[a.equipaBId].equipaExtinta).forEach(a=>{
      const b=state.teams[a.equipaBId], idx=PT_DIVISION_ORDER.indexOf(a.divisaoAtual);
      if(idx<0 || b.divisaoAtual!==a.divisaoAtual) return;
      const ev = idx===PT_DIVISION_ORDER.length-1 ? btrCeaseBTeam(a,b) : btrDropBTeam(a,b,ctx);
      if(ev) events.push(ev);
    });
    // Se alguma B cessou, reequilibra as duas sub-zonas de cada região da 3.ª Divisão (diferença máx. 1 clube).
    if(events.some(e=>e.tipo==="cessa")){
      const nA=competitionByDivisionZone("3div","norte-a"), nB=competitionByDivisionZone("3div","norte-b");
      const sA=competitionByDivisionZone("3div","sul-a"), sB=competitionByDivisionZone("3div","sul-b");
      if(nA&&nB) rebalanceTwoWay(nA,nB,Math.ceil((nA.teamIds.length+nB.teamIds.length)/2));
      if(sA&&sB) rebalanceTwoWay(sA,sB,Math.floor((sA.teamIds.length+sB.teamIds.length)/2));
    }
    return events;
  }
  function applyPromotionAndRelegation(){
    if(state.seasonTransitionApplied) return state.promotionEvent;
    const placard=competitionByDivisionZone("placard",null), norte=competitionByDivisionZone("2div","norte"), sul=competitionByDivisionZone("2div","sul");
    // Apuramento congelado: todas as decisões são calculadas antes de alterar qualquer divisão.
    const pTable=standingsForCompetition(placard.id), nTable=standingsForCompetition(norte.id), sTable=standingsForCompetition(sul.id);
    // 2026-10-16: tabelas finais de todas as ligas, congeladas antes de mexer em comp.teamIds (ver seasonEndTable).
    const frozenTables={};
    Object.values(state.competitions).filter(c=>["placard","ok-liga","serie-a1","2div","ok-liga-plata","3div"].includes(c.divisionId)&&!c.id.includes("apuramento")).forEach(c=>{
      frozenTables[c.id]=(c.id===placard.id?pTable:c.id===norte.id?nTable:c.id===sul.id?sTable:standingsForCompetition(c.id)).map(t=>t.id);
      // 3.ª Divisão: usa a tabela de zona congelada no arranque dos apuramentos (os jogos do apuramento já contaminaram team.stats).
      if(c.divisionId==="3div" && state.terceiraDivisaoZoneTables && Array.isArray(state.terceiraDivisaoZoneTables[c.id])){
        const snap=state.terceiraDivisaoZoneTables[c.id];
        frozenTables[c.id]=snap.filter(id=>c.teamIds.includes(id)).concat(c.teamIds.filter(id=>!snap.includes(id)));
      }
    });
    const frozenThirdPlan={nTable2:nTable.slice(),sTable2:sTable.slice(),relegatedNorte:nTable.slice(-3).map(t=>t.id),relegatedSul:sTable.slice(-3).map(t=>t.id)};
    const nEligible=eligiblePromotionRanking(nTable), sEligible=eligiblePromotionRanking(sTable);
    const promoted=[nEligible[0].id,sEligible[0].id,state.promotionTie.winner];
    const relegated=pTable.slice(-3).map(t=>t.id);
    if(new Set(promoted).size!==3) throw new Error("A promoção produziu clubes duplicados.");
    placard.teamIds=placard.teamIds.filter(id=>!relegated.includes(id)).concat(promoted);
    norte.teamIds=norte.teamIds.filter(id=>!promoted.includes(id));
    sul.teamIds=sul.teamIds.filter(id=>!promoted.includes(id));
    const norteSlots=14-norte.teamIds.length, sulSlots=14-sul.teamIds.length;
    const allocation=chooseBalancedPlacardAllocation(relegated,norteSlots,sulSlots);
    relegated.forEach((id,index)=>{
      const zona=allocation[index],competition=zona==="norte"?norte:sul;
      competition.teamIds.push(id); adaptClubFinanceToDivision(state.teams[id],state.teams[id].divisaoAtual,"2div","descida-placard"); state.teams[id].divisaoAtual="2div"; state.teams[id].zona=zona;
    });
    promoted.forEach(id=>{ adaptClubFinanceToDivision(state.teams[id],state.teams[id].divisaoAtual,"placard","promocao-2div"); state.teams[id].divisaoAtual="placard"; state.teams[id].zona=null; });
    validateDivisionTransition(placard,norte,sul);
    const thirdDivisionResult = applyThirdDivisionPromotionAndRelegation(frozenThirdPlan);
    const spanishResult = applySpanishPromotionAndRelegation();
    const bRule = enforceBTeamRule({apuramentoOrder: thirdDivisionResult ? thirdDivisionResult.apuramentoOrder : [], frozenTables});
    if(relegated.some(id=>frozenThirdPlan.relegatedNorte.includes(id)||frozenThirdPlan.relegatedSul.includes(id))) throw new Error("Transição inválida: clube desceu dois escalões na mesma época.");
    state.promotionEvent={epoca:seasonLabel(state.season),promoted:promoted.slice(),relegated:relegated.slice(),relegatedAllocation:Object.fromEntries(relegated.map((id,i)=>[id,allocation[i]])),champion:state.placardChampion,
      promotedFromThird: thirdDivisionResult ? thirdDivisionResult.promotedFromThird : [],
      relegatedToThird: thirdDivisionResult ? thirdDivisionResult.relegatedToThird : [],
      promotedEs: spanishResult ? spanishResult.promotedEs : [], relegatedEs: spanishResult ? spanishResult.relegatedEs : [],
      relegatedEsAllocation: spanishResult ? spanishResult.relegatedEsAllocation : {},
      bRule,
      // Elite Cup (07d-elite-cup.js): qualificação da próxima edição — os 8 primeiros do
      // Campeonato Placard desta época, na classificação ainda "congelada" (pTable), antes de
      // subidas/descidas serem aplicadas às divisões dos clubes.
      placardTop8: pTable.slice(0,8).map(t=>t.id),
      // Competições Europeias (07g-europa.js): qualificação por país precisa da classificação
      // final completa (não só o top 8), já que Portugal pode ter direito a mais de 8 vagas
      // somadas entre Champions League/Cup/Trophy/Qualificação.
      placardFullStandingsIds: pTable.map(t=>t.id),
      frozenTables};
    state.seasonTransitionApplied=true;
    const newComp=competitionIdForTeam(state.userTeamId);
    if(newComp) state.userCompetitionId=newComp;
    return state.promotionEvent;
  }
  // =================================================================
