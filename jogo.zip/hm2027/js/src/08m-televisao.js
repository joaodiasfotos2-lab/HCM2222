// Jogos na televisão (2026-10-12, pedido do utilizador: ideia 8 da sexta lista).
// Decisões de desenho confirmadas por ele:
//  - depende da DIVISÃO: Placard, OK Liga e Serie A1 têm 2 jogos transmitidos por jornada (as
//    divisões inferiores não têm televisão); a escolha é por interesse;
//  - efeitos: RECEITA para o clube, HORÁRIO que muda (o jogo só tem data por jornada, por isso a
//    mudança de dia e hora vem no email da Federação e o descanso de cada equipa é ajustado) e
//    EXPOSIÇÃO para patrocínios e adeptos (bónus do patrocinador, humor dos adeptos);
//  - a Federação avisa o clube do utilizador por EMAIL com antecedência;
//  - também para a IA: a escolha, o horário, as receitas e a exposição valem para todos os clubes.
//
// Base regulamentar (RGHP, Art. 10.º): a Federação é a detentora exclusiva dos direitos de
// transmissão, escolhe os jogos e pode impor a alteração do horário, dia ou local para tornar
// possível a transmissão; os clubes são informados com pelo menos 5 dias úteis de antecedência
// (aqui, 8 dias antes da jornada). O RGHP não fixa quanto cada clube recebe nem quantos jogos por
// jornada: os valores de receita, o bónus do patrocinador, o efeito na bilheteira (−8%), o
// ajuste de descanso por horário e o número de jogos por divisão são ESTIMATIVAS.
//
// Dados: fx.tv = { slot, label, interesse, descanso } no próprio jogo do calendário (guardado com a
// competição); round.tvDecidido marca a jornada tratada; team.tv = { epoca, jogos } (contagem para
// não escolher sempre os mesmos clubes).

const TV_DIVISOES = {
  "placard": { jogos: 2, base: 3500 },
  "ok-liga": { jogos: 2, base: 3500 },
  "serie-a1": { jogos: 2, base: 3000 },
};
const TV_ANTECEDENCIA_DIAS = 8;
// As jornadas são ao domingo: sexta/sábado = menos dias de descanso antes do jogo; segunda = mais um dia.
const TV_SLOTS = [
  { id: "sabado", label: "sábado às 20h30", dias: -1, descanso: -2.5 },
  { id: "domingo", label: "domingo às 18h00", dias: 0, descanso: 0 },
  { id: "sexta", label: "sexta-feira às 21h00", dias: -2, descanso: -5 },
  { id: "segunda", label: "segunda-feira às 21h00", dias: 1, descanso: 2.5 },
];
const TV_BILHETEIRA_FATOR = 0.92;
const TV_BONUS_PATROCINADOR_PCT = 0.08;   // da mensalidade do patrocinador, por jogo transmitido
const TV_HUMOR_VITORIA = 1.2;

function tvConfigDaCompeticao(comp){ return comp ? TV_DIVISOES[comp.divisionId] || null : null; }
function tvDiasAte(date){
  const a = new Date(state.currentDate), b = new Date(date);
  a.setHours(0, 0, 0, 0); b.setHours(0, 0, 0, 0);
  return Math.round((b - a) / 86400000);
}
function tvEnsure(team){
  if(!team) return null;
  if(!team.tv || typeof team.tv !== "object") team.tv = { epoca: state.season, jogos: 0 };
  if(team.tv.epoca !== state.season){ team.tv.epoca = state.season; team.tv.jogos = 0; }
  return team.tv;
}

// Interesse de um jogo (mais alto = mais apelativo para a televisão).
function tvInteresse(comp, fx, posOf){
  const h = state.teams[fx.home], a = state.teams[fx.away];
  if(!h || !a) return -99;
  let v = ((h.reputacao || 50) + (a.reputacao || 50)) / 2;
  if(typeof isDerby === "function" && isDerby(fx.home, fx.away)) v += (typeof derbyTvInteresse === "function" ? derbyTvInteresse(fx.home, fx.away) : 15);
  const ph = posOf[fx.home] || 99, pa = posOf[fx.away] || 99;
  if(ph <= 4 && pa <= 4) v += 12; else if(ph <= 4 || pa <= 4) v += 4;
  const n = comp.teamIds.length;
  if(ph > n - 3 && pa > n - 3) v += 6;           // duelo de aflitos
  v += patrocinioTvInteresse(h) + patrocinioTvInteresse(a);   // patrocinadores com exposição máxima pedem televisão
  v -= 6 * (tvEnsure(h).jogos + tvEnsure(a).jogos); // quem já foi muito à televisão cede o lugar
  v += (Math.random() - 0.5) * 10;
  return v;
}

function tvEscolherJornada(comp, roundIdx){
  const cfg = tvConfigDaCompeticao(comp);
  const round = comp.fixtures[roundIdx];
  if(!cfg || !round || round.tvDecidido) return [];
  round.tvDecidido = true;
  const standings = standingsForCompetition(comp.id) || [];
  const posOf = {}; standings.forEach((t, i) => { posOf[t.id] = i + 1; });
  const cands = round.filter(fx => !fx.played)
    .map(fx => ({ fx, v: tvInteresse(comp, fx, posOf) }))
    .sort((x, y) => y.v - x.v);
  const escolhidos = [];
  const usados = new Set();
  for(const c of cands){
    if(escolhidos.length >= cfg.jogos) break;
    if(usados.has(c.fx.home) || usados.has(c.fx.away)) continue;
    escolhidos.push(c); usados.add(c.fx.home); usados.add(c.fx.away);
  }
  // O melhor jogo vai para o horário nobre (sábado ou domingo); os outros para os restantes horários.
  const nobres = TV_SLOTS.filter(s => s.id === "sabado" || s.id === "domingo").sort(() => Math.random() - 0.5);
  const outros = TV_SLOTS.filter(s => s.id !== "sabado" && s.id !== "domingo").sort(() => Math.random() - 0.5);
  const ordem = nobres.concat(outros);
  escolhidos.forEach((c, i) => {
    const slot = ordem[i % ordem.length];
    c.fx.tv = { slot: slot.id, label: slot.label, interesse: Math.round(c.v), descanso: slot.descanso };
    tvEnsure(state.teams[c.fx.home]).jogos++; tvEnsure(state.teams[c.fx.away]).jogos++;
  });
  tvAvisarUtilizador(comp, roundIdx, escolhidos.map(c => c.fx), cfg);
  return escolhidos.map(c => c.fx);
}

function tvValorClube(fx, cfg, isHome){
  const r = clamp((fx.tv.interesse || 50) / 60, 0.7, 1.5);
  const dk = (typeof derbyTvDireitosMult === "function" && fx.home && fx.away) ? derbyTvDireitosMult(fx.home, fx.away) : 1;   // 0.2.4: Clássicos valem mais
  return Math.round(cfg.base * r * dk * (isHome ? 1 : 0.8));
}
function tvAvisarUtilizador(comp, roundIdx, jogos, cfg){
  const me = state.userTeamId;
  if(!me) return;
  const fx = jogos.find(f => f.home === me || f.away === me);
  if(!fx) return;
  const home = state.teams[fx.home], away = state.teams[fx.away];
  const euCasa = fx.home === me;
  const dRest = fx.tv.descanso;
  const descansoTxt = dRest < 0 ? `Joga mais cedo do que o resto da jornada: chegamos com menos descanso (cerca de ${Math.abs(dRest)} pontos de condição a menos).`
    : dRest > 0 ? `Joga mais tarde do que o resto da jornada: ganhamos um dia de descanso (cerca de ${dRest} pontos de condição a mais).` : "Mantém o dia habitual da jornada.";
  pushNews(state.currentDate,
    `A Federação escolheu o jogo <b>${escapeHtml(home.name)} vs ${escapeHtml(away.name)}</b> da jornada ${roundIdx + 1} para transmissão televisiva. O jogo passa para <b>${fx.tv.label}</b>. ${descansoTxt}<br><br>Receita estimada para o clube: ${fmtMoney(tvValorClube(fx, cfg, euCasa))} pelos direitos, mais um bónus do patrocinador pela exposição. Parte do público tende a ficar em casa a ver o jogo (cerca de −8% de assistência).`,
    "tv", `Televisão: ${home.name} vs ${away.name} — ${fx.tv.label}`, { sender: `comunicacao@${DISC_FEDERACAO[disciplinaPais(state.teams[me])] || "fpp.pt"}` });
}

// Diário: 8 dias antes de cada jornada de uma divisão com televisão, a Federação escolhe os jogos.
function tvDiario(){
  Object.values(state.competitions || {}).forEach(comp => {
    const cfg = tvConfigDaCompeticao(comp);
    if(!cfg || !comp.fixtures || comp.currentRound >= comp.fixtures.length) return;
    const round = comp.fixtures[comp.currentRound];
    if(!round || round.tvDecidido || !round.date) return;
    const dias = tvDiasAte(round.date);
    if(dias >= 0 && dias <= TV_ANTECEDENCIA_DIAS) tvEscolherJornada(comp, comp.currentRound);
  });
}

// O jogo (casa/fora) da jornada corrente da competição que está marcado para televisão.
function tvInfoDoJogo(competitionId, homeId, awayId){
  const comp = competitionId && state.competitions && state.competitions[competitionId];
  if(!comp || !comp.fixtures || !tvConfigDaCompeticao(comp)) return null;
  const round = comp.fixtures[comp.currentRound];
  if(!round) return null;
  const fx = round.find(f => f.home === homeId && f.away === awayId && !f.played);
  return fx && fx.tv ? fx.tv : null;
}
// Procura em todas as ligas com televisão (usado por matchAttendance, que não conhece a competição).
function tvJogoTransmitido(homeId, awayId){
  const comps = state.competitions ? Object.values(state.competitions) : [];
  for(const comp of comps){
    if(!tvConfigDaCompeticao(comp) || !comp.fixtures) continue;
    const round = comp.fixtures[comp.currentRound];
    if(!round) continue;
    const fx = round.find(f => f.home === homeId && f.away === awayId && !f.played);
    if(fx) return !!fx.tv;
  }
  return false;
}
function tvAplicarDescanso(tv, jogadores){
  if(!tv || !tv.descanso) return;
  (jogadores || []).filter(Boolean).forEach(p => {
    const cur = p.condicao != null && Number.isFinite(p.condicao) ? p.condicao : 100;
    p.condicao = roundDecimal(clamp(cur + tv.descanso, 0, 100));
  });
}

// Fim do jogo (finalizePlayerStats): receita dos direitos, bónus do patrocinador e humor dos adeptos.
function tvAposJogo(ctx){
  if(!ctx.tv || ctx.isFriendly) return;
  const comp = state.competitions && state.competitions[ctx.competitionId];
  const cfg = tvConfigDaCompeticao(comp);
  if(!cfg) return;
  const fx = { tv: ctx.tv, home: ctx.homeId, away: ctx.awayId };
  ["home", "away"].forEach(side => {
    const team = state.teams[side === "home" ? ctx.homeId : ctx.awayId];
    if(!team || !team.financeiro) return;
    const mine = side === "home" ? ctx.score.home : ctx.score.away, theirs = side === "home" ? ctx.score.away : ctx.score.home;
    const opp = state.teams[side === "home" ? ctx.awayId : ctx.homeId];
    const direitos = tvValorClube(fx, cfg, side === "home");
    addFinanceMovement(team, "receita", "Televisão", `Direitos de transmissão televisiva — jogo com o ${opp.name}`, direitos, state.currentDate);
    const bonus = Math.round((team.financeiro.receitaMensalPatrocinio || 0) * TV_BONUS_PATROCINADOR_PCT * (mine > theirs ? 1.3 : 1) * patrocinioTvMult(team));
    if(bonus > 0) addFinanceMovement(team, "receita", "Televisão", "Bónus de exposição mediática do patrocinador", bonus, state.currentDate);
    const a = typeof ensureAdeptos === "function" ? ensureAdeptos(team) : null;
    if(a) a.humor = clamp(a.humor + (mine > theirs ? TV_HUMOR_VITORIA : mine < theirs ? -TV_HUMOR_VITORIA : 0), 0, 100);
  });
}

// Condição à chegada ao jogo: viagem do visitante (08j) e ajuste de descanso do horário de TV, para
// uma equipa (jogadores já escolhidos para o jogo). O utilizador é tratado em newLiveMatchState,
// com a convocatória que escolheu.
function preJogoAplicarCondicao(ctx, side, jogadores){
  if(!ctx) return;
  if(side === "away" && ctx.viagem) viagemAplicarFadiga(ctx.viagem, jogadores);
  if(ctx.tv) tvAplicarDescanso(ctx.tv, jogadores);
}
